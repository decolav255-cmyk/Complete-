# CRO Demonstration Specification v2.0.5

**Version:** 2.0.5  
**Date:** 2026-11-07  
**Status:** APPROVED AND FROZEN — 2026-11-07
**Approval phrase:** `Approve CRO Demonstration Specification v2.0.5 as written.`  
**Amends:** v2.0.4 with completed Option A verification + independent artifact verification record  
**Non-changes:** No S1–S3 confirmatory re-runs; historical rates unchanged; V3 failure retained  

**R23 pin:** `SOURCE/cro/pooled_screen.py`  
SHA-256 `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`

---

## 1. Option A result

On the S2/S3 design (\(G=12\), two strata of 6 clusters, 3 treated per stratum, \(N_A=400\)), for **one fixed standardized moderator** (NumPy `default_rng(0)`):

| Metric | Value |
|--------|--------|
| Observed assignments tested | 400 |
| Full-universe retention (`valid = total = 400`) | 400 |
| Abstain | 0 |
| Partial retention | 0 |

**Conclusion for this (design, M) pair:**

\[
\mathcal{A}_{\mathrm{ret}}(T_{\mathrm{obs}}, M) = \mathcal{A}
\]

for every observed assignment in the declared universe.

Details: `DEMO/OPTION_A_REPORT.md`, `DEMO/OPTION_A_RESULTS.json`.

---

## 2. Independent artifact verification

**Verification date:** 2026-11-07  

### 2.1 Checks performed (all passed)

1. All **400** observed assignments appear exactly once (indices 0–399).  
2. Each row reports `valid_allocation_count = 400` and `allocation_space_size = 400`.  
3. Zero abstentions and zero partial-retention rows.  
4. Checkpoint and final results consistent (length 400; first/last rows match).  
5. Pinned source hash matches the executed `pooled_screen.py`.  
6. Record-verification bypass is confined to `verify_randomization_record` only (does not patch ranking / `exact_rank_and_fit` / `sharp_null_test` logic).  
7. Fixed M/Y construction from `default_rng(0)` present in the verification script.

### 2.2 SHA-256 fingerprints

| Artifact | SHA-256 |
|----------|---------|
| `OPTION_A_RESULTS.json` | `a02ebf57499fa6e4bb49d38f09eb29653073da0b49aaa102553f77814a7071d3` |
| Moderator vector M (bytes) | `b20496c6b9d2c3b273ebce2e321c300669628c3aea7e1ec4071b34ad5bd7f3db` |
| Outcome vector Y (bytes) | `ba3a9e89807bc7b0e3493e4c8d71d7047f4fd9e7a48739f636f819cd01d34ae0` |
| R23 `pooled_screen.py` | `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6` |

### 2.3 Explicit limitation

This verification applies to the **supplied artifacts** and the **tested (design, M)** pair. It does **not** establish retention invariance for other moderator vectors, other CRT designs, or a general exactness theorem.

---

## 3. How D1 p-values may be described

**When diagnostics show `valid = total = N_A` on the S2/S3 design:**  
Exact enumeration p-value over the full complete-randomization allocation universe under the declared strata margins, as implemented by pinned R23 fixed-τ `sharp_null_test` (interaction statistic). Option A shows that, for the tested M, retention was full for every observed assignment.

**Historical confirmatory S2/S3 AUTHORIZE rates (4.6%):**  
Historical engine outputs (n=500). Option A and artifact verification support full-universe retention for the tested M on this design; they do **not** by themselves rewrite historical rows without per-replicate logs from those runs.

**Still not claimed:** moderation; beneficial improvement from D1; universal 5% calibration; V3 pass.

---

## 4. Unchanged historical results and commercial limits

| Item | Status |
|------|--------|
| S1 primary success 0.982 (0.966, 0.991) | Retain |
| S2/S3 AUTHORIZE 0.046 (0.031, 0.068) | Retain as historical engine outputs |
| V3 (\(\hat p \ge 0.20\)) | **FAILED** |
| C1_OLS_unclustered 31.2% on S2 | Not CRT-valid main-effect inference |
| C1m_cluster | Predeclared; unevaluated |
| Demo vs OC v1.1 | Demo does not replace OC |
| Thresholds / retuning | None |

---

## 5. Outcome states (mutually exclusive)

| State | Meaning |
|-------|---------|
| **NOT_ELIGIBLE** | Missing/invalid/unreproducible assignment record |
| **ABSTAIN** | Valid design intent, but engine numerical/computational failure |
| **DO_NOT_AUTHORIZE** | Eligible test executed; \(p \ge 0.05\) |
| **AUTHORIZE** | Eligible test executed; \(p < 0.05\) → `AUTHORIZE_DESIGN_BASED_REJECTION_OF_SHARP_NULL` |

---

## 6. Approval record

**Approved and frozen** on 2026-11-07 with the phrase:

`Approve CRO Demonstration Specification v2.0.5 as written.`

Content SHA-256 before status stamp (inspection draft as reviewed):  
`0e0d1a6436e5e2b752e21940711136a71a427a588d2a51ba14f62356ae2ca931`

This freeze does **not** authorize new confirmatory runs, change historical rates, reverse V3 failure, or expand commercial claims.
