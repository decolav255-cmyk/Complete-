# CRO — Offer and pricing

**Scientific baseline:** CRO Demonstration Specification v2.0.5 (APPROVED AND FROZEN).  
**Commercial status:** research-stage offer; paid operational work remains conditional on release, security, legal, and customer-data readiness approval.

## 1. What CRO offers

**Design-gated causal authorization for intervention analytics.** CRO checks whether a causal claim is supported by a verifiable assignment mechanism before authorizing a design-based conclusion.

1. Without a verifiable assignment record, CRO refuses design-based causal authorization (S1-style NOT_ELIGIBLE / refusal).
2. For a declared cluster-randomized design, the CRT path additionally requires stable cluster IDs, strata, treatment alignment, and a reproducible assignment record.
3. Only after eligibility passes does CRO run the pinned R23 exact-enumeration sharp-null test for its specified interaction functional.
4. Results are reported within v2.0.5's boundaries. D1 rejection is not proof of moderation, beneficial improvement, ROI, safety, or deployment suitability.

## 2. Packages and indicative pricing

| Package | Scope | Indicative price |
|---|---|---:|
| **A. Design Gate Review** | One study's assignment evidence and design reviewed; written eligibility / refusal memo and 60–90 minute readout | **$8k–$15k** fixed |
| **B. Pilot Authorization Gate** | Up to three studies / experiment designs over 6–8 weeks; mandatory assignment-record, cluster-ID, and strata checks; S1-style refusal plus exact-enumeration CRT path where eligible; methods appendices and decision memos | **$25k–$45k** |
| **C. Annual Gate License (future / not currently offerable)** | Internal workflow license, quarterly methods office hours | **$60k–$120k / year** — indicative only; not an available production offer |

Pricing is indicative and subject to scope, data-security review, legal terms, and written release authorization. Do not promise a start date or binding fixed price before those approvals.

## 3. Pilot prerequisites

Before a paid operational pilot is contracted or customer data is accepted:

- Owner approval of the specific release candidate.
- Reproducible verification of all applicable implementation gates and adversarial tests.
- Independent technical review of the release candidate.
- Customer data security, privacy, retention, deletion, access controls, and incident-response review.
- Runbook, rollback procedure, data-processing terms, liability / IP terms, and signed scope.

A study cannot enter the CRT authorization path without a verifiable assignment record, cluster IDs, and strata. If those are absent or cannot be reproduced, CRO's deliverable is a refusal / NOT_ELIGIBLE memo.

## 4. Evidence and claim boundaries

The synthetic confirmatory S1 result supports only this narrow statement: without a verifiable randomization record, CRO did not authorize a design-based causal claim, while unclustered OLS was significant in 98.2% of the synthetic replicates. It is not partner validation.

Other limitations that must accompany the offer:

- D1 is a sharp-global-null randomization test using an interaction functional, not a moderation detector.
- V3's predeclared 20% power floor failed; the historical D1 power result remains 4.6%.
- C1m_cluster's G=12 synthetic evaluation had an estimated null rejection rate of 9.4%; it is not exact 5% calibration.
- OC Protocol v1.1 remains partial.
- No partner validation, production certification, or customer outcome improvement has been established.

## 5. Out of scope

- Guaranteed ROI, lift percentages, or marketing claims that an intervention worked.
- D1 as proof of moderation or beneficial improvement.
- Treating unclustered OLS as CRT-valid evidence.
- Universal 5% calibration, V3 pass, or completed OC v1.1 claims.
- Production deployment, customer-model retraining, or safety / compliance certification.

## 6. First 90-day commercial objective

Target 10–15 qualified discovery conversations, 3 paid or scoped Design Gate Reviews, and 1 conditional Pilot Authorization Gate—subject to the prerequisites above. Discovery conversations should focus on assignment records and governance needs; do not request confidential datasets in initial outreach.
