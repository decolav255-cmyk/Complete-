# Outreach readiness and release boundary

**As of:** 2026-11-09  
**Scientific baseline:** CRO Demonstration Specification v2.0.5 (APPROVED AND FROZEN)

## Decision

- **Exploratory outreach / discovery conversations:** READY, using the approved one-pager and bounded claims.
- **Paid operational pilot:** CONDITIONAL — not authorized by this document alone.
- **Annual software license / production deployment:** NOT OFFERABLE.

## Evidence in this release candidate

- Restored the original 91-entry research package and retained the original package, R23, and CRO v0.6.16 baseline ZIPs under `ORIGINALS/`.
- Preserved the approved v2.0.5 specification, approval record, historical S1–S3 evidence, Option A artifacts, and partial OC v1.1 materials.
- Included genuine R23 `SOURCE/cro/pooled_screen.py`, verified against SHA-256 `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`.
- Combined package source suite: **64 passed** (34 core-gate, 25 R23, 2 release-integrity, and 3 OC seed tests).
- CRO v0.6.16 baseline suite: **207 passed** from the nested baseline archive.
- Demo smoke run: 5 replicates each for S1/S2/S3; embedded checks passed. Historical confirmatory results were not rerun or overwritten.
- Added local SQLite-based authority-token / revocation controls, transaction-bound database fencing, append-only local audit rows, canonical serialization and Ed25519 binding helpers, persisted lifecycle transitions, SQLite WAL transactions, and signed checkpoint verification with clock rollback detection.
- Replaced process-randomized Python `hash()` seed derivation for future OC runs with a domain-separated SHA-256 scheme. Historical partial OC outputs were preserved unchanged and are not retroactively attributed to the new scheme.
- G5 limitation is explicit: SQLite WAL is implemented; PostgreSQL SERIALIZABLE is not implemented and raises `NotImplementedError`.

These are reproducible local test results for this candidate, not an independent third-party security certification or production-readiness finding.

## Paid-pilot prerequisites still open

- Independent technical / security review of this exact candidate, including broader multi-process crash-recovery and adversarial testing beyond the local concurrency cases already covered.
- Remote independent authority deployment and operational key custody.
- External side-effect fencing / idempotent receiver integration.
- Project-controlled detached release-manifest signing.
- Customer-data security and privacy review: access controls, encryption / key custody, retention, deletion, incident response, and data-processing terms.
- Operational runbook, rollback procedure, deployment controls, signed scope / liability / IP terms.
- Owner's explicit authorization of the exact release candidate and pilot scope.

## Mandatory study-level authorization gate

A study cannot enter the design-based CRT authorization path unless it supplies a verifiable assignment record, stable cluster IDs, strata aligned to that record, treatment / outcome data, and a pretreatment moderator for the D1 interaction-functional test. If the assignment record is missing, invalid, or unreproducible—or required cluster / strata identifiers are absent—CRO returns NOT_ELIGIBLE / refusal. No observational regression substitutes for this refusal.

## Permitted claims

Use `EXECUTIVE_ONE_PAGER.md`, `COVER_EMAIL.md`, and `PILOT_PROTOCOL.md`. State that the scientific evidence is synthetic, v2.0.5 is frozen, V3 failed, OC v1.1 is partial, and no partner or production validation exists.

## Prohibited claims

Do not claim CRO is production-ready, independently certified, universally calibrated, partner-validated, guaranteed to identify beneficial interventions, or approved to process customer data. Do not offer a firm pilot start date or binding fixed-price commitment before the prerequisites are satisfied.

## Next release gate

A paid pilot may be considered only after owner approval, independent technical review, completed customer-data / security controls, an operational runbook and rollback, and signed contractual terms. This file does not itself authorize a pilot.
