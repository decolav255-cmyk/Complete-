Subject: CRO — design-gated causal authorization (research-stage)

We are exploring a research-stage **Design Gate Review / Pilot Authorization Gate** for teams that need audit-friendly discipline when claiming an intervention “worked.”

**What the synthetic confirmatory evidence shows (Spec v2.0.5, frozen):** Under confounding with **no** randomization record, unclustered OLS was significant in 98.2% of replicates while CRO **never** authorized a design-based causal claim (reason: missing randomization record; primary success 98.2%, Wilson 96.6–99.1%).

For the CRT path, CRO requires a verifiable assignment record, stable cluster IDs, and strata aligned with the declared allocation. If those are missing or the record cannot be reproduced, the result is refusal / NOT_ELIGIBLE—not an observational substitute. Where eligibility passes, D1 reports sharp-null rejection/non-rejection under the declared mechanism; it does not prove moderation or beneficial improvement.

**Potential pilot scope:** up to three studies over 6–8 weeks, with eligibility decisions, written authorization/refusal memos, and methods appendices. Indicative pricing is USD 25k–45k, subject to release, security, data-handling, and legal approvals. This is not a commitment that a paid pilot is currently cleared to start.

Would a 20-minute discovery call be useful to understand what assignment evidence your team retains for live or planned experiments?
