# CRO — Executive briefing (research demonstration)

**Status:** Research-stage demonstration under **CRO Demonstration Specification v2.0.5 (APPROVED AND FROZEN)**.  
**Not:** production certification, partner validation, or guaranteed ROI.

## Headline result

In a **confounded** synthetic design with **no randomization record** (n=500):

- Unclustered OLS of outcome on treatment was significantly positive in **98.2%** of replicates.
- CRO decision rule **D1 never authorized** a design-based causal claim (**0%**).
- Non-authorization reason: **`missing_randomization_record`** (not a hard-coded confounder flag).
- Primary success rate: **98.2%** (Wilson 95% CI **96.6–99.1%**).

**Claim you may make:**  
*Without a verifiable randomization record, CRO does not authorize a design-based causal claim—even when unclustered OLS is significant.*

## When a cluster-randomized record exists

The CRT authorization path requires a reproducible assignment record, stable cluster IDs, strata aligned to that record, treatment/outcome alignment, and a pretreatment moderator for the D1 interaction-functional test. Missing or unreproducible assignment evidence, cluster IDs, or strata produces NOT_ELIGIBLE / refusal.

- **D1** reports only rejection/non-rejection of the **sharp global null** under the verified CRT mechanism (interaction functional).  
  Historical AUTHORIZE rate against a pure main-effect alternative: **4.6%** (CI **3.1–6.8%**).  
  Predeclared demo power floor 20% (**V3**): **not met** — reported failure.  
  This is **not** a moderation finding and **not** a proven beneficial “improvement.”

- **C1m_cluster** (cluster-robust main-effect readout: \(Y\sim 1+T+\) stratum FE, CR1 SE) was **implemented and evaluated** on the same design family (synthetic n=500):  
  - Main-effect alternative (τ=0.35): significance rate **0.232** (CI **0.197–0.271**)  
  - Null: significance rate **0.094** (CI **0.071–0.123**) — **inflated vs 5%** at G=12; not exact calibration  

- Unclustered OLS on S2 remains a **foil only** (~31%), not CRT-valid inference.

## Option A (retention)

For the S2/S3 design and one fixed moderator, all 400 observed assignments retained the full 400-allocation universe (artifact-verified). This does **not** generalize to all moderators or all designs by itself, and does **not** retro-certify historical 4.6% rows without per-replicate logs from those runs.

## Type I snapshot (randomized null, D1)

D1 AUTHORIZE **4.6%** (CI **3.1–6.8%**), zero abstentions in 500 replicates. Not a claim of universal 5% calibration.

## What this is not

| Do not say | Why |
|------------|-----|
| D1 confirmed moderation or beneficial improvement | Wrong estimand / forbidden under v2.0.5 |
| V3 passed | Failed at 4.6% vs 20% floor |
| C1m is exact 5% CRT calibration at G=12 | Type I ~9.4% in synthetic eval |
| OC Protocol v1.1 complete | Partial only |
| Partner / production validated | Synthetic demonstration only |

## One sentence

**CRO is a design-gated evidence brake and sharp-null randomization test under a declared CRT—not an automatic ROI or moderation detector.**
