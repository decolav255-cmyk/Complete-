# Progress update after items 2–4 (no pilot)

## Done

### 2. C1m_cluster
- Implemented: `DEMO/run_demo.py` → `c1m_cluster_test` (Y ~ 1+T+stratum FE, CR1 SE, normal p)
- Evaluated: 500 reps S2-like (τ=0.35) and S3-like (τ=0)
- **Power (τ=0.35):** sig rate **0.232** (Wilson 0.197–0.271); abstain 0
- **Type I (τ=0):** sig rate **0.094** (Wilson 0.071–0.123) — inflated vs 5% at G=12; do not claim exact calibration
- Artifacts: `DEMO/C1M_CLUSTER_EVAL.json`, `DEMO/C1M_CLUSTER_REPORT.md`

### 3. Offer + pricing
- `COMMERCIAL/OFFER_AND_PRICING.md`
- Packages: Design Gate Review ($8–15k), Pilot ($25–45k), Annual ($60–120k)
- Claims locked to frozen v2.0.5

### 4. OC extra (partial)
- Incremental G=12 n=5 cells written to `OC/RESULTS_oc_extra.json` as completed
- Full v1.1 5k/2k targets still **not** met
- Does not change frozen demo rates

## Profit bar (revised)
Roughly **~45–50%** toward careful first revenue (was ~40%): stronger main-effect readout + clear offer. Still need your pilot (#1) for a real jump.
