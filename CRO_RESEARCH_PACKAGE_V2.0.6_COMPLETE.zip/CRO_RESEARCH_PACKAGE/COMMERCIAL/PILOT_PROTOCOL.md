# CRO Pilot Authorization Gate — Protocol

**Aligned to:** CRO Demonstration Specification v2.0.5 (APPROVED AND FROZEN)  
**Pilot scope:** Up to three studies / experiment designs over 6–8 weeks  
**Status:** Research-stage, conditional pilot protocol; not production certification or partner validation.

## 1. Purpose

The pilot applies CRO's design-gated authorization rules to up to three customer studies. It determines whether the supplied assignment mechanism is sufficiently documented and reproducible for a design-based analysis. CRO does not infer randomization from outcome patterns or substitute observational regression when assignment evidence is missing.

## 2. Mandatory eligibility inputs — all required for the CRT path

For each study proposed for design-based causal authorization, the customer must provide:

1. **Verifiable assignment record:** the randomization algorithm / draw rule and the seed or equivalent auditable draw record, plus the treated allocation counts by stratum. The record must reproduce the observed assignment under the declared design.
2. **Stable cluster identifiers:** one unambiguous cluster ID for every analysis unit, with treatment assignment consistent with the declared cluster-level mechanism.
3. **Strata identifiers:** the stratum for every cluster, aligned with the randomization record and allocation margins.
4. **Treatment and outcome data:** correctly aligned to the cluster / unit IDs, with a documented outcome definition.
5. **Pretreatment moderator:** required if the D1 interaction-functional test is to be run.

Missing, invalid, internally inconsistent, or unreproducible assignment evidence results in **NOT_ELIGIBLE** / S1-style refusal. CRO must not run or report a design-based authorization result for that study. Missing cluster IDs or strata likewise blocks the CRT path. These are eligibility requirements, not optional preferences.

A study without a qualifying randomized assignment record may still receive a documented design review, but the conclusion is refusal / not eligible—not causal authorization.

## 3. Execution gates per study

- **Gate A — eligibility and provenance:** validate the assignment record, cluster IDs, strata, treatment alignment, and required pretreatment moderator.
- **Gate B — S1-style refusal check:** confirm that absence or failure of assignment verification produces NOT_ELIGIBLE / refusal, with a reason code. Do not use unclustered OLS as a replacement.
- **Gate C — exact-enumeration path:** only for a verified declared cluster-randomized design, execute the pinned R23 `RobustPooledScreenEngine.sharp_null_test` using the declared assignment configuration. Preserve the result, diagnostics, and source pin.
- **Gate D — decision memo:** report AUTHORIZE / DO_NOT_AUTHORIZE / ABSTAIN / NOT_ELIGIBLE exactly within v2.0.5 boundaries. AUTHORIZE means rejection of the specified sharp global null under the verified design; it does not mean proven moderation, ROI, beneficial improvement, safety, or deployment suitability.

## 4. Scope and deliverables

**Scope:** up to three studies / experiment designs, one agreed data intake per study, eligibility review, approved analysis path where eligible, and one consolidated readout over 6–8 weeks.

**Deliverables:**

- Study-level eligibility and assignment-provenance checklist.
- Authorization / refusal / abstention memo for each study, with reason codes.
- Methods appendix documenting the declared assignment mechanism, strata, cluster IDs, exact-enumeration protocol, source pin, and diagnostics.
- Alignment statement against the applicable predeclared test protocol and v2.0.5 boundaries / explicit non-claims.
- Final readout and limitations register.

## 5. Timeline

| Period | Activity |
|---|---|
| Week 1 | Kickoff, data dictionary, assignment-record intake, eligibility screen |
| Weeks 2–4 | Analysis of up to three eligible studies; refusal memos for ineligible studies |
| Week 5 | Draft study memos and methods appendix |
| Weeks 6–8 | Review, final readout, and final deliverables |

## 6. Out of scope and prohibited claims

- Guaranteed ROI, lift, or financial return.
- D1 as proof of moderation or beneficial improvement.
- Unclustered OLS as CRT-valid inference.
- Universal 5% Type-I control or a V3 pass.
- Completion of OC Protocol v1.1 (its outputs remain partial).
- Partner validation, production certification, safety certification, or deployment approval.
- Customer model retraining or production MLOps integration.

## 7. Frozen-science boundary

The approved v2.0.5 specification, approval record, confirmatory S1–S3 results, Option A artifacts, and historical rates remain unchanged. Customer pilot results are customer-specific and must not overwrite or be pooled into historical evidence without a separate predeclared protocol.

## 8. Commercial success criterion

The pilot succeeds when the customer receives reproducible eligibility decisions and auditable authorization / refusal / abstention memos for the agreed studies. It does not require a statistically significant result or a target uplift.
