"""Stable hierarchical OC seed derivation (no process-randomized Python hash())."""
from __future__ import annotations

import hashlib
import numpy as np

SEED_SCHEME_VERSION = "sha256_label_words_v1"


def seed_word(kind: str, value: str) -> int:
    if not isinstance(kind, str) or not kind or not isinstance(value, str) or not value:
        raise ValueError("seed label kind and value must be non-empty strings")
    material = b"CRO_OC_SEED_V1\x00" + kind.encode("utf-8") + b"\x00" + value.encode("utf-8")
    return int.from_bytes(hashlib.sha256(material).digest()[:4], "big", signed=False)


def child_rng(scenario: str, cell_id: str, replicate: int, role: str,
              master_seed: int = 20261107) -> np.random.Generator:
    if isinstance(replicate, bool) or not isinstance(replicate, int) or replicate < 0:
        raise ValueError("replicate must be a non-negative integer")
    if isinstance(master_seed, bool) or not isinstance(master_seed, int) or master_seed < 0:
        raise ValueError("master_seed must be a non-negative integer")
    sequence = np.random.SeedSequence([
        master_seed,
        seed_word("scenario", scenario),
        seed_word("cell_id", cell_id),
        replicate,
        seed_word("role", role),
    ])
    return np.random.Generator(np.random.PCG64(sequence))
