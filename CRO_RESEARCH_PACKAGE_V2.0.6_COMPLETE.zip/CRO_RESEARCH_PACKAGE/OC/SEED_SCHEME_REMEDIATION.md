# OC deterministic seed remediation

**Date:** 2026-11-09  
**Scope:** Future OC runs only; historical partial outputs preserved unchanged.

## Defect found

The inherited `OC/run_oc_v11.py` derived scenario, cell, and role seed words using Python's built-in `hash()`. Python string hashes are process-randomized unless `PYTHONHASHSEED` is fixed. The archived partial result metadata does not record a `PYTHONHASHSEED` value or the resulting child-seed words. Therefore, the exact random streams for those historical partial outputs cannot be independently reconstructed from the archived metadata alone.

## Correction

Future calls to the OC runner now use `OC/seed_scheme.py`:

- Domain-separated UTF-8 material: `CRO_OC_SEED_V1\0` + label kind + `\0` + label.
- SHA-256 of that material; first four digest bytes interpreted as an unsigned big-endian 32-bit word.
- `numpy.random.SeedSequence([MASTER_SEED, scenario_word, cell_word, replicate, role_word])` followed by `PCG64`.
- New run metadata records `seed_scheme_version = sha256_label_words_v1` and the exact scheme description.

The stable seed mapping is unit-tested. The OC preregistration v1.1 file remains unchanged.

## Historical-output boundary

`OC/RESULTS.json`, `OC/RESULTS_stage1_incremental.json`, `OC/RESULTS_oc_extra.json`, and associated CSV/log artifacts were **not** regenerated or rewritten. They remain partial historical outputs. This correction does not retroactively claim that they used the new deterministic seed mapping. Any future continuation must identify the corrected seed scheme in its run metadata and report the prior partial outputs separately; it must not silently merge incompatible seed histories as though they were one reproducible run.
