#!/usr/bin/env python3
import json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_oc_v11 as R

def main():
    outp = Path(__file__).resolve().parent / 'RESULTS_oc_extra.json'
    cells = []
    # More precise Type I at G=12 n=5 for 3 ICCs with 100 reps
    for icc in (0.05, 0.20, 0.50):
        print(f'OC extra sharp G=12 n=5 icc={icc}', flush=True)
        cell = R.run_cell(12, 5, icc, 0.0, 100, 'sharp_null')
        cells.append(cell)
        print('  uncond', cell['unconditional_rejection_rate'], 'p2', cell['p2_unconditional_rejection_rate'], flush=True)
    # Power G=12 n=5 beta=0.35 100 reps
    for icc in (0.05, 0.20, 0.50):
        print(f'OC extra power G=12 n=5 icc={icc} beta=0.35', flush=True)
        cell = R.run_cell(12, 5, icc, 0.35, 100, 'power')
        cells.append(cell)
        print('  uncond', cell['unconditional_rejection_rate'], flush=True)
    meta = {
        'note': 'OC extra cells; synthetic; does not complete full v1.1 5000/2000 targets',
        'protocol': 'v1.1',
        'master_seed': R.MASTER_SEED,
        'seed_scheme_version': R.SEED_SCHEME_VERSION,
        'seed_scheme': 'SeedSequence([MASTER_SEED, SHA256_32(scenario), SHA256_32(cell_id), replicate, SHA256_32(role)]) -> PCG64',
    }
    outp.write_text(json.dumps({'meta': meta, 'cells': cells}, indent=2))
    print('Wrote', outp)

if __name__ == '__main__':
    main()
