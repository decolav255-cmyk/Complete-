# OC Report — Protocol v1.1 (final package snapshot)

Generated (UTC): 2026-11-05T19:41:16.716702+00:00
Protocol SHA-256: 7f2c550d3cb5ad782c7b94165bfe5a7a1c2bef4ed6c43177865c6c47f3d16ac0
Source SHA-256: 92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6
Master seed: 20261107

## Important scope
- Synthetic cluster-randomized designs only under Protocol v1.1.
- P1 = R23 `sharp_null_test` (exact-rational enumeration).
- P2 = naive CR1 standard-normal comparator (expected anti-conservative at small G).
- **Full target 5,000 / 2,000 reps not completed.** Stage-1 uses 50–100; partial stage-2 uses 500 for selected G=8 cells.
- G=40 confirmatory P1 unavailable (no verified exact-rational MC).
- G=12 n=20 cells not completed in this snapshot (compute time).

## Results table

| scenario | cell | reps | P1 uncond | P1 cond | abstain | P2 uncond |
|----------|------|------|-----------|---------|---------|-----------|
| power | G8_n5_icc0.05_beta0.20 | 50 | 0.0000 | 0.0000 | 0.0000 | 0.3600 |
| power | G8_n5_icc0.05_beta0.35 | 50 | 0.0000 | 0.0000 | 0.0000 | 0.4000 |
| power | G8_n5_icc0.20_beta0.20 | 50 | 0.0000 | 0.0000 | 0.0000 | 0.4800 |
| power | G8_n5_icc0.20_beta0.35 | 50 | 0.0000 | 0.0000 | 0.0000 | 0.3600 |
| power | G8_n5_icc0.50_beta0.20 | 50 | 0.0000 | 0.0000 | 0.0000 | 0.4000 |
| power | G8_n5_icc0.50_beta0.35 | 50 | 0.0000 | 0.0000 | 0.0000 | 0.3000 |
| power | G8_n20_icc0.05_beta0.20 | 50 | 0.0000 | 0.0000 | 0.0000 | 0.4400 |
| power | G8_n20_icc0.05_beta0.35 | 50 | 0.0000 | 0.0000 | 0.0000 | 0.5800 |
| power | G8_n20_icc0.20_beta0.35 | 50 | 0.0000 | 0.0000 | 0.0000 | 0.4200 |
| power | G8_n20_icc0.50_beta0.35 | 50 | 0.0000 | 0.0000 | 0.0000 | 0.3200 |
| power | G12_n5_icc0.05_beta0.35 | 40 | 0.1500 | 0.1500 | 0.0000 | 0.4250 |
| power | G12_n5_icc0.20_beta0.35 | 40 | 0.0500 | 0.0500 | 0.0000 | 0.4000 |
| sharp_null | G8_n5_icc0.05_beta0.00 | 100 | 0.0000 | 0.0000 | 0.0000 | 0.3200 |
| sharp_null | G8_n5_icc0.20_beta0.00 | 500 | 0.0000 | 0.0000 | 0.0000 | 0.3180 |
| sharp_null | G8_n5_icc0.50_beta0.00 | 100 | 0.0000 | 0.0000 | 0.0000 | 0.2800 |
| sharp_null | G8_n20_icc0.05_beta0.00 | 100 | 0.0000 | 0.0000 | 0.0000 | 0.3900 |
| sharp_null | G8_n20_icc0.20_beta0.00 | 100 | 0.0000 | 0.0000 | 0.0000 | 0.3300 |
| sharp_null | G8_n20_icc0.50_beta0.00 | 100 | 0.0000 | 0.0000 | 0.0000 | 0.3200 |
| sharp_null | G12_n5_icc0.05_beta0.00 | 50 | 0.0400 | 0.0400 | 0.0000 | 0.2600 |
| sharp_null | G12_n5_icc0.20_beta0.00 | 50 | 0.0600 | 0.0600 | 0.0000 | 0.2200 |
| sharp_null | G12_n5_icc0.50_beta0.00 | 50 | 0.0600 | 0.0600 | 0.0000 | 0.2600 |

## Interpretation
1. **P1 at G=8:** 0 rejections in all completed sharp-null cells including 500-rep stage-2 cells — consistent with a conservative discrete exact test (N_A=36). Wilson upper bounds shrink with 500 reps but zero events still do not prove asymptotic 5% calibration alone.
2. **P1 at G=12 (n=5, 50 reps):** rejection rates ≈ 0.04–0.06 under the sharp null — near nominal but imprecise.
3. **P2 naive CR1:** rejection rates ≈ 0.22–0.40 under the sharp null — **anti-conservative** at these G; do not use as primary confirmatory p-value.
4. **Power:** At G=8, P1 power ≈ 0 for β∈{0.20,0.35} with 50 reps (limited discrete power / small G). At G=12 n=5 β=0.35, observed power ≈ 0.05–0.15 (low).
5. **Abstention:** 0 on completed cells with valid randomization_record.

## Permitted claim language
> In the preregistered synthetic cluster-randomized designs described in Protocol v1.1 (completed cells only), the procedure exhibited the reported rejection, power, and abstention rates.

## Prohibited
Production proven; partner validated; moderator discovery guaranteed; ROI claims.
