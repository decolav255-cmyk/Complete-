# CRO Phase 1 Operating-Characteristics Study — Protocol v1.1 (Amendment)

**Status:** APPROVED FOR EXECUTION under user instruction 2026-11-05 (adopt v1.1; start confirmatory simulation).  
**Amends:** Protocol v1.0 draft (Pasted Text-10).  
**Rule:** This file is immutable for confirmatory runs under v1.1. Further changes require v1.2+.

## Amendment rationale

1. R23 provides verified **exact enumeration** only; no verified exact-rational Monte Carlo path exists.  
2. \(G=40\) yields \(N_A \approx 3.4\times 10^{10}\) — confirmatory P1 marked **computationally unavailable**.  
3. Default `min_clusters_threshold=10` blocks \(G=8\); OC study uses `min_clusters_threshold=8`.  
4. Confirmatory P1 grid narrowed to designs that can be fully enumerated under R23.

## Confirmatory design grid (v1.1)

| Factor | Confirmatory levels |
|--------|---------------------|
| G | **8, 12** (primary). G=20 optional extension if resources allow. **G=40: P1 unavailable** |
| Strata | 2 equal; half treated per stratum |
| Cluster size | 5, 20 |
| ICC | 0.05, 0.20, 0.50 |
| Alpha | 0.05 two-sided |
| Sharp-null replicates | 5,000 per cell (target); staged execution allowed with cumulative reporting |
| Power replicates | 2,000 per cell (target); \(\beta \in \{0.20, 0.35\}\) |
| Master seed | 20261107 |
| P1 | R23 `sharp_null_test` exact-rational path only |
| P2/P3 | Naive CR1 normal-reference comparator |
| Study engine config | `min_clusters_threshold=8`, `exact_enumeration_threshold=1_000_000` |

## Unchanged from v1.0

DGP, sharp null, power alternatives, metrics (Wilson intervals, abstention accounting), seed hierarchy principles, reporting language restrictions, prohibition on unverified MC as confirmatory P1.

## Explicit non-claims

Synthetic OC only. No partner validation, no production certification, no ROI, no “moderator proven.”
