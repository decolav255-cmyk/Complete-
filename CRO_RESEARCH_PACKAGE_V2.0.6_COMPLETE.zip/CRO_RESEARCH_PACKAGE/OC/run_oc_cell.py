#!/usr/bin/env python3
"""Run a single OC cell and append to RESULTS_stage1_incremental.json"""
from __future__ import annotations
import json, sys
from pathlib import Path

# Import runner helpers
sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_oc_v11 as R

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--G', type=int, required=True)
    ap.add_argument('--n', type=int, required=True)
    ap.add_argument('--icc', type=float, required=True)
    ap.add_argument('--beta', type=float, required=True)
    ap.add_argument('--reps', type=int, required=True)
    ap.add_argument('--scenario', required=True)
    ap.add_argument('--out', default=str(Path(__file__).resolve().parent / 'RESULTS_stage1_incremental.json'))
    args = ap.parse_args()

    cell = R.run_cell(args.G, args.n, args.icc, args.beta, args.reps, args.scenario)
    outp = Path(args.out)
    if outp.exists():
        data = json.loads(outp.read_text())
    else:
        data = {
            'meta': {
                'protocol': 'v1.1',
                'protocol_sha256': R.sha256_file(R.PROTOCOL_PATH),
                'source_pooled_screen_sha256': R.sha256_file(R.SOURCE_POOL),
                'master_seed': R.MASTER_SEED,
                'seed_scheme_version': R.SEED_SCHEME_VERSION,
                'seed_scheme': 'SeedSequence([MASTER_SEED, SHA256_32(scenario), SHA256_32(cell_id), replicate, SHA256_32(role)]) -> PCG64',
                'stage': 'stage1_incremental',
                'note': 'Synthetic OC; incremental cell persistence',
            },
            'cells': [],
        }
    # replace same cell_id if re-run
    data['cells'] = [c for c in data['cells'] if c.get('cell_id') != cell['cell_id'] or c.get('scenario') != cell['scenario']]
    # cell_id includes beta so unique across scenarios... scenario also stored
    data['cells'] = [c for c in data['cells'] if not (c.get('cell_id') == cell['cell_id'] and c.get('scenario') == cell['scenario'])]
    data['cells'].append(cell)
    outp.write_text(json.dumps(data, indent=2))
    print(json.dumps({
        'cell_id': cell['cell_id'],
        'scenario': cell['scenario'],
        'uncond': cell['unconditional_rejection_rate'],
        'cond': cell['conditional_rejection_rate'],
        'abst': cell['abstention_rate'],
        'p2_uncond': cell['p2_unconditional_rejection_rate'],
        'elapsed': cell['elapsed_seconds'],
    }))

if __name__ == '__main__':
    main()
