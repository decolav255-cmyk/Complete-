#!/usr/bin/env python3
"""CRO Phase 1 OC runner — Protocol v1.1 confirmatory core (synthetic only)."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from seed_scheme import SEED_SCHEME_VERSION, child_rng

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "SOURCE"))
from cro.pooled_screen import RobustPooledScreenEngine  # noqa: E402

MASTER_SEED = 20261107
PROTOCOL_PATH = Path(__file__).resolve().parent / "PREREGISTRATION_v1.1.md"
SOURCE_POOL = ROOT / "SOURCE" / "cro" / "pooled_screen.py"
ALPHA = 0.05


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def wilson_interval(successes: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n <= 0:
        return (float("nan"), float("nan"))
    p = successes / n
    den = 1 + z**2 / n
    centre = p + z**2 / (2 * n)
    margin = z * math.sqrt(p * (1 - p) / n + z**2 / (4 * n**2))
    return ((centre - margin) / den, (centre + margin) / den)


def make_assignment(G: int, strata_c: np.ndarray, rec_seed: int):
    gen = np.random.Generator(np.random.PCG64(int(rec_seed)))
    cluster_t = np.zeros(G, dtype=float)
    treated_counts = []
    for st in sorted(set(strata_c.tolist())):
        members = list(np.where(strata_c == st)[0])
        nt = len(members) // 2
        sel = set(gen.choice(len(members), size=nt, replace=False).tolist())
        for j, c in enumerate(members):
            cluster_t[c] = 1.0 if j in sel else 0.0
        treated_counts.append({"stratum": int(st), "n_treated": int(nt), "n_clusters": int(len(members))})
    return cluster_t, treated_counts


def simulate_outcomes(G, n_per, clusters, strata_c, cluster_t, moderator_c, icc, tau0, beta, rng):
    sigma_u2 = icc
    sigma_e2 = 1.0 - icc
    u = rng.normal(0.0, math.sqrt(sigma_u2), size=G)
    eps = rng.normal(0.0, math.sqrt(sigma_e2), size=len(clusters))
    gamma = np.where(strata_c == 0, -0.15, 0.15)
    y = gamma[clusters] + u[clusters] + eps + cluster_t[clusters] * (tau0 + beta * moderator_c[clusters])
    return y


def naive_cr1_normal_p(engine, y, t, m, c) -> tuple[float | None, str | None]:
    try:
        t_stat, _, _ = engine.compute_cluster_robust_stat(y, t, m, c)
        # two-sided standard normal
        from math import erfc, sqrt

        p = erfc(abs(float(t_stat)) / sqrt(2.0))
        return float(p), None
    except Exception as exc:
        return None, str(exc)


def run_cell(G: int, n_per: int, icc: float, beta: float, n_rep: int, scenario: str) -> dict:
    cell_id = f"G{G}_n{n_per}_icc{icc:.2f}_beta{beta:.2f}"
    strata_c = np.array([0] * (G // 2) + [1] * (G // 2))
    N_A = math.comb(G // 2, G // 4) ** 2

    attempted = completed = rejected = not_rejected = abstained = num_fail = 0
    p1_p2_disagree = 0
    p2_rejected = p2_completed = 0
    reasons: dict[str, int] = {}

    engine = RobustPooledScreenEngine(min_clusters_threshold=8, exact_enumeration_threshold=1_000_000)

    t_start = time.time()
    for rep in range(n_rep):
        attempted += 1
        rng_mod = child_rng(scenario, cell_id, rep, "moderator")
        rng_out = child_rng(scenario, cell_id, rep, "outcomes")
        rng_asg = child_rng(scenario, cell_id, rep, "assignment")

        clusters = np.repeat(np.arange(G), n_per)
        M = rng_mod.normal(0.0, 1.0, size=G)
        M = (M - M.mean()) / M.std(ddof=0)
        rec_seed = int(rng_asg.integers(0, 2**31 - 1))
        cluster_t, treated_counts = make_assignment(G, strata_c, rec_seed)
        treatment = cluster_t[clusters]
        moderator = M[clusters]
        y = simulate_outcomes(G, n_per, clusters, strata_c, cluster_t, M, icc, 0.0, beta, rng_out)

        cfg = {
            "mechanism": "complete_cluster_randomization_within_strata",
            "strata": strata_c.tolist(),
            "randomization_record": {
                "algorithm": "numpy.PCG64_uniform_without_replacement_v1",
                "seed": rec_seed,
                "treated_counts": treated_counts,
            },
        }

        try:
            out = engine.sharp_null_test(y, treatment, moderator, clusters, assignment_config=cfg)
        except Exception as exc:
            num_fail += 1
            reasons[f"exception:{type(exc).__name__}"] = reasons.get(f"exception:{type(exc).__name__}", 0) + 1
            continue

        if out.abstained:
            abstained += 1
            key = (out.reason or "abstain")[:120]
            reasons[key] = reasons.get(key, 0) + 1
        else:
            completed += 1
            p = float(out.p_value)
            if p < ALPHA:
                rejected += 1
            else:
                not_rejected += 1

        p2, err = naive_cr1_normal_p(engine, y, treatment, moderator, clusters)
        if p2 is not None:
            p2_completed += 1
            r2 = p2 < ALPHA
            if r2:
                p2_rejected += 1
            if not out.abstained:
                r1 = float(out.p_value) < ALPHA
                if r1 != r2:
                    p1_p2_disagree += 1
        else:
            reasons[f"p2_fail:{err}"] = reasons.get(f"p2_fail:{err}", 0) + 1

    elapsed = time.time() - t_start
    uncond_rate = rejected / attempted if attempted else float("nan")
    cond_rate = rejected / completed if completed else float("nan")
    abs_rate = abstained / attempted if attempted else float("nan")
    wi_u = wilson_interval(rejected, attempted)
    wi_c = wilson_interval(rejected, completed) if completed else (float("nan"), float("nan"))
    wi_a = wilson_interval(abstained, attempted)

    return {
        "cell_id": cell_id,
        "scenario": scenario,
        "G": G,
        "cluster_size": n_per,
        "icc": icc,
        "beta": beta,
        "N_A": N_A,
        "alpha": ALPHA,
        "attempted": attempted,
        "completed": completed,
        "rejected": rejected,
        "not_rejected": not_rejected,
        "abstained": abstained,
        "numerical_failures": num_fail,
        "unconditional_rejection_rate": uncond_rate,
        "conditional_rejection_rate": cond_rate,
        "abstention_rate": abs_rate,
        "wilson95_uncond": {"low": wi_u[0], "high": wi_u[1]},
        "wilson95_cond": {"low": wi_c[0], "high": wi_c[1]},
        "wilson95_abstention": {"low": wi_a[0], "high": wi_a[1]},
        "p2_completed": p2_completed,
        "p2_rejected": p2_rejected,
        "p2_unconditional_rejection_rate": p2_rejected / attempted if attempted else float("nan"),
        "p1_p2_disagreement_among_p1_completed": p1_p2_disagree,
        "reasons": reasons,
        "elapsed_seconds": elapsed,
        "p1_method": "R23_sharp_null_test_exact_rational",
        "p2_method": "naive_CR1_normal_reference",
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", default="stage1", help="stage1 (reduced) or target")
    ap.add_argument("--sharp-reps", type=int, default=None)
    ap.add_argument("--power-reps", type=int, default=None)
    ap.add_argument("--only-G", type=int, nargs="*", default=None)
    args = ap.parse_args()

    if args.stage == "stage1":
        sharp_reps = args.sharp_reps or 200
        power_reps = args.power_reps or 100
    else:
        sharp_reps = args.sharp_reps or 5000
        power_reps = args.power_reps or 2000

    G_list = [8, 12]
    if args.only_G:
        G_list = list(args.only_G)
    n_list = [5, 20]
    icc_list = [0.05, 0.20, 0.50]
    betas_power = [0.20, 0.35]

    meta = {
        "protocol": "v1.1",
        "protocol_sha256": sha256_file(PROTOCOL_PATH),
        "source_pooled_screen_sha256": sha256_file(SOURCE_POOL),
        "master_seed": MASTER_SEED,
        "seed_scheme_version": SEED_SCHEME_VERSION,
        "seed_scheme": "SeedSequence([MASTER_SEED, SHA256_32('scenario'), SHA256_32('cell_id'), replicate, SHA256_32('role')]) -> PCG64",
        "stage": args.stage,
        "sharp_reps_per_cell": sharp_reps,
        "power_reps_per_cell": power_reps,
        "python": sys.version,
        "numpy": np.__version__,
        "platform": platform.platform(),
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "note": "Synthetic cluster-RCT OC only. G=40 P1 unavailable under v1.1.",
    }

    results = []
    # Sharp null
    for G in G_list:
        for n_per in n_list:
            for icc in icc_list:
                print(f"[sharp] G={G} n={n_per} icc={icc} reps={sharp_reps}", flush=True)
                cell = run_cell(G, n_per, icc, 0.0, sharp_reps, "sharp_null")
                results.append(cell)
                print(
                    f"  done uncond={cell['unconditional_rejection_rate']:.4f} "
                    f"cond={cell['conditional_rejection_rate']:.4f} "
                    f"abst={cell['abstention_rate']:.4f} elapsed={cell['elapsed_seconds']:.1f}s",
                    flush=True,
                )

    # Power
    for G in G_list:
        for n_per in n_list:
            for icc in icc_list:
                for beta in betas_power:
                    print(f"[power] G={G} n={n_per} icc={icc} beta={beta} reps={power_reps}", flush=True)
                    cell = run_cell(G, n_per, icc, beta, power_reps, "power")
                    results.append(cell)
                    print(
                        f"  done uncond={cell['unconditional_rejection_rate']:.4f} elapsed={cell['elapsed_seconds']:.1f}s",
                        flush=True,
                    )

    meta["finished_utc"] = datetime.now(timezone.utc).isoformat()
    out = {"meta": meta, "cells": results}
    out_path = Path(__file__).resolve().parent / f"RESULTS_{args.stage}.json"
    out_path.write_text(json.dumps(out, indent=2))
    print("Wrote", out_path)

    # CSV summary
    import csv

    csv_path = Path(__file__).resolve().parent / f"RESULTS_{args.stage}.csv"
    fields = [
        "scenario",
        "cell_id",
        "G",
        "cluster_size",
        "icc",
        "beta",
        "N_A",
        "attempted",
        "completed",
        "rejected",
        "abstained",
        "unconditional_rejection_rate",
        "conditional_rejection_rate",
        "abstention_rate",
        "p2_unconditional_rejection_rate",
        "elapsed_seconds",
    ]
    with open(csv_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        for row in results:
            w.writerow(row)
    print("Wrote", csv_path)


if __name__ == "__main__":
    main()
