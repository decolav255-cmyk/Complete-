# CRO deployment security and customer-data baseline

**Status:** Engineering baseline implemented in documentation; customer-specific approval and independent review remain mandatory. This is not a certification or legal compliance attestation.

## Data minimization and classification
- Do not send direct identifiers, credentials, secrets, or raw customer records to CRO unless the signed statement of work explicitly requires them.
- Prefer pseudonymous study, cluster, worker, and event identifiers. Keep re-identification keys with the customer.
- Treat assignment records, outcomes, moderator values, event traces, audit logs, and authorization decisions as confidential customer data.
- No production customer data in development, demo, test fixtures, issue trackers, or model prompts.

## Access and secrets
- Separate authority service identity, operator identity, analyst identity, and read-only auditor identity.
- Require MFA at the infrastructure identity provider; least privilege; time-bound operator elevation; documented joiner/mover/leaver process.
- Store authority and release private keys in separate secret stores or HSM/KMS-backed custody. Never place private keys in the ZIP, source control, container image, or ordinary logs.
- Rotate admin bearer credentials; revoke on suspected compromise. Use TLS at the ingress/reverse proxy and network allow-lists. The reference HTTP service does not itself terminate TLS.

## Retention, deletion, and backups
- Define retention periods per data class in the customer contract before ingestion.
- Provide customer export and verified deletion workflow, including replicas and backups, with deletion evidence.
- Encrypt persistent volumes and backups; restrict backup restore privileges; test restore and deletion procedures.
- Preserve required append-only audit evidence only for the agreed period; do not promise deletion of immutable records without a documented cryptographic-erasure or retention design.

## Operations and incident response
- Centralize security logs without recording bearer tokens, private keys, raw payloads, or unnecessary personal data.
- Alert on failed authorization, repeated signature failures, stale epochs, clock rollback, service restarts, backup failures, and anomalous access.
- Maintain incident severity levels, 24-hour escalation contacts, evidence preservation, customer notification timelines, containment, recovery, and post-incident review.
- Maintain tested backup/restore, rollback, key-revocation, and service-recovery runbooks.

## Pre-production customer gate
- Signed DPA/SOW and data-processing instructions; approved purpose and data categories.
- Named customer and CRO security contacts; approved hosting region and subprocessors.
- Threat model, penetration test / independent review, vulnerability remediation and acceptance.
- Access matrix, key custody record, retention/deletion schedule, backup policy, incident plan, and operational acceptance test.
- No customer data ingestion until the customer-specific gate is signed by authorized parties.
