# CRO deployment runbook — pre-production

## Services
1. PostgreSQL 16 is the selected production database target; SQLite remains the local/test backend. PostgreSQL-compatible persistence adapters and core policy, engine, authority, and receiver schemas are now included. Live integration and concurrency validation remain release gates.
2. Separately deployed authorization authority with its own state volume and Ed25519 signing key.
3. Fencing-aware idempotent receiver at each external side-effect boundary.
4. TLS ingress, secret manager, monitoring, encrypted backups, and restricted operator access supplied by the deployment environment.

## Authority bootstrap
- Provision a dedicated host/VM or isolated container environment, persistent encrypted state volume, and secret mount.
- Generate the authority Ed25519 key on the authority host with `python scripts/generate_authority_key.py --private DEPLOYMENT/secrets/authority-ed25519.pem --public DEPLOYMENT/authority-public.pem`, or inject it from KMS/HSM custody. The included helper creates a local PEM with restrictive file permissions; it is not an HSM. The container runs as UID 10001, so provision owner-only readable access for that UID (for example `chown 10001:10001` and `chmod 0400` on the host). The service refuses to start if the key is absent or group/world-readable; it does not silently create a new authority identity.
- Set `CRO_AUTHORITY_ADMIN_TOKEN` from a secret manager (minimum 32 random characters).
- Bind the service only to a private interface; publish through authenticated TLS ingress. Do not expose the reference HTTP port directly to the public internet.
- Distribute only the authority public key to CRO workers and receivers.
- Verify health endpoint, authorized token issuance, signature validation, worker revocation, expiry, replay rejection, and recovery after restart.

## Idempotent receiver
- Deploy a receiver adjacent to the downstream system; use a durable database and unique idempotency key per logical action.
- Ensure receiver persistence commits the idempotency record and accepted action atomically. Downstream adapters must propagate the same idempotency key or implement an equivalent transactional outbox/inbox pattern.
- Reject stale fencing epochs; never accept a lower epoch after a higher epoch has been observed for a candidate.
- Test retries, duplicate requests, key reuse with changed payload, stale workers, authority outage, receiver restart, and concurrent duplicate delivery.

## PostgreSQL
- Provision PostgreSQL 16 using `docker compose up -d postgres`; set `CRO_POSTGRES_PASSWORD` through a secret environment and never commit `.env`.
- On a fresh data volume, Compose mounts migrations `001_durable_outbox.sql` and `002_cro_core.sql` into the PostgreSQL initialization directory. Existing volumes do not rerun initialization scripts: apply new migrations manually using a migration identity.
- Install `DEPLOYMENT/requirements-postgresql.txt` and supply a least-privilege, TLS-verified DSN through a secret manager.
- `DurableStore(backend="postgresql", db_path=DSN)`, `AuthorityApplication(DSN, ...)`, and `IdempotentReceiver(DSN, ...)` accept PostgreSQL DSNs. Policy and engine classes accept the PostgreSQL connection adapter.
- The PostgreSQL adapter uses SERIALIZABLE transactions. Policy reservation/authorization/fenced mutation, authority issue/revoke, engine transitions and receiver acceptance retry complete database-only operations on SQLSTATE `40001` and `40P01`, with bounded attempts. Never put external side effects inside a retryable callback.
- The runtime role `cro_app` is created as a non-superuser by `postgresql/003_create_runtime_role.sh`; the bootstrap role is separate. The Compose database port is loopback-only for test use.
- Run `bash scripts/run_postgres16_gate.sh` and follow `VALIDATION/POSTGRES16_LIVE_VERIFICATION_PROCEDURE.md`. This candidate has not yet passed live PostgreSQL 16 tests, Docker build/launch, restart/restore testing, independent security review, or owner signing. Keep production authorization traffic disabled until all gates pass.

## Release signing
- Generate release-signing keypair offline with `python scripts/generate_release_key.py --private /secure/offline/cro-release-private.pem --public DEPLOYMENT/cro-release-public.pem`.
- Keep the private key under owner-controlled offline/KMS custody; never add it to the package.
- After the package manifest is finalized, sign with `PYTHONPATH=SOURCE python scripts/sign_release.py --private-key /secure/offline/cro-release-private.pem`.
- Verify with `PYTHONPATH=SOURCE python scripts/verify_release.py --public-key DEPLOYMENT/cro-release-public.pem`.
- The signature cannot be finalized by the build process without the owner's controlled private key.

## Rollback and stop conditions
- Stop authorization on clock rollback, signature failure, missing assignment provenance, unknown authority key, database integrity error, or unresolved idempotency conflict.
- Revoke affected worker credentials and authority tokens; retain incident evidence.
- Roll back application binaries only after confirming schema compatibility; do not roll back fencing epochs or append-only audit history.
- No customer data until customer-specific security, privacy, contractual, and independent-review gates are approved.


## v2.0.6 security remediation notes

- Authority and receiver must share one PostgreSQL database for pilot fencing (C1).
- Non-loopback cleartext requires CRO_AUTHORITY_ALLOW_CLEARTEXT=1 (lab only). TLS terminates at reverse proxy.
- Admin token rotation: set CRO_AUTHORITY_ADMIN_TOKEN and optional CRO_AUTHORITY_ADMIN_TOKEN_PREVIOUS (>=32 chars, distinct).
- Rate limits: CRO_AUTHORITY_UNAUTH_RATE_LIMIT (default 10/s), CRO_AUTHORITY_RATE_LIMIT (default 30/s). Proxy limits still required.
- Trusted-key revocation is available via DurableKeyHistoryManager.revoke_trusted_key_authorized.
