#!/bin/bash
set -Eeuo pipefail
: "${CRO_POSTGRES_PASSWORD:?CRO_POSTGRES_PASSWORD must be set for the runtime role}"
# Escape single quotes before embedding the secret as a SQL string literal.
escaped_password=${CRO_POSTGRES_PASSWORD//\'/\'\'}
psql --set ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" <<SQL
-- Runtime role: least privilege. Migration role remains the bootstrap superuser/owner.
DO \$\$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'cro_app') THEN
    CREATE ROLE cro_app LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT PASSWORD '$escaped_password';
  ELSE
    ALTER ROLE cro_app WITH LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT PASSWORD '$escaped_password';
  END IF;
END
\$\$;

GRANT CONNECT ON DATABASE "$POSTGRES_DB" TO cro_app;

-- Schema: usage only; no CREATE for the runtime role.
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
REVOKE CREATE ON SCHEMA public FROM cro_app;
GRANT USAGE ON SCHEMA public TO cro_app;

-- Start from a clean slate on public objects.
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM PUBLIC;
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM cro_app;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM PUBLIC;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM cro_app;

-- Mutable operational tables: SELECT + INSERT + UPDATE
GRANT SELECT, INSERT, UPDATE ON TABLE
  reservations,
  policy_clock_watermark,
  authority_state,
  durable_outbox,
  engine_states,
  receiver_epochs,
  clock_watermark
  TO cro_app;

-- durable_outbox may need DELETE for retention/cleanup under controlled ops
GRANT DELETE ON TABLE durable_outbox TO cro_app;

-- Append-only / immutable evidence: SELECT + INSERT only
GRANT SELECT, INSERT ON TABLE
  reservation_history,
  fenced_mutation_log,
  authority_audit,
  revoked_workers,
  consumed_authority_tokens,
  state_transition_log,
  receiver_effects,
  trusted_keys,
  trusted_key_history,
  verified_anchors,
  revoked_keys
  TO cro_app;

-- Sequences: usage + select only (no UPDATE privilege required for nextval under typical grants)
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO cro_app;

-- Default privileges for future objects created by the migration role:
-- do NOT auto-grant UPDATE/DELETE to cro_app.
ALTER DEFAULT PRIVILEGES FOR ROLE "$POSTGRES_USER" IN SCHEMA public
  REVOKE ALL ON TABLES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE "$POSTGRES_USER" IN SCHEMA public
  REVOKE ALL ON TABLES FROM cro_app;
ALTER DEFAULT PRIVILEGES FOR ROLE "$POSTGRES_USER" IN SCHEMA public
  GRANT SELECT, INSERT ON TABLES TO cro_app;
ALTER DEFAULT PRIVILEGES FOR ROLE "$POSTGRES_USER" IN SCHEMA public
  REVOKE ALL ON SEQUENCES FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE "$POSTGRES_USER" IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO cro_app;
SQL
