# PostgreSQL deployment foundation

PostgreSQL 16 is the selected production database target. The package includes PostgreSQL persistence paths for policy, execution, remote authorization, idempotent receiver, durable outbox, trusted-key history and checkpoint anchors/clock watermarks. SQLite remains available for local tests and legacy workflows. This is an implementation candidate, **not a production-certified release**: live PostgreSQL, concurrency, restart, backup/restore, Docker and remote deployment validation remain outstanding.

## Provisioning

1. Set distinct `CRO_POSTGRES_BOOTSTRAP_PASSWORD` and `CRO_POSTGRES_PASSWORD`, URL-encoded `CRO_AUTHORITY_DSN`, and `CRO_AUTHORITY_ADMIN_TOKEN` in the deployment secret environment; do not commit `.env`.
2. On a fresh PostgreSQL data volume, Compose runs migrations `001_durable_outbox.sql`, `002_cro_core.sql`, then `003_create_runtime_role.sh`. The script creates a non-superuser `cro_app` and grants runtime privileges. The official image runs these only during first database initialization. For existing volumes, apply migrations and role grants manually with a migration identity; do not delete a production volume to force initialization.
3. Configure a TLS-verified runtime DSN through a secret manager. Do not put credentials in source control or logs.
4. Install `DEPLOYMENT/requirements-postgresql.txt`.

## Runtime selection

- `DurableStore(backend="postgresql", db_path=DSN)` selects PostgreSQL; SQLite paths are rejected for this backend.
- `AuthorityApplication(DSN, key_path, admin_token)` uses PostgreSQL when the first argument is a `postgres://` or `postgresql://` DSN. Compose configures `CRO_AUTHORITY_DSN` accordingly.
- `IdempotentReceiver(DSN, public_key, authority_epoch_provider)` accepts the same DSN form.
- `DurablePolicyManager`, `DurableEngine`, `DurableKeyHistoryManager`, and `CheckpointMonitor` accept the `PostgresConnection` returned by `cro.postgres_compat.PostgresConnection`.

The adapter translates the qmark parameter style, SQLite BLOB fields to PostgreSQL BYTEA, and selected SQLite SQL idioms used by the existing application. Durable trusted-key history (`trace_integrity.py`) and checkpoint anchor/clock-watermark persistence (`pilot.py`) are also included in migration 002. `BEGIN IMMEDIATE` maps to PostgreSQL `SERIALIZABLE`. Append-only protections are database triggers created by migration 002, not application-only checks; startup verifies the triggers used by the policy and engine schemas and fails if they are missing. The application retries complete database-only operations on SQLSTATE `40001` and `40P01`, with a bounded retry count. Protected-mutation callbacks must not perform network, filesystem, or other non-transactional side effects. Do not use the adapter with arbitrary SQL outside the supported CRO statements without review.

## Transaction and retry contract

`PostgresDurableStore` provides `run_serializable`; policy, authority, engine, receiver, trusted-key and checkpoint DB-only operations also retry complete transactions on SQLSTATE `40001` and `40P01`, with bounded attempts. These retries are safe only because the retried operations are database-only. Protected-mutation callbacks must never perform network, filesystem or other non-transactional side effects. Live concurrency tests must still prove the behavior on PostgreSQL 16.

The PostgreSQL receiver checks `authority_state` inside the same SERIALIZABLE transaction as effect acceptance. The reference Compose deployment therefore shares one PostgreSQL database between authority and receiver. A separate receiver database requires a separately engineered atomic revocation/fencing protocol; this implementation fails closed if the authority-state table is missing.

## Required validation before production

- Run `bash scripts/run_postgres16_gate.sh` from the package root. It verifies PostgreSQL 16, runtime role privileges, migrations, live integration tests, authority service health and the complete test suite.
- The live suite covers policy reservations, concurrent single-use token consumption, lease takeover, receiver duplicate delivery, stale fencing, revocation, engine transitions, trusted-key enrollment/history, checkpoint anchor verification, append-only trigger enforcement, atomic rollback and recovery.
- Restart, connection-loss, serialization/deadlock, migration-upgrade, backup/restore and recovery tests.
- The live gate builds and launches Docker Compose; additionally verify restart, backup/restore, connection-loss recovery, key custody, DSN secrecy, TLS ingress and least-privilege database roles.
- Independent security review, TLS/network controls, customer-specific data controls and owner-controlled release signing.

Until those gates pass, keep production authorization traffic disabled. The runtime role is a non-superuser `cro_app`; the bootstrap role is separate and must not be used by the service. The Compose PostgreSQL port is published on loopback only for the test harness. See `VALIDATION/POSTGRES16_LIVE_VERIFICATION_PROCEDURE.md`, `VALIDATION/INDEPENDENT_SECURITY_REVIEW_REQUEST.md`, and `VALIDATION/OWNER_RELEASE_SIGNING_HANDOFF.md`. This candidate is not yet a final deployment release.
