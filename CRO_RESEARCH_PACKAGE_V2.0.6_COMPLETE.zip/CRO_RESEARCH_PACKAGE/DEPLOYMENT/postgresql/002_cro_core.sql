BEGIN;
-- CRO core persistence schema. Run after 001_durable_outbox.sql.
-- Append-only records are protected in the database, not only in application code.
CREATE TABLE IF NOT EXISTS reservations (
 candidate_id TEXT PRIMARY KEY, worker_id TEXT NOT NULL, epoch BIGINT NOT NULL CHECK(epoch >= 0),
 expires_at DOUBLE PRECISION NOT NULL, authorized_at DOUBLE PRECISION NOT NULL);
CREATE TABLE IF NOT EXISTS policy_clock_watermark (
 id INTEGER PRIMARY KEY CHECK(id=1), max_observed_wall DOUBLE PRECISION NOT NULL);
CREATE TABLE IF NOT EXISTS reservation_history (
 sequence BIGSERIAL PRIMARY KEY, candidate_id TEXT NOT NULL, worker_id TEXT NOT NULL,
 epoch BIGINT NOT NULL, action TEXT NOT NULL, recorded_at DOUBLE PRECISION NOT NULL);
CREATE TABLE IF NOT EXISTS fenced_mutation_log (
 sequence BIGSERIAL PRIMARY KEY, candidate_id TEXT NOT NULL, worker_id TEXT NOT NULL,
 epoch BIGINT NOT NULL, recorded_at DOUBLE PRECISION NOT NULL);
CREATE TABLE IF NOT EXISTS authority_state (
 id INTEGER PRIMARY KEY CHECK(id=1), authority_epoch BIGINT NOT NULL);
INSERT INTO authority_state(id,authority_epoch) VALUES(1,0) ON CONFLICT DO NOTHING;
CREATE TABLE IF NOT EXISTS revoked_workers (
 worker_id TEXT PRIMARY KEY, revoked_at DOUBLE PRECISION NOT NULL, reason TEXT NOT NULL,
 authority_epoch BIGINT NOT NULL);
CREATE TABLE IF NOT EXISTS authority_audit (
 sequence BIGSERIAL PRIMARY KEY, action TEXT NOT NULL, worker_id TEXT NOT NULL,
 candidate_id TEXT, authority_epoch BIGINT NOT NULL, recorded_at DOUBLE PRECISION NOT NULL, detail TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS consumed_authority_tokens (
 nonce TEXT PRIMARY KEY, consumed_at DOUBLE PRECISION NOT NULL);
CREATE TABLE IF NOT EXISTS engine_states (job_id TEXT PRIMARY KEY, state TEXT NOT NULL, reason TEXT);
CREATE TABLE IF NOT EXISTS state_transition_log (
 id BIGSERIAL PRIMARY KEY, job_id TEXT NOT NULL, from_state TEXT NOT NULL, to_state TEXT NOT NULL,
 reason TEXT, timestamp DOUBLE PRECISION NOT NULL);
CREATE TABLE IF NOT EXISTS receiver_epochs (candidate_id TEXT PRIMARY KEY, epoch BIGINT NOT NULL);
CREATE TABLE IF NOT EXISTS receiver_effects (
 idempotency_key TEXT PRIMARY KEY, candidate_id TEXT NOT NULL, epoch BIGINT NOT NULL,
 payload_hash TEXT NOT NULL, response_json TEXT NOT NULL, committed_at DOUBLE PRECISION NOT NULL);
CREATE TABLE IF NOT EXISTS trusted_keys (
 key_id TEXT PRIMARY KEY, public_bytes BYTEA NOT NULL, added_at DOUBLE PRECISION NOT NULL, enrolled_by TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS trusted_key_history (
 sequence BIGSERIAL PRIMARY KEY, key_id TEXT NOT NULL, public_sha256 TEXT NOT NULL,
 action TEXT NOT NULL, recorded_at DOUBLE PRECISION NOT NULL, enrolled_by TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS revoked_keys (
 key_id TEXT PRIMARY KEY, revoked_at DOUBLE PRECISION NOT NULL,
 revoked_by TEXT NOT NULL, reason TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS verified_anchors (
 anchor_hash TEXT PRIMARY KEY, timestamp DOUBLE PRECISION NOT NULL, signature BYTEA NOT NULL, recorded_at DOUBLE PRECISION NOT NULL);
CREATE TABLE IF NOT EXISTS clock_watermark (
 id INTEGER PRIMARY KEY CHECK(id=1), max_observed_wall DOUBLE PRECISION NOT NULL);

-- The loop below creates state_transition_log_no_update and state_transition_log_no_delete.
CREATE OR REPLACE FUNCTION cro_reject_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'CRO append-only record: mutation rejected'; END; $$;
DO $$ DECLARE t TEXT; BEGIN
 FOREACH t IN ARRAY ARRAY['reservation_history','fenced_mutation_log','authority_audit','revoked_workers','consumed_authority_tokens','state_transition_log','receiver_effects','trusted_keys','trusted_key_history','verified_anchors','revoked_keys'] LOOP
  EXECUTE format('DROP TRIGGER IF EXISTS %I ON %I', t || '_no_update', t);
  EXECUTE format('CREATE TRIGGER %I BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION cro_reject_mutation()', t || '_no_update', t);
  EXECUTE format('DROP TRIGGER IF EXISTS %I ON %I', t || '_no_delete', t);
  EXECUTE format('CREATE TRIGGER %I BEFORE DELETE ON %I FOR EACH ROW EXECUTE FUNCTION cro_reject_mutation()', t || '_no_delete', t);
 END LOOP;
END $$;
COMMIT;
