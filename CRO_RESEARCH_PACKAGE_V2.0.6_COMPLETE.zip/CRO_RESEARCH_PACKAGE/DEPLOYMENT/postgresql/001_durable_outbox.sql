-- CRO PostgreSQL durable-outbox foundation (PostgreSQL 14+)
-- Apply with a least-privilege migration role; runtime role needs SELECT/INSERT/UPDATE.
BEGIN;
CREATE TABLE IF NOT EXISTS durable_outbox (
    id TEXT PRIMARY KEY,
    payload TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at DOUBLE PRECISION NOT NULL DEFAULT EXTRACT(EPOCH FROM clock_timestamp()),
    updated_at DOUBLE PRECISION NOT NULL DEFAULT EXTRACT(EPOCH FROM clock_timestamp())
);
CREATE INDEX IF NOT EXISTS durable_outbox_status_created_idx
    ON durable_outbox(status, created_at);
COMMIT;
