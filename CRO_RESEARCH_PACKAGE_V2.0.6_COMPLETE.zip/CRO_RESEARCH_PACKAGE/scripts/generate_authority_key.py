#!/usr/bin/env python3
"""Generate authority Ed25519 keypair before mounting the private key as a secret."""
import argparse, os
from pathlib import Path
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
p=argparse.ArgumentParser(); p.add_argument('--private',required=True); p.add_argument('--public',required=True); a=p.parse_args()
priv,pub=Path(a.private),Path(a.public)
if priv.exists() or pub.exists(): raise SystemExit('Refusing to overwrite an existing key file')
key=ed25519.Ed25519PrivateKey.generate(); priv.parent.mkdir(parents=True,exist_ok=True); pub.parent.mkdir(parents=True,exist_ok=True)
fd=os.open(priv,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
with os.fdopen(fd,'wb') as f: f.write(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
pub.write_bytes(key.public_key().public_bytes(serialization.Encoding.PEM,serialization.PublicFormat.SubjectPublicKeyInfo)); os.chmod(pub,0o644)
print('Authority keypair created. Keep the private key on the authority host / in secret custody; distribute only the public key.')
