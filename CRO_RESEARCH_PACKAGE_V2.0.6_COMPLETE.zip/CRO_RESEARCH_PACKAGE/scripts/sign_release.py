#!/usr/bin/env python3
import argparse, base64, json
from pathlib import Path
from cryptography.hazmat.primitives import serialization
from cro.trace_integrity import sign_release_manifest, verify_release_manifest
p=argparse.ArgumentParser(); p.add_argument('--private-key',required=True); p.add_argument('--manifest',default='CRO_RELEASE_MANIFEST.json'); p.add_argument('--output',default='CRO_RELEASE_MANIFEST.sig.json'); a=p.parse_args()
key=serialization.load_pem_private_key(Path(a.private_key).read_bytes(),password=None)
manifest=json.loads(Path(a.manifest).read_text())
signed=sign_release_manifest(manifest,key)
Path(a.output).write_text(json.dumps({'manifest':signed['manifest'],'signature_b64':base64.b64encode(signed['signature']).decode()},indent=2)+'\n')
print(f'Detached signature written: {a.output}')
