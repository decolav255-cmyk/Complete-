#!/usr/bin/env bash
# Execute the live PostgreSQL 16 and Docker gates. Run from any directory.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT/DEPLOYMENT"

command -v docker >/dev/null || { echo "FAIL: Docker CLI not installed" >&2; exit 2; }
docker compose version >/dev/null || { echo "FAIL: Docker Compose plugin unavailable" >&2; exit 2; }
[[ -f .env ]] || { echo "FAIL: copy .env.example to .env and populate secrets" >&2; exit 2; }
[[ -s secrets/authority-ed25519.pem ]] || { echo "FAIL: provision DEPLOYMENT/secrets/authority-ed25519.pem first" >&2; exit 2; }

set -a
# shellcheck disable=SC1091
source .env
set +a
: "${CRO_TEST_POSTGRES_DSN:?set host-reachable CRO_TEST_POSTGRES_DSN in DEPLOYMENT/.env}"

mkdir -p "$ROOT/VALIDATION"
LOG="$ROOT/VALIDATION/POSTGRES16_LIVE_GATE_$(date -u +%Y%m%dT%H%M%SZ).log"
exec > >(tee "$LOG") 2>&1

echo "[1/8] Validate Compose configuration"
docker compose config --quiet

echo "[2/8] Build authority image"
docker compose build cro-authority

echo "[3/8] Start PostgreSQL 16 and wait for health"
docker compose up -d postgres
for n in $(seq 1 60); do
  if docker compose exec -T postgres pg_isready -U cro_bootstrap -d cro >/dev/null 2>&1; then break; fi
  sleep 2
done
docker compose exec -T postgres pg_isready -U cro_bootstrap -d cro

VERSION_NUM="$(docker compose exec -T postgres psql -At -U cro_bootstrap -d cro -c 'SHOW server_version_num')"
[[ "$VERSION_NUM" =~ ^[0-9]+$ ]] || { echo "FAIL: could not read PostgreSQL version"; exit 1; }
(( VERSION_NUM >= 160000 && VERSION_NUM < 170000 )) || { echo "FAIL: expected PostgreSQL 16, got server_version_num=$VERSION_NUM"; exit 1; }
echo "PASS: PostgreSQL server_version_num=$VERSION_NUM"

echo "[4/8] Verify least-privilege runtime role and required migrations"
docker compose exec -T postgres psql -v ON_ERROR_STOP=1 -U cro_bootstrap -d cro <<'SQL'
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='cro_app' AND NOT rolsuper AND NOT rolcreatedb AND NOT rolcreaterole) THEN
    RAISE EXCEPTION 'cro_app missing or has excessive role privileges';
  END IF;
  IF to_regclass('public.reservations') IS NULL OR to_regclass('public.receiver_effects') IS NULL OR to_regclass('public.durable_outbox') IS NULL OR to_regclass('public.trusted_keys') IS NULL OR to_regclass('public.verified_anchors') IS NULL THEN
    RAISE EXCEPTION 'required CRO migrations are missing';
  END IF;
  IF has_table_privilege('cro_app','public.receiver_effects','DELETE') THEN
    RAISE EXCEPTION 'cro_app unexpectedly has DELETE privilege on append-only receiver effects';
  END IF;
  IF NOT has_table_privilege('cro_app','public.durable_outbox','DELETE') THEN
    RAISE EXCEPTION 'cro_app is missing operational DELETE privilege on durable_outbox';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='state_transition_log_no_update' AND NOT tgisinternal) THEN
    RAISE EXCEPTION 'append-only transition trigger missing';
  END IF;
END $$;
SQL

echo "[5/8] Install PostgreSQL driver in the test environment"
python -m pip install -r "$ROOT/DEPLOYMENT/requirements-postgresql.txt"

echo "[6/8] Run all live PostgreSQL integration tests"
(
  cd "$ROOT/SOURCE"
  export PYTHONPATH=.
  export CRO_TEST_POSTGRES_DSN
  pytest -q -m integration tests/test_postgres_store_contract.py tests/test_postgres_full_stack_integration.py
)

echo "[7/8] Launch the authority service and verify health"
docker compose up -d cro-authority
for n in $(seq 1 30); do
  if python - <<'PY'
import urllib.request
try:
    urllib.request.urlopen('http://127.0.0.1:8765/health', timeout=2).read()
except Exception:
    raise SystemExit(1)
PY
  then break; fi
  sleep 2
done
python - <<'PY'
import json, urllib.request
with urllib.request.urlopen('http://127.0.0.1:8765/health', timeout=3) as r:
    body=json.loads(r.read())
assert r.status == 200 and body.get('status') == 'ok', body
print('PASS: CRO authority health endpoint')
PY

echo "[8/8] Run complete local suite with live database configured"
(
  cd "$ROOT/SOURCE"
  export PYTHONPATH=.
  export CRO_TEST_POSTGRES_DSN
  pytest -q
)

echo "ALL POSTGRESQL 16 LIVE GATES PASSED. Log: $LOG"
