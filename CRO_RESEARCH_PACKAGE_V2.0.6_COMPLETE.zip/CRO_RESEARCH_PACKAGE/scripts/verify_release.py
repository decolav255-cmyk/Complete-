#!/usr/bin/env python3
import argparse, base64, json
from pathlib import Path
from cryptography.hazmat.primitives import serialization
from cro.trace_integrity import verify_release_manifest
p=argparse.ArgumentParser(); p.add_argument('--public-key',required=True); p.add_argument('--signature',default='CRO_RELEASE_MANIFEST.sig.json'); p.add_argument('--package-root',default='.'); a=p.parse_args()
pub=serialization.load_pem_public_key(Path(a.public_key).read_bytes())
s=json.loads(Path(a.signature).read_text()); signed={'manifest':s['manifest'],'signature':base64.b64decode(s['signature_b64'],validate=True)}
files={k:(Path(a.package_root)/k).read_bytes() for k in signed['manifest']['files']}
if not verify_release_manifest(signed,pub,files): raise SystemExit('FAIL: signature or payload hash mismatch')
print('PASS: detached signature and every manifest file hash verified')
