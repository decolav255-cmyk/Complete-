#!/usr/bin/env python3
from cro.remote_authority import serve_from_env
serve_from_env()
