# CRO Demonstration Specification v2.0

**Single governing document for the independent demonstration track**  
**Version:** 2.0  
**Date:** 2026-11-06  
**Status:** DRAFT FOR INSPECTION — not formally frozen until explicitly approved  
**Supersedes for narrative purposes:** Demo Protocol fragments v1.0 through v1.0.3 (historical results retained; see §8)

This file is intentionally self-contained. It replaces the need to juggle multiple protocol drafts, one-pagers, and status notes for the demonstration story.

---

# Part A — Scope and posture

## A1. What this document is

A consolidated specification of:

1. What was **already run** (historical confirmatory demonstration).  
2. What those results **may and may not** be used to claim.  
3. What decision rules the system uses.  
4. What remains **predeclared but unevaluated**.  
5. How this relates to the separate **OC Protocol v1.1** track.

## A2. What this document is not

- Not partner or production validation.  
- Not a claim of financial ROI.  
- Not a completed replacement for OC Protocol v1.1 (5,000 / 2,000 targets).  
- Not formal approval of a freeze (inspection draft until you approve).

## A3. Two tracks (do not merge)

| Track | Role | State |
|-------|------|--------|
| **Demonstration (this document)** | Commercial-facing scientific story under synthetic designs | S1–S3 confirmatory history complete; narrative corrected |
| **OC Protocol v1.1** | Operating characteristics of the exact-rational sharp-null engine | **Partial only** — not completed by the demo |

Demo replicate counts (500) **do not** substitute for OC targets.

---

# Part B — System under test

## B1. D1 — Design-gated sharp-null rule (primary)

**When design-eligible** (all required):

- Mechanism: `complete_cluster_randomization_within_strata`  
- Cluster-level treatment, homogeneous within cluster  
- Strata aligned to clusters  
- Verified `randomization_record` (`numpy.PCG64_uniform_without_replacement_v1`, seed, treated counts)  

**Procedure:** R23 `sharp_null_test` (exact-rational fixed-τ = 0 path).

**Null:** sharp global null — no treatment effect for any unit under the declared randomization.

**Outcomes (must be reported separately):**

| Code | Meaning |
|------|---------|
| `AUTHORIZE_DESIGN_BASED_REJECTION_OF_SHARP_NULL` | Not abstained and \(p < 0.05\) |
| `DO_NOT_AUTHORIZE` | Abstained or \(p \ge 0.05\) |
| `ABSTAIN` | Engine abstention (record separately; do not hide inside “negative”) |

**Binding interpretation**

Authorization means only: the data are extreme under the sharp global null given the verified assignment mechanism and estimable allocation set.

It does **not** mean:

- moderation is established;  
- a beneficial “improvement” is established;  
- an estimand-specific policy effect is signed.

**When design-ineligible** (no authentic record, observational assignment, etc.):

- Do **not** fabricate a randomization record.  
- Do **not** call `sharp_null_test` as if a CRT existed.  
- Outcome: `DO_NOT_AUTHORIZE` with reason in  
  `{missing_randomization_record, observational_assignment, weak_overlap, insufficient_clusters, rank_deficient, other_abstain}`.  
- **`confounding_flag_demo` is forbidden as a primary success reason.**

## B2. Comparators (taxonomy)

| ID | Method | CRT-valid inference? | Use |
|----|--------|----------------------|-----|
| **C1_OLS_unclustered** | Pooled OLS \(Y\sim 1+T\), IID SE, normal \(p\), \(\alpha=0.05\) | **No** | Descriptive / conventional foil only |
| **C1m_cluster** | Cluster-robust main-effect test (§F) | Only after approved evaluation | Predeclared; **unevaluated** |
| **C2** | CR1 interaction \(t\), naive normal \(p\) | No (naive) | Labeled stress comparator only |
| **C3** | Ignore clustering (IID SE on similar functional) | No | Optional stress comparator |

**Retired inferential label:** “C1m” applied to the historical 31.2% S2 rate.  
**Correct label for that rate:** `C1_OLS_unclustered`.

## B3. Commercial wording constraints

**Allowed**

- Record-gated non-authorization when OLS is significant under confounding.  
- Sharp-null rejection rates under a verified CRT.  
- Explicit limitations (power, discrete \(N_A\), partial OC).

**Forbidden**

- D1 ⇒ moderation or proven beneficial improvement.  
- Historical 31.2% ⇒ valid CRT main-effect detection.  
- “Conventional statistics generally fail” (only specified naive/unclustered comparators were used).  
- Universal 5% calibration of P1 for all \(G\).  
- Low power ⇒ “no real effects exist.”  
- Demo ⇒ OC complete or production-ready.

---

# Part C — Historical confirmatory demonstration (executed)

## C1. Design summary

| Item | Value |
|------|--------|
| Demo master seed | `20261108` |
| Engine | R23 Phase 1 `sharp_null_test` |
| S1 / S2 / S3 replicates | **500 each** (confirmatory under then-current Demo Protocol v1.0.1) |
| Smoke | Separate file; not mixed with confirmatory |

**Reproducibility note:** The confirmatory run used the runner of that time. Child-seed derivation has since been specified as SHA-256–based (§G). Historical **aggregate rates** are retained; **bit-identical** row replay is not claimed under the new seed function without a new approved run.

## C2. Scenario S1 — Confounded, no randomization record

| Field | Specification |
|-------|----------------|
| Truth | No treatment effect; \(T\) from covariate threshold; outcome depends on confounder |
| Record | **None** |
| G, n, ICC | 20, 10, 0.20 |

**Results (n=500)**

| Metric | Rate | Wilson 95% CI |
|--------|------|----------------|
| C1_OLS_unclustered sig pos | 0.982 | — |
| D1 authorize | **0.000** | — |
| D1 do not authorize / abstain | 1.000 | — |
| **Primary success** (OLS sig pos ∧ D1 non-authorize ∧ reason allowed) | **0.982** | **(0.966, 0.991)** |
| Reasons | 500× `missing_randomization_record` | allowed |

**Checks passed:** never authorizes; no confounding-flag primary reason.

**Lead claim supported:** Without a verifiable randomization record, CRO does not authorize a design-based causal claim even when unclustered OLS is significant.

## C3. Scenario S2 — CRT record, pure main-effect alternative

| Field | Specification |
|-------|----------------|
| Truth | \(\tau_0 = 0.35\), \(\beta = 0\) (main effect, **not** interaction) |
| Record | Valid CRT record |
| G, n, ICC | 12, 5, 0.20 |

**Results (n=500)**

| Metric | Rate | Wilson 95% CI |
|--------|------|----------------|
| D1 `AUTHORIZE_DESIGN_BASED_REJECTION_OF_SHARP_NULL` | **0.046** | **(0.031, 0.068)** |
| D1 abstain | 0.000 | — |
| C1_OLS_unclustered sig pos | 0.312 | (0.273, 0.354) |
| Predeclared D1 demo power floor 0.20 (V3) | **NOT MET** | failure retained |

**How to read this**

- D1 answers a **sharp-null / interaction-functional** question.  
- Pure main-effect truth can yield **low** D1 authorization; that is a **limitation**, not proof the main effect is absent.  
- 31.2% is **unclustered OLS only** — not cluster-valid CRT main-effect inference (G=12).  
- Path C dual readout: D1 and OLS reported side by side; they measure different things.

## C4. Scenario S3 — CRT record, sharp null (Type I snapshot)

| Field | Specification |
|-------|----------------|
| Truth | \(\tau_0 = 0\), \(\beta = 0\) |
| Design | Same CRT machinery as S2 |

**Results (n=500)**

| Metric | Rate | Wilson 95% CI |
|--------|------|----------------|
| D1 authorize (Type I) | **0.046** | **(0.031, 0.068)** |
| D1 abstain | 0.000 | — |
| C1_OLS_unclustered sig pos | 0.072 | (0.052, 0.098) |

Not a claim of universal 5% calibration for all designs.

## C5. Predeclared value tests (historical outcome)

| ID | Intent | Outcome |
|----|--------|---------|
| **V1** | S1: OLS often sig; D1 does not authorize for record reasons | **Supported** (primary 0.982) |
| **V2** | S3: D1 Type I vs naive comparators (descriptive) | D1 ≈ 0.046; descriptive only |
| **V3** | S2: D1 rate ≥ 0.20 or CI excludes 0.05 | **Failed** (0.046; CI upper 0.068) |

V3 failure is **not** to be silently dropped or cured by retuning \(\tau_0\).

---

# Part D — Dual-readout rule (Path C)

For any CRT-eligible scenario:

1. **D1** → sharp-null rejection language only.  
2. **C1_OLS_unclustered** → may be shown as conventional foil; never as CRT-valid main-effect proof.  
3. **C1m_cluster** → only after §F evaluation exists.  
4. Side-by-side tables required; agreement not required.

---

# Part E — Optional interaction arm (S2i)

Separate future demonstration (not run under this document):

| Field | Value |
|-------|--------|
| Truth | \(\tau_0=0\), \(\beta=0.35\) |
| Design | Same CRT shell as S2 |
| Purpose | Align interaction alternative with interaction-based D1 statistic |
| Rule | Passing a power floor on S2i **does not** validate V3 on pure main-effect S2 |

---

# Part F — C1m_cluster (predeclared, unevaluated)

Nothing in this section authorizes a performance claim.

## F1. Estimand

Average treatment effect \(\tau = \mathbb{E}[Y_{ic}(1)-Y_{ic}(0)]\) under the declared CRT, individual-level outcome.

## F2. Null and threshold

\(H_0:\tau=0\), two-sided \(\alpha=0.05\).

## F3. Assignment

Same verified complete cluster randomization within strata as D1. Abstain if record fails.

## F4. Working model

\[
Y_{ic} = \alpha + \tau T_c + \sum_s \gamma_s \mathbf{1}\{s(c)=s\} + \varepsilon_{ic}
\]

Primary adjustment: **stratum fixed effects only**. No moderator, no extra covariates in the primary test.

## F5. Statistic and variance

\[
t_\tau = \frac{\hat\tau}{\widehat{\mathrm{SE}}_{\mathrm{CR1}}(\hat\tau)}
\]

Cluster-robust **CR1** SE for \(\hat\tau\). Primary \(p = 2\Phi(-|t_\tau|)\).  
Optional t-reference DF diagnostic may be reported but is not primary.

## F6. Confidence interval

Wald 95%: \(\hat\tau \pm z_{0.975}\,\widehat{\mathrm{SE}}_{\mathrm{CR1}}(\hat\tau)\).

## F7. Missing data

Complete finite \((Y,T)\) required; otherwise abstain. No primary-path imputation.

## F8. First evaluation design (if later approved)

S2-like: G=12, \(n_c=5\), ICC=0.20, \(\tau_0=0.35\), \(\beta=0\), 500 replicates, Wilson CIs, abstention rate.  
Does not re-open D1 V3 failure.

---

# Part G — Reproducibility

```text
u32(label) = first 4 bytes of SHA-256(utf-8(label)) as uint32
SeedSequence([20261108, u32(scenario), replicate_id, u32(role)]) → PCG64
```

Python `hash()` is forbidden for seed material.  
Roles: fixed strings such as `assignment`, `M`, `Y`, `C`.

---

# Part H — OC Protocol v1.1 (separate)

| Item | State |
|------|--------|
| P1 | Exact-rational sharp-null under CRT assumptions |
| P2 | Naive CR1-normal **interaction** comparator only |
| Grid | Narrowed vs early draft (G=8,12 primary; G=40 P1 unavailable without verified MC) |
| Completion | **Partial** — not finished by demo work |
| Reporting | Not universally calibrated at 5%; low power at small G is a limitation |

---

# Part I — External narrative (one page)

**Problem.** Significant regressions are often read as “the intervention worked” even without a verifiable experimental assignment record.

**Demonstration.** In synthetic confirmatory runs (n=500): under confounding with no randomization record, unclustered OLS was significant in 98.2% of replicates while CRO never authorized a design-based claim (reason: missing randomization record). Primary success 98.2% (96.6–99.1%).

**When a CRT record exists.** CRO reports sharp-null rejection/non-rejection only. Against a pure main-effect alternative, that rate was 4.6% (3.1–6.8%) — below a predeclared 20% demo floor (reported failure). Unclustered OLS was significant in 31.2% of those replicates; that is not cluster-valid CRT inference. A cluster-robust main-effect procedure is predeclared and not yet evaluated.

**Type I snapshot.** Under the randomized null, D1 authorization 4.6% (3.1–6.8%), zero abstentions.

**One sentence.** CRO is a design-gated evidence brake and sharp-null randomization test under a declared CRT—not an automatic ROI or moderation detector, and not validated by unclustered OLS p-values.

---

# Part J — File map (package)

| Path | Role |
|------|------|
| This document | `CRO_DEMONSTRATION_SPEC_v2.0.md` — single narrative/spec source |
| `DEMO/RESULTS_confirmatory_S1.json` etc. | Historical row-level outputs |
| `DEMO/REPORT_confirmatory.md` | Run report |
| `DEMO/run_demo.py` | Runner (OLS = unclustered; SHA-256 seeds) |
| `ORIGINALS/` | Frozen source zips |
| `OC/` | Separate OC track |

---

# Part K — Approval

**Inspection status:** Draft v2.0 for review.  

Formal freeze phrase (only when you intend to freeze this consolidated text):

`Approve CRO Demonstration Specification v2.0 as written.`

Until then: use as the clean reading copy; do not treat as a license for new confirmatory runs or stronger claims than §B–§C allow.

**New runs** (C1m_cluster evaluation, S2i, further OC cells) always require a **separate explicit request** after freeze.
