# CRO Demonstration Specification v2.0.4

**Version:** 2.0.4  
**Date:** 2026-11-07  
**Status:** DRAFT FOR INSPECTION — not formally frozen  
**Amends:** v2.0.3 (observed-assignment dependence in estimability)  
**Non-changes:** No new S1–S3 confirmatory runs; historical rates unchanged; V3 failure retained  

**R23 pin:** `SOURCE/cro/pooled_screen.py`  
SHA-256 `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`

---

## 1. Why v2.0.4 exists

Review of v2.0.3 correctly noted that in `exact_rank_and_fit` the scores \(z1\) use:

```text
rt = observed_treatment - X(A) * bt
z1_c = sum_i in c  weights_i(A) * rt_i
```

So the variance polynomial’s \(\sum z1^2\) term depends on:

- the **candidate** allocation \(A\) (through \(X(A)\), weights), and  
- the **observed** assignment \(T_{\mathrm{obs}}\), and  
- pretreatment \(M\),  

and **not** on outcomes \(Y\).

Therefore the retained set need not be a function of \((A, M)\) alone; it can depend on \(T_{\mathrm{obs}}\). The v2.0.2/v2.0.3 “design + pretreatment only” wording was **too strong** if taken as a theorem about the pinned engine.

---

## 2. What is established vs not established

### 2.1 Established (source + probes)

| Fact | Status |
|------|--------|
| Rank / invertibility of \(H(A) = X(A)^\top X(A)\) | Depends on candidate \(A\) and \(M\) only |
| Outcome-dependent `vm=0` at \(\tau=0\) | Whole-test **ABSTAIN**, not silent reduced-universe \(p\) |
| Silent \(Y\)-thinned success-path \(p\) in probes | Not demonstrated |
| Source hash | Matches package file |
| Balanced G=8 probe (12 distinct CRT assignments, fixed \(M\), fixed random \(Y\)) | Always `valid=36=total` (full universe); retention **invariant** across those observed assignments |

### 2.2 Not established

| Claim | Status |
|-------|--------|
| For **all** designs, \(\mathcal{A}_{\mathrm{ret}}\) is invariant to \(T_{\mathrm{obs}}\) | **Not established** |
| General theorem: p-value is exactly uniform under sharp null for every design the engine accepts | **Not established** |
| Historical S2/S3 4.6% rates are certified exact conditional randomization rates under a design-only retained set | **Not established** — remain **historical engine outputs** |

### 2.3 Statistical point (accepted)

If membership of candidate allocations in the ranked set depends on the realized \(T_{\mathrm{obs}}\) in a nontrivial way, one cannot automatically quote the elementary “uniform over a pretreatment-fixed \(\mathcal{A}_{\mathrm{ret}}\)” argument without a further proof of the conditional law under the sharp null.

That is a **justification gap**, not a demonstration that the CRO architecture or historical S1 result is false.

---

## 3. How D1 p-values may be described (normative)

Until either (i) invariance of \(\mathcal{A}_{\mathrm{ret}}\) to \(T_{\mathrm{obs}}\) is proved or verified for the design class in use, or (ii) retention is forced to an assignment-independent predicate (below), or (iii) a different exactness proof is supplied:

**Allowed description of a returned D1 p-value**

> Exact enumeration p-value as implemented by pinned R23 fixed-τ `sharp_null_test`: fraction of the engine’s retained allocations whose interaction statistic is at least as extreme as observed, using Fraction ranking at \(\tau=0\).

**Not allowed without further work**

> “Proven design-only conditional exact randomization test for every CRT design.”

**When `valid_allocation_count = allocation_space_size` and the test does not abstain**

The engine ranked the **full design universe**. For that replicate, retention did not remove allocations. Exactness then reduces to the standard complete-randomization enumeration argument under the sharp null **for that full universe**, subject to the usual assumptions of the declared design and the interaction statistic (still ≠ moderation claim).

Demo S2/S3 use \(G=12\) (\(N_A=400\)) or similar CRT margins; historical runs did not log per-replicate `valid` vs `total`. Therefore historical aggregates stay:

> Historical confirmatory engine outputs (n=500). Not retro-certified from this specification alone.

---

## 4. Path to close the gap (choose one; not executed here)

### Option A — Verify invariance on the evaluation design class

For the S2/S3 design (or a declared class), show analytically or by exhaustive check that \(\mathcal{A}_{\mathrm{ret}}(T_{\mathrm{obs}}, M) = \mathcal{A}\) (or a common set) for every admissible \(T_{\mathrm{obs}}\).

### Option B — Assignment-independent retention predicate

Implementation change (future, separately approved): retain allocation \(A\) iff \(H(A)\) is invertible (and engine minima hold); do **not** exclude candidates using \(T_{\mathrm{obs}}\)-dependent \(z1\) guards. If observed assignment fails its own rank/variance requirements → **ABSTAIN**.

### Option C — Prove exactness under \(T_{\mathrm{obs}}\)-dependent retention

Supply a formal argument that the engine’s ranking still yields a valid conditional p-value under the sharp null despite retention depending on \(T_{\mathrm{obs}}\).

No S1–S3 rate retuning attaches to A–C.

---

## 5. Unchanged substance (carried forward)

- States: NOT_ELIGIBLE | ABSTAIN | DO_NOT_AUTHORIZE | AUTHORIZE  
- S1 lead claim and 0.982 primary success  
- S2/S3 AUTHORIZE 0.046 (Wilson 0.031–0.068); V3 **FAILED** (\(\hat p \ge 0.20\) only)  
- C1_OLS_unclustered vs C1m_cluster predeclared/unevaluated  
- Commercial limits on “improvement” / moderation  
- Demo ≠ OC v1.1 completion  
- Seed/draw specification from v2.0.2+; pin NumPy/Python on future runs  

---

## 6. Approval

Formal freeze only when intended:

`Approve CRO Demonstration Specification v2.0.4 as written.`

Until then: inspection draft. Prefer closing §4 Option A or B before any stronger exactness marketing language.
