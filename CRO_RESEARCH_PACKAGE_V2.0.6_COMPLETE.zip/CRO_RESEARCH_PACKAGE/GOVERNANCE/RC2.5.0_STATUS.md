# RC2.5.0 — deployment-hardening candidate status

**Date:** 2026-11-09  
**Status:** Engineering candidate updated; local test suite passes. Not a production release, not an independent security certification, and not owner-signed.

## Governance

The project owner is the sole approval authority. The frozen v2.0.5 scientific specification remains unchanged.

## Workstream status

| Workstream | Status |
|---|---|
| v2.0.5 specification and approval | APPROVED / FROZEN; preserved unchanged |
| R23 source | Exact approved source pin preserved |
| Historical scientific evidence | Preserved; no confirmatory rerun or result alteration |
| Local SQLite authorization, lifecycle, fencing, trace integrity | Implemented; existing tests retained |
| Remote authorization authority | Reference service implemented and unit-tested; Docker deployment prepared; not deployed or independently operated yet |
| Idempotent side-effect receiver | Reference receiver implemented and tested for signature, live authority epoch, stale epoch, retries, and idempotency conflicts; downstream/customer integration not performed |
| PostgreSQL SERIALIZABLE | Optional SERIALIZABLE durable-outbox primitive implemented; not a full SQLite-to-PostgreSQL application backend; no live PostgreSQL integration test executed |
| Detached release signing | Owner-controlled key-generation, signing, and verification workflow implemented; no owner key or detached signature supplied |
| Customer-data controls | Security/data-control baseline and runbook prepared; customer-specific controls, contracts, hosting controls, and approval not completed |
| Independent security / technical review | NOT PERFORMED; must be independent of implementation |
| Production deployment | NOT PERFORMED; infrastructure, credentials, TLS ingress, monitoring, backup and rollback need owner-controlled environment |
| Paid pilot / customer-data ingestion | BLOCKED pending owner approval, independent review, customer-specific controls, deployment acceptance and legal terms |
| Exploratory outreach | Permitted within existing claims boundaries |

## PostgreSQL limitation

`PostgresDurableStore` uses PostgreSQL SERIALIZABLE transactions for the durable outbox primitive. The rest of the existing application still contains SQLite-specific schema and transaction paths. Full PostgreSQL support must not be claimed until migrations and integration tests cover policy, authority, lifecycle, fencing, and recovery paths against a real PostgreSQL service.

## Seven-gate interpretation

The local suite validates the implemented local and reference-service paths only. It does not establish independent remote operation, downstream system integration, full PostgreSQL application compatibility, project-owned signature issuance, independent security review, or customer-specific production acceptance.

## Frozen-science boundary

The approved v2.0.5 specification, approval record, historical S1–S3 evidence, Option A records, and pinned R23 source remain unchanged. V3 remains failed; OC Protocol v1.1 remains partial. New customer pilot results must not be pooled into historical evidence without a separate predeclared protocol.
