# RC2.5.0 remediation specification — handoff and unresolved status

**Status:** Historical handoff dated 2026-11-08. The architecture remains a draft, is not a formally approved normative specification, and is not independently validated. The complete v1.8 conversation draft is not embedded here as an approved specification. For subsequent local implementation work, see `RC2.5.0_STATUS.md` and the 2026-11-09 validation report.

## Project governance

The project owner is the sole approval authority. No committee exists. Any previous requirement for unanimous committee approval is superseded by explicit project-owner approval.

## Architecture areas specified in the v1.8 draft

1. **Authorization and revocation:** one independent authority serializes revocation and authorization; atomic authorization reservation; maximum lease TTL 60 seconds; new reservations require online authority interaction; no stale epoch caching.
2. **Cryptographic binding:** event hash and signature; dataset/protocol binding; audit-event hash; checkpoint hash/signature; detached release-manifest signature; canonical serialization, domain separation, length framing, raw 32-byte hashes, and 64-byte Ed25519 signatures.
3. **Execution state machine:** terminal states `DECISION_RELEASED`, `MARK_FAILED`, `REJECTED`; `AUDIT_COMMITTED` is non-terminal; explicit `RECOVERY_PENDING` paths; transient failures are not prematurely made permanent.
4. **Worker fencing:** distinct acquisition, renewal, takeover, and transition operations; conditional SQL updates; external side effects require a fencing-aware or durable idempotent receiver.
5. **Atomic local commitment:** one Serializable primary-database transaction; asynchronous outbox handled separately; disclose `anchored: false` if release precedes independently verified checkpoint anchoring.
6. **Audit checkpoints:** maximum 60-minute unanchored interval; monitor failure and clock rollback block release.
7. **R23 binding:** verify raw source bytes against SHA-256 `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`; extract actual `validity_classification` values from source/tests before finalizing adapter mappings; malformed or contradictory results are operational failures.

## Required implementation evidence

- Formal owner approval of a finalized normative specification.
- Isolated baseline verification record; preserve the original archive unchanged.
- Implementation in a separate working tree.
- Seven release gates with executable positive, negative, concurrency, crash/restart, revocation-race, and adversarial tests.
- Reproducible logs, database-state evidence, raw outputs, hashes, and signed release manifest.
- Independent technical/security review.

## Explicit non-claims

No hardware attestation, guaranteed remote-client integrity, exactly-once physical execution, or universal protection against a fully compromised host or independent service. An `AUTHORIZE` result remains limited to the declared sharp-null test under an eligible, verified design; it does not prove ROI, beneficial effect, practical significance, safety, compliance, deployment suitability, or external validity.

## Status at time of handoff (2026-11-08)

At the time this handoff was written, no RC2.5.0 implementation or seven-gate execution had occurred. The subsequent local implementation candidate and its limitations are documented in `RC2.5.0_STATUS.md`; this handoff remains a draft architecture record, not evidence of complete implementation or independent validation.
