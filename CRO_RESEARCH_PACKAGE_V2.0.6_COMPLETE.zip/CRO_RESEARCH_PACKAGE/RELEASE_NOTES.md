# CRO Research Package v2.0.5 — deployment-hardening candidate

**Date:** 2026-11-09  
**Scientific baseline:** CRO Demonstration Specification v2.0.5 APPROVED AND FROZEN (unchanged).

## New engineering work
- Added separately deployable Ed25519 authorization authority reference service, with durable state, lease issuance, worker revocation, authority epoch endpoint, bounded requests, and Docker deployment reference.
- Added a fencing-aware idempotent receiver reference implementation with signature verification, live authority-epoch checking, monotonic fencing epochs, durable acceptance records, retry deduplication, and conflicting-key rejection.
- Added optional PostgreSQL SERIALIZABLE durable-outbox transaction primitive. This does not yet constitute full PostgreSQL support for all SQLite-backed application components.
- Added project-owner detached Ed25519 release-key generation, manifest signing, and signature verification scripts. No private key or owner signature is included.
- Added customer-data security baseline and deployment/rollback runbook.

## Verification
- Combined source test suite: 68 passed.
- New deployment-hardening tests: 4 passed.
- R23 source pin remains unchanged at SHA-256 `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`.
- PostgreSQL integration against a live PostgreSQL server was not run; the optional backend is currently limited to the durable outbox primitive.

## Remaining external/owner gates
- Deploy the authority service into owner-controlled infrastructure and configure TLS ingress, secret custody, monitoring, backups, and restore.
- Integrate the receiver with each real downstream side-effect system.
- Complete PostgreSQL migrations and full application integration tests if PostgreSQL is the selected production backend.
- Owner generates and retains the release signing key and signs the final manifest.
- Independent technical/security review of the exact release candidate.
- Complete customer-specific data processing, retention, deletion, access, incident response, contractual, and hosting approvals.

## Frozen-science boundary
No v2.0.5 scientific specification, approval record, historical S1–S3 result, Option A result, or R23 source byte was modified. V3 remains failed and OC Protocol v1.1 remains partial.


## PostgreSQL deployment preparation — phase 1 (2026-11-09)

- Selected PostgreSQL 16 as the production database target.
- Added Compose PostgreSQL service, durable-outbox migration, SERIALIZABLE transaction wrapper, and bounded retries for serialization failures/deadlocks.
- Added driver-independent transaction tests and an opt-in live PostgreSQL integration test.
- Verification: 72 passed, 1 skipped (live PostgreSQL test; no server/DSN available).
- Important: policy, engine, remote authority, and receiver persistence remain SQLite-specific. This phase does not establish full PostgreSQL application support or production readiness.

## PostgreSQL application migration — phase 2 (2026-11-09)

- Added a psycopg connection adapter and PostgreSQL paths for the durable store, policy manager, execution engine, remote authority, and idempotent receiver.
- Added PostgreSQL core schema migration `DEPLOYMENT/postgresql/002_cro_core.sql`, including database-enforced append-only triggers.
- Updated Compose and deployment guidance to configure the remote authority against PostgreSQL.
- Added opt-in full-stack PostgreSQL integration coverage.
- Verification: **74 passed, 2 skipped**; Python compilation passed. Both skips require a live PostgreSQL DSN.
- No psycopg, PostgreSQL server/client, or Docker executable was available; no live database, migration, Compose, concurrency, restore, or deployment verification occurred.
- Status remains `CANDIDATE_NOT_PRODUCTION_RELEASE`; production authorization traffic must remain disabled until live integration and operational gates pass.

## PostgreSQL application hardening — phase 3 (2026-11-09)

- Added bounded whole-operation retries for PostgreSQL serialization failures (`40001`) and deadlocks (`40P01`) to policy authorization/reservation/fenced mutation, authority issue/revoke, engine transitions, and idempotent receiver acceptance. Retry callbacks are restricted to database-only work; non-retryable SQLSTATEs propagate.
- Moved the PostgreSQL receiver's authority-epoch check inside the same SERIALIZABLE transaction as the accepted idempotent effect, closing the previous preflight time-of-check/time-of-use gap in the reference shared-database deployment.
- Aligned engine and consumed-token append-only trigger checks with the names produced by migration 002; added a local contract test to prevent drift.
- Explicitly close PostgreSQL connections created by authority bootstrap and receiver paths.
- Changed the Compose bootstrap to use a separate bootstrap database role and create a non-superuser `cro_app` runtime role. Published PostgreSQL only on loopback port 55432 for the live test procedure.
- Added PostgreSQL 16 live tests for full-stack operation, signed-token single-use races, concurrent lease takeover/fencing, concurrent duplicate delivery, rollback, restart recovery, revocation, and append-only enforcement.
- Added `scripts/run_postgres16_gate.sh` and the independent-review/signing handoff documents.
- Local verification: **78 passed, 7 skipped**. The seven skipped tests are live PostgreSQL integration tests; no PostgreSQL server or Docker is available in this environment. Shell syntax, Python compilation, package checksums and R23 source pin are separately recorded in the phase 3 audit.
- Status remains `CANDIDATE_PENDING_LIVE_POSTGRES16_AND_EXTERNAL_GATES`; this is not a production release.
