# CRO Demonstration Specification v2.0.3

**Version:** 2.0.3  
**Date:** 2026-11-06  
**Status:** DRAFT FOR INSPECTION — not formally frozen  
**Amends:** v2.0.2 (implementation conformity for estimability only)  
**Non-changes:** No new confirmatory simulations; historical rates unchanged; V3 failure retained  

**R23 pin (re-verified):** `SOURCE/cro/pooled_screen.py`  
SHA-256 `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`

---

## 1. Purpose of this revision

v2.0.2 stated a design-only retained set mathematically. Review required a **source-level** determination of whether pinned R23 actually enforces that rule, and what to claim about historical 4.6% rates until then.

This document records the audit result and tightens claims accordingly.

---

## 2. Source audit of allocation exclusion (pinned R23)

### 2.1 Code path (fixed-τ / `sharp_null_test`)

For each allocation \(A\) in the full design universe \(\mathcal{A}\):

1. Build \(X^{(A)}\) with columns \((1,T^{(A)},M,T^{(A)}M)\).  
2. Invert Gram matrix \(H^{(A)}=(X^{(A)})^\top X^{(A)}\) in exact rational arithmetic.  
3. On success, build variance polynomial coefficients from cluster scores \(z0,z1\).  
4. If `not any(vpoly)`: exclude allocation (exception → `excluded` list).  
5. After building `fits`, for each retained fit at \(\tau=0\): if variance evaluation `vm <= 0`, **raise** (whole-test failure → ABSTAIN), not a silent reduced-universe p-value.

### 2.2 What depends only on assignment + pretreatment

| Step | Depends on \(Y\)? | Role |
|------|-------------------|------|
| Construction of \(X^{(A)}\) / \(H^{(A)}\) | **No** (uses \(T^{(A)}\), \(M\)) | Rank / invertibility |
| Invertibility failure | **No** | Per-allocation **exclude** |
| Scores \(z1\) (treatment residual path) | **No** | Design/pretreatment |
| Scores \(z0\) (outcome residual path) | **Yes** | Enters variance poly |

### 2.3 Critical behavioral facts

**A. Per-allocation exclusion in the `fits` loop**  
Driven by rank failure of \(H^{(A)}\) (design/pretreatment) or “variance polynomial identically zero.” Identically zero requires all variance coefficients zero, including the pure \(z1\) term \(\sum z1^2\). If \(\sum z1^2>0\), the polynomial is not identically zero regardless of \(Y\). Thus **silent per-allocation drops that change \(\mathcal{A}_{\mathrm{ret}}\) solely due to \(Y\)** are not the intended path for rank-based exclusion.

**B. Whole-test ABSTAIN on `vm <= 0` at \(\tau=0\)**  
At \(\tau=0\), `vm = c\sum z0^2` with \(c>0\). So `vm <= 0` means `vm = 0` means **all cluster outcome scores \(z0=0\)**. That **can depend on \(Y\)**. Empirical probe on the pinned engine (G=8, full design \(N_A=36\)): constant / zero / pure-\(T\) outcomes caused **ABSTAIN** (“observed allocation is not exactly full rank / variance estimable”); generic random outcomes retained **valid=36=total** with a p-value.

**C. What the engine does *not* do in the fixed-τ success path**  
When it returns a p-value, the post-`fits` guard has not raised. For the balanced demo designs probed, success path used the **full** design count (`valid_allocation_count = allocation_space_size`). The dangerous pattern “\(Y\)-dependent reduced denominator with a returned p” was **not observed** in those probes; \(Y\)-dependence manifested as **ABSTAIN** instead.

### 2.4 Audit conclusion (plain)

| Question | Answer |
|----------|--------|
| Does rank-based exclusion match design-only \(E(A)\)? | **Yes** |
| Can \(Y\) affect engine behavior? | **Yes** — via variance-at-zero / observed estimability → **ABSTAIN** |
| Does pinned fixed-τ path silently return p over a \(Y\)-dependent reduced universe in probes? | **Not observed**; success path used full \(|\mathcal{A}|\) in probes |
| Can historical 4.6% be retroactively certified as exact conditional p-values solely from v2.0.2 text? | **No** — treat as **historical engine outputs** until per-replicate retained-set logging proves design-only retention |

---

## 3. Specification rules (normative going forward)

### 3.1 Claim discipline for D1 p-values

A returned p-value may be called an **exact conditional randomization p-value under design-only retention** only if the implementation (or a verified wrapper) guarantees:

1. \(\mathcal{A}_{\mathrm{ret}}\) is fixed by assignment + pretreatment only; and  
2. \(A_{\mathrm{obs}}\in\mathcal{A}_{\mathrm{ret}}\); and  
3. No \(Y\)-dependent alteration of \(\mathcal{A}_{\mathrm{ret}}\) occurred.

### 3.2 Mandatory whole-test ABSTAIN

If any outcome-dependent guard would change the retained set or invalidate observed estimability, the replicate’s primary state is **ABSTAIN**, not AUTHORIZE / DO_NOT_AUTHORIZE.

Pinned R23 already converts several of those guards into exceptions (ABSTAIN). Future wrappers must not catch those exceptions and recompute a p-value on a reduced set.

### 3.3 Historical S2/S3 4.6% rates

**Labeling required in all external and internal summaries:**

> Historical confirmatory engine outputs under pinned R23 (n=500). Not retroactively certified as design-only exact conditional p-values solely by Specification v2.0.2/v2.0.3 without retained-set verification logs.

Numerical values **unchanged**: AUTHORIZE rates 0.046 (Wilson 0.031–0.068); V3 **FAILED**.

### 3.4 States (unchanged partition from v2.0.2)

NOT_ELIGIBLE | ABSTAIN | DO_NOT_AUTHORIZE | AUTHORIZE — mutually exclusive as in v2.0.2.

---

## 4. Reproducibility environment pin

In addition to §G seed/draw rules from v2.0.2:

| Component | Pin |
|-----------|-----|
| `pooled_screen.py` | SHA-256 `92157a54…09d6` |
| NumPy | Record version in any future run’s metadata (`np.__version__`) |
| Python | Record `sys.version` |
| Claim limit | Bit-identical reproduction **not** guaranteed across unpinned NumPy/Python builds; API-level procedure is pinned |

Historical run metadata may be incomplete; do not over-claim cross-environment replay.

---

## 5. What remains from v2.0.2 (accepted)

- NOT_ELIGIBLE vs ABSTAIN partition  
- D1 interaction statistic vs sharp null vs moderation  
- V3 sole criterion \(\hat p \ge 0.20\); failure retained  
- C1_OLS_unclustered vs C1m_cluster predeclaration  
- S2i does not cure V3  
- S1 primary success 0.982 narrative  

---

## 6. Next technical step (not a simulation of S1–S3)

Optional verification work (only if requested): instrument pinned R23 to log `|A|`, `|A_ret|`, and exclusion reasons per replicate on a **held-out probe grid**, or add a design-only prefilter before outcome-using variance checks. **No retuning of thresholds or historical rates.**

---

## 7. Approval

Formal freeze phrase (only when intended):

`Approve CRO Demonstration Specification v2.0.3 as written.`

Until then: inspection draft. Architecture retained; exactness claim limited as in §3.3.
