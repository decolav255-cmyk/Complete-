#!/usr/bin/env python3
"""CRO Demo runner (v1.0.1 confirmatory historical + v1.0.3 labeling).

C1 via ols_T_pvalue = C1_OLS_unclustered only (NOT CRT-valid).
C1m_cluster is predeclared in DEMO_PROTOCOL_v1.0.3.md and is NOT evaluated here.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "SOURCE"))
from cro.pooled_screen import RobustPooledScreenEngine

DEMO_SEED = 20261108
PROTOCOL = Path(__file__).resolve().parent / "DEMO_PROTOCOL_v1.0.1.md"
ALPHA = 0.05


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()


def wilson(successes: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n <= 0:
        return (float("nan"), float("nan"))
    p = successes / n
    den = 1 + z * z / n
    centre = p + z * z / (2 * n)
    margin = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (centre - margin) / den, (centre + margin) / den


def _stable_u32(s: str) -> int:
    """Stable 32-bit digest for SeedSequence (not Python's randomized hash())."""
    return int.from_bytes(hashlib.sha256(s.encode("utf-8")).digest()[:4], "big")


def child_rng(scenario: str, rep: int, role: str) -> np.random.Generator:
    ss = np.random.SeedSequence(
        [DEMO_SEED, _stable_u32(scenario), int(rep), _stable_u32(role)]
    )
    return np.random.Generator(np.random.PCG64(ss))


def ols_T_pvalue(y, t) -> tuple[float, float]:
    """Return (beta_hat, two-sided normal p) for pooled Y ~ 1 + T.

    NOT cluster-robust / NOT CRT-valid inference. Commercial label: C1_OLS_unclustered.
    """
    y = np.asarray(y, float)
    t = np.asarray(t, float)
    n = len(y)
    x = np.column_stack([np.ones(n), t])
    try:
        beta, _, _, _ = np.linalg.lstsq(x, y, rcond=None)
        resid = y - x @ beta
        dof = max(n - 2, 1)
        s2 = float(resid @ resid) / dof
        xtx_inv = np.linalg.inv(x.T @ x)
        se = math.sqrt(max(s2 * xtx_inv[1, 1], 0.0))
        if se == 0:
            return float(beta[1]), 1.0
        z = float(beta[1]) / se
        p = math.erfc(abs(z) / math.sqrt(2.0))
        return float(beta[1]), float(p)
    except Exception:
        return float("nan"), float("nan")




def c1m_cluster_test(y, t, clusters, strata_c, alpha=0.05):
    """Predeclared C1m_cluster: OLS Y ~ 1 + T + stratum FE, CR1 SE for T, normal p.

    Returns dict with tau_hat, se, t_stat, p_value, sig, abstain, reason.
    """
    y = np.asarray(y, float)
    t = np.asarray(t, float)
    clusters = np.asarray(clusters)
    strata_c = np.asarray(strata_c)
    n = len(y)
    if n == 0 or not np.isfinite(y).all() or not np.isfinite(t).all():
        return {"tau_hat": None, "se": None, "t_stat": None, "p_value": None,
                "sig": False, "abstain": True, "reason": "non_finite_or_empty"}
    # Map individual strata from cluster strata
    # clusters are ids 0..G-1; strata_c is length G
    try:
        uniq_c = []
        for c in clusters:
            if c not in uniq_c:
                uniq_c.append(int(c))
        G = len(uniq_c)
        if G < 4:
            return {"tau_hat": None, "se": None, "t_stat": None, "p_value": None,
                    "sig": False, "abstain": True, "reason": "insufficient_clusters"}
        st_by_c = {int(c): int(strata_c[int(c)]) for c in uniq_c}
        st_ind = np.array([st_by_c[int(c)] for c in clusters])
        # Dummy strata (drop first)
        levels = sorted(set(st_ind.tolist()))
        X_cols = [np.ones(n), t]
        for lev in levels[1:]:
            X_cols.append((st_ind == lev).astype(float))
        X = np.column_stack(X_cols)
        # OLS
        beta, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
        resid = y - X @ beta
        # CR1 for coefficient index 1 (T)
        # meat = sum_c X_c' e_c e_c' X_c
        k = X.shape[1]
        meat = np.zeros((k, k))
        for c in uniq_c:
            idx = np.where(clusters == c)[0]
            Xc = X[idx]
            ec = resid[idx]
            score = Xc.T @ ec  # k-vector
            meat += np.outer(score, score)
        try:
            xtx_inv = np.linalg.inv(X.T @ X)
        except np.linalg.LinAlgError:
            return {"tau_hat": None, "se": None, "t_stat": None, "p_value": None,
                    "sig": False, "abstain": True, "reason": "rank_deficient"}
        # CR1 factor G/(G-1) * (n-1)/(n-k)
        df_c = G / max(G - 1, 1)
        df_n = (n - 1) / max(n - k, 1)
        vcov = df_c * df_n * (xtx_inv @ meat @ xtx_inv)
        var_t = float(vcov[1, 1])
        if not np.isfinite(var_t) or var_t <= 0:
            return {"tau_hat": float(beta[1]), "se": None, "t_stat": None, "p_value": None,
                    "sig": False, "abstain": True, "reason": "non_positive_cr1_variance"}
        se = math.sqrt(var_t)
        t_stat = float(beta[1]) / se
        p = math.erfc(abs(t_stat) / math.sqrt(2.0))
        return {
            "tau_hat": float(beta[1]),
            "se": se,
            "t_stat": t_stat,
            "p_value": float(p),
            "ci_low": float(beta[1] - 1.96 * se),
            "ci_high": float(beta[1] + 1.96 * se),
            "sig": bool(p < alpha),
            "abstain": False,
            "reason": "OK",
        }
    except Exception as exc:
        return {"tau_hat": None, "se": None, "t_stat": None, "p_value": None,
                "sig": False, "abstain": True, "reason": f"error:{exc}"}


def make_crt_assignment(G: int, rec_seed: int):
    strata_c = np.array([0] * (G // 2) + [1] * (G // 2))
    gen = np.random.Generator(np.random.PCG64(int(rec_seed)))
    cluster_t = np.zeros(G)
    treated_counts = []
    for st in (0, 1):
        members = list(np.where(strata_c == st)[0])
        nt = len(members) // 2
        sel = set(gen.choice(len(members), size=nt, replace=False).tolist())
        for j, c in enumerate(members):
            cluster_t[c] = 1.0 if j in sel else 0.0
        treated_counts.append(
            {"stratum": int(st), "n_treated": int(nt), "n_clusters": int(len(members))}
        )
    cfg = {
        "mechanism": "complete_cluster_randomization_within_strata",
        "strata": strata_c.tolist(),
        "randomization_record": {
            "algorithm": "numpy.PCG64_uniform_without_replacement_v1",
            "seed": int(rec_seed),
            "treated_counts": treated_counts,
        },
    }
    return cluster_t, strata_c, cfg


def d1_design_eligible(engine, y, t, m, clusters, cfg) -> dict:
    out = engine.sharp_null_test(y, t, m, clusters, assignment_config=cfg)
    if out.abstained:
        return {
            "D1_authorize_sharp_null_rejection": False,
            "D1_do_not_authorize": True,
            "D1_abstain": True,
            "reason": out.reason or "abstain",
            "p_value": out.p_value,
        }
    p = float(out.p_value)
    auth = p < ALPHA
    return {
        "D1_authorize_sharp_null_rejection": auth,
        "D1_do_not_authorize": not auth,
        "D1_abstain": False,
        "reason": "OK_tested",
        "p_value": p,
    }


def d1_design_ineligible() -> dict:
    """S1 path: no sharp_null_test call; record-driven non-authorization."""
    return {
        "D1_authorize_sharp_null_rejection": False,
        "D1_do_not_authorize": True,
        "D1_abstain": True,
        "reason": "missing_randomization_record",
        "p_value": None,
    }


def simulate_Y(G, n_per, clusters, strata_c, cluster_t, M_c, icc, tau0, beta, delta, C_c, rng):
    sigma_u2 = icc
    sigma_e2 = 1.0 - icc
    u = rng.normal(0.0, math.sqrt(sigma_u2), size=G)
    eps = rng.normal(0.0, math.sqrt(sigma_e2), size=len(clusters))
    gamma = np.where(strata_c == 0, -0.15, 0.15)
    conf = delta * C_c[clusters] if delta else 0.0
    y = (
        gamma[clusters]
        + u[clusters]
        + eps
        + cluster_t[clusters] * (tau0 + beta * M_c[clusters])
        + conf
    )
    return y


def run_S1(rep: int, engine) -> dict:
    G, n_per, icc = 20, 10, 0.20
    rng_c = child_rng("S1", rep, "C")
    rng_m = child_rng("S1", rep, "M")
    rng_y = child_rng("S1", rep, "Y")
    clusters = np.repeat(np.arange(G), n_per)
    strata_c = np.array([0] * (G // 2) + [1] * (G // 2))
    C_c = rng_c.normal(0, 1, size=G)
    cluster_t = (C_c > 0).astype(float)  # observational
    M_c = rng_m.normal(0, 1, size=G)
    M_c = (M_c - M_c.mean()) / M_c.std(ddof=0)
    y = simulate_Y(G, n_per, clusters, strata_c, cluster_t, M_c, icc, 0.0, 0.0, 0.6, C_c, rng_y)
    t = cluster_t[clusters]
    m = M_c[clusters]
    beta_hat, p_c1 = ols_T_pvalue(y, t)
    c1_sig_pos = (beta_hat > 0) and (p_c1 < ALPHA)
    d1 = d1_design_ineligible()
    # Guard: never call sharp_null without record
    primary = (
        c1_sig_pos
        and d1["D1_do_not_authorize"]
        and d1["reason"] in ("missing_randomization_record", "observational_assignment")
    )
    return {
        "scenario": "S1",
        "rep": rep,
        "C1_beta": beta_hat,
        "C1_p": p_c1,
        "C1_sig_pos": c1_sig_pos,
        **d1,
        "primary_success_S1": primary,
    }


def run_S2_or_S3(scenario: str, rep: int, engine, tau0: float) -> dict:
    G, n_per, icc = 12, 5, 0.20
    rng_asg = child_rng(scenario, rep, "assignment")
    rng_m = child_rng(scenario, rep, "M")
    rng_y = child_rng(scenario, rep, "Y")
    clusters = np.repeat(np.arange(G), n_per)
    rec_seed = int(rng_asg.integers(0, 2**31 - 1))
    cluster_t, strata_c, cfg = make_crt_assignment(G, rec_seed)
    M_c = rng_m.normal(0, 1, size=G)
    M_c = (M_c - M_c.mean()) / M_c.std(ddof=0)
    C_c = np.zeros(G)
    y = simulate_Y(
        G, n_per, clusters, strata_c, cluster_t, M_c, icc, tau0, 0.0, 0.0, C_c, rng_y
    )
    t = cluster_t[clusters]
    m = M_c[clusters]
    beta_hat, p_c1 = ols_T_pvalue(y, t)
    c1m_sig_pos = (beta_hat > 0) and (p_c1 < ALPHA)
    d1 = d1_design_eligible(engine, y, t, m, clusters, cfg)
    return {
        "scenario": scenario,
        "rep": rep,
        "tau0": tau0,
        "C1m_beta": beta_hat,
        "C1m_p": p_c1,
        "C1m_sig_pos": c1m_sig_pos,
        **d1,
    }


def summarize_S1(rows):
    n = len(rows)
    c1 = sum(r["C1_sig_pos"] for r in rows)
    auth = sum(r["D1_authorize_sharp_null_rejection"] for r in rows)
    dn = sum(r["D1_do_not_authorize"] for r in rows)
    ab = sum(r["D1_abstain"] for r in rows)
    prim = sum(r["primary_success_S1"] for r in rows)
    reasons = {}
    for r in rows:
        reasons[r["reason"]] = reasons.get(r["reason"], 0) + 1
    return {
        "scenario": "S1",
        "n": n,
        "C1_sig_pos_rate": c1 / n,
        "D1_authorize_sharp_null_rejection_rate": auth / n,
        "D1_do_not_authorize_rate": dn / n,
        "D1_abstain_rate": ab / n,
        "primary_success_rate": prim / n,
        "primary_wilson95": wilson(prim, n),
        "reason_counts": reasons,
    }


def summarize_S2S3(rows, scenario):
    n = len(rows)
    auth = sum(r["D1_authorize_sharp_null_rejection"] for r in rows)
    dn = sum(r["D1_do_not_authorize"] for r in rows)
    ab = sum(r["D1_abstain"] for r in rows)
    c1m = sum(r["C1m_sig_pos"] for r in rows)
    return {
        "scenario": scenario,
        "n": n,
        "D1_authorize_sharp_null_rejection_rate": auth / n,
        "D1_authorize_wilson95": wilson(auth, n),
        "D1_do_not_authorize_rate": dn / n,
        "D1_abstain_rate": ab / n,
        "C1m_sig_pos_rate": c1m / n,
        "C1m_wilson95": wilson(c1m, n),
        "V3_demo_adequacy_threshold": 0.20,
        "V3_threshold_met": (auth / n) >= 0.20 or (wilson(auth, n)[0] > 0.05 if n else False),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["smoke", "confirmatory"], default="smoke")
    ap.add_argument("--reps-s1", type=int, default=None)
    ap.add_argument("--reps-s2", type=int, default=None)
    ap.add_argument("--reps-s3", type=int, default=None)
    ap.add_argument("--scenario", choices=["S1","S2","S3","all"], default="all")
    ap.add_argument("--checkpoint-every", type=int, default=25)
    args = ap.parse_args()

    if args.mode == "smoke":
        n1 = args.reps_s1 or 5
        n2 = args.reps_s2 or 5
        n3 = args.reps_s3 or 5
        label = "smoke"
    else:
        n1 = args.reps_s1 or 500
        n2 = args.reps_s2 or 500
        n3 = args.reps_s3 or 500
        label = "confirmatory"

    engine = RobustPooledScreenEngine(min_clusters_threshold=8, exact_enumeration_threshold=1_000_000)
    t0 = time.time()

    s1_rows = [run_S1(i, engine) for i in range(n1)]
    s2_rows = [run_S2_or_S3("S2", i, engine, tau0=0.35) for i in range(n2)]
    s3_rows = [run_S2_or_S3("S3", i, engine, tau0=0.0) for i in range(n3)]

    summary = {
        "S1": summarize_S1(s1_rows),
        "S2": summarize_S2S3(s2_rows, "S2"),
        "S3": summarize_S2S3(s3_rows, "S3"),
    }

    # Unit checks embedded
    checks = {
        "S1_never_authorizes": all(not r["D1_authorize_sharp_null_rejection"] for r in s1_rows),
        "S1_reasons_allowed": all(
            r["reason"] in ("missing_randomization_record", "observational_assignment")
            for r in s1_rows
        ),
        "S1_no_confounding_flag_reason": all(r["reason"] != "confounding_flag_demo" for r in s1_rows),
        "S2_has_pvalues_when_not_abstain": all(
            (r["p_value"] is not None) or r["D1_abstain"] for r in s2_rows
        ),
    }

    out = {
        "meta": {
            "protocol": "DEMO_PROTOCOL_v1.0.1",
            "protocol_sha256_at_write": sha256_file(PROTOCOL) if PROTOCOL.exists() else None,
            "mode": label,
            "demo_master_seed": DEMO_SEED,
            "does_not_replace_oc_v1_1": True,
            "authorize_label": "AUTHORIZE_DESIGN_BASED_REJECTION_OF_SHARP_NULL",
            "finished_utc": datetime.now(timezone.utc).isoformat(),
            "elapsed_seconds": time.time() - t0,
            "checks": checks,
        },
        "summary": summary,
        "rows": {"S1": s1_rows, "S2": s2_rows, "S3": s3_rows},
    }

    out_dir = Path(__file__).resolve().parent
    out_path = out_dir / f"RESULTS_{label}.json"
    out_path.write_text(json.dumps(out, indent=2, default=str))
    print(json.dumps({"meta": out["meta"], "summary": summary}, indent=2))
    print("Wrote", out_path)


if __name__ == "__main__":
    main()
