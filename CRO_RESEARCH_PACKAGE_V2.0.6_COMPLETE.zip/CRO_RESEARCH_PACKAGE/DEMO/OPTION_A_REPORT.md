# Option A verification report (S2/S3 design)

**Date:** 2026-11-07  
**Type:** Exhaustive retention verification — **not** a confirmatory AUTHORIZE-rate study  
**Engine pin:** `pooled_screen.py` SHA-256 `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`

## Design

| Item | Value |
|------|--------|
| G | 12 |
| Strata | 2 × 6 clusters |
| Treated per stratum | 3 |
| \(\|\mathcal{A}\|\) | \(\binom{6}{3}^2 = 400\) |
| n per cluster | 5 |
| Moderator | One fixed vector: N(0,1) draws, seed 0, then standardized (ddof=0) |
| Outcome | One fixed vector (seed 0); held constant across observed assignments |

## Procedure

For **each** of the 400 possible observed CRT assignments:

1. Call pinned `sharp_null_test` with record-verification bypassed (design audit only).  
2. Record `valid_allocation_count`, `allocation_space_size`, abstain flag.

## Result

| Metric | Value |
|--------|--------|
| Observed assignments tested | **400** |
| Full-universe retention (`valid=total=400`) | **400** |
| Abstain | **0** |
| Partial retention | **0** |
| **Invariance of \(\mathcal{A}_{\mathrm{ret}}\) to \(T_{\mathrm{obs}}\) for this (design, M)** | **YES** |

Artifacts: `OPTION_A_RESULTS.json`, `OPTION_A_CHECKPOINT.json`, `OPTION_A_LOG.txt`.

## What this does **not** show

- Invariance for **all** moderator vectors (only one M was tested).  
- Retroactive certification of historical S2/S3 4.6% rates (no historical retained-set logs).  
- A general theorem for all CRT designs.  
- Any change to V3 or commercial claims.

## Interpretation

For the **declared S2/S3 assignment universe** and **this fixed moderator**, every observed assignment retained the **full** 400-allocation ranking set. Under that condition, the elementary complete-randomization enumeration argument applies to the success path for this design/M pair (still subject to interaction-statistic interpretation limits).
