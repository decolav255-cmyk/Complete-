# Observed-assignment dependence note

In exact_rank_and_fit, z1 uses observed_treatment residuals projected onto X(candidate).
Thus variance-polynomial gates can depend on T_obs, not only (A, M).

Probe (G=8, 12 CRT assignments, fixed M and Y): always valid=total=36.
Invariance of A_ret to T_obs is not a general theorem; full-universe success path supports standard enumeration exactness for those replicates only.

Historical S2/S3 rates: engine outputs, not retro-certified.
