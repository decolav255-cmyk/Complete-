#!/usr/bin/env python3
"""Option A verification with checkpoint resume."""
from __future__ import annotations
import json, math, sys, time
from itertools import combinations
from pathlib import Path
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "SOURCE"))
from cro.pooled_screen import RobustPooledScreenEngine

G, N_PER = 12, 5
STRATA = [0]*6 + [1]*6
N_A = math.comb(6, 3)**2
OUT = Path(__file__).resolve().parent / "OPTION_A_RESULTS.json"
CKPT = Path(__file__).resolve().parent / "OPTION_A_CHECKPOINT.json"
LOG = Path(__file__).resolve().parent / "OPTION_A_LOG.txt"

def all_assignments():
    s0, s1 = list(range(6)), list(range(6,12))
    for a in combinations(s0, 3):
        for b in combinations(s1, 3):
            ct = np.zeros(G)
            for c in a: ct[c]=1.0
            for c in b: ct[c]=1.0
            yield ct

def main():
    rng = np.random.default_rng(0)
    M = rng.normal(size=G); M=(M-M.mean())/M.std(ddof=0)
    y = rng.normal(size=G*N_PER)
    clusters = np.repeat(np.arange(G), N_PER)
    m = M[clusters]
    eng = RobustPooledScreenEngine(min_clusters_threshold=8, exact_enumeration_threshold=10**6)
    eng.verify_randomization_record = lambda *a, **k: (True, "option_a_audit_bypass")

    rows = []
    start = 0
    if CKPT.exists():
        prev = json.loads(CKPT.read_text())
        rows = prev.get("rows", [])
        start = len(rows)
        print(f"Resuming from {start}", flush=True)

    t0 = time.time()
    n_full = sum(1 for r in rows if (not r["abstain"]) and r["valid"]==r["total"]==N_A)
    n_abstain = sum(1 for r in rows if r["abstain"])
    n_partial = len(rows) - n_full - n_abstain

    for i, ct in enumerate(all_assignments()):
        if i < start:
            continue
        t = ct[clusters]
        cfg = {
            "mechanism": "complete_cluster_randomization_within_strata",
            "strata": STRATA,
            "randomization_record": {
                "algorithm": "numpy.PCG64_uniform_without_replacement_v1",
                "seed": 0,
                "treated_counts": [
                    {"stratum": 0, "n_treated": 3, "n_clusters": 6},
                    {"stratum": 1, "n_treated": 3, "n_clusters": 6},
                ],
            },
        }
        out = eng.sharp_null_test(y, t, m, clusters, assignment_config=cfg)
        d = out.diagnostics or {}
        valid, total = d.get("valid_allocation_count"), d.get("allocation_space_size")
        row = {"index": i, "abstain": bool(out.abstained), "valid": valid, "total": total,
               "reason": (out.reason or "")[:120]}
        rows.append(row)
        if out.abstained: n_abstain += 1
        elif valid == total == N_A: n_full += 1
        else: n_partial += 1
        if (i+1) % 10 == 0 or (i+1)==N_A:
            CKPT.write_text(json.dumps({"rows": rows}))
            msg = f"checked {i+1}/{N_A} full={n_full} abstain={n_abstain} partial={n_partial} elapsed={time.time()-t0:.1f}s"
            print(msg, flush=True)
            with LOG.open("a") as f: f.write(msg+"\n")

    summary = {
        "design": {"G": G, "n_per": N_PER, "N_A": N_A},
        "n_observed_assignments_tested": len(rows),
        "n_full_universe_retention": n_full,
        "n_abstain": n_abstain,
        "n_partial_retention": n_partial,
        "invariance_full_universe": n_full==N_A and n_abstain==0 and n_partial==0,
        "elapsed_seconds": time.time()-t0,
        "note": "Option A only; fixed M and Y from seed 0; record verify bypassed for audit",
    }
    OUT.write_text(json.dumps({"summary": summary, "rows": rows}, indent=2))
    print(json.dumps(summary, indent=2), flush=True)

if __name__ == "__main__":
    main()
