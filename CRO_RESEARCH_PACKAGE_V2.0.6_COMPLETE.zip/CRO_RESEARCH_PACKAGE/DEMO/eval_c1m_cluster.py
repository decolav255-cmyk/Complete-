#!/usr/bin/env python3
"""Synthetic evaluation of C1m_cluster on S2-like design. Not a customer pilot."""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
from datetime import datetime, timezone
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_demo as D

def wilson(s, n, z=1.96):
    if n <= 0: return (float('nan'), float('nan'))
    p = s/n
    den = 1+z*z/n
    centre = p + z*z/(2*n)
    margin = z*math.sqrt(p*(1-p)/n + z*z/(4*n*n))
    return (centre-margin)/den, (centre+margin)/den

def one_rep(scenario, rep, tau0):
    G, n_per, icc = 12, 5, 0.20
    rng_asg = D.child_rng(scenario, rep, "assignment")
    rng_m = D.child_rng(scenario, rep, "M")
    rng_y = D.child_rng(scenario, rep, "Y")
    clusters = np.repeat(np.arange(G), n_per)
    rec_seed = int(rng_asg.integers(0, 2**31 - 1))
    cluster_t, strata_c, cfg = D.make_crt_assignment(G, rec_seed)
    M_c = rng_m.normal(0, 1, size=G)
    M_c = (M_c - M_c.mean()) / M_c.std(ddof=0)
    C_c = np.zeros(G)
    y = D.simulate_Y(G, n_per, clusters, strata_c, cluster_t, M_c, icc, tau0, 0.0, 0.0, C_c, rng_y)
    t = cluster_t[clusters]
    # C1m_cluster
    c1m = D.c1m_cluster_test(y, t, clusters, strata_c)
    # Unclustered foil
    beta, p_ols = D.ols_T_pvalue(y, t)
    ols_sig = (beta > 0) and (p_ols < 0.05)
    return {
        "rep": rep, "tau0": tau0,
        "c1m_sig": c1m["sig"], "c1m_abstain": c1m["abstain"],
        "c1m_p": c1m["p_value"], "c1m_tau": c1m["tau_hat"],
        "c1m_reason": c1m["reason"],
        "ols_sig_pos": ols_sig, "ols_p": p_ols,
    }

def run_scenario(name, tau0, n_rep=500):
    rows = [one_rep(name, i, tau0) for i in range(n_rep)]
    n = len(rows)
    n_abs = sum(r["c1m_abstain"] for r in rows)
    n_sig = sum(r["c1m_sig"] for r in rows)
    n_ols = sum(r["ols_sig_pos"] for r in rows)
    # among non-abstain
    done = [r for r in rows if not r["c1m_abstain"]]
    n_done = len(done)
    n_sig_done = sum(r["c1m_sig"] for r in done)
    return {
        "scenario": name, "tau0": tau0, "n": n,
        "c1m_abstain_rate": n_abs/n,
        "c1m_sig_rate_unconditional": n_sig/n,
        "c1m_sig_rate_conditional": (n_sig_done/n_done) if n_done else None,
        "c1m_sig_wilson95": wilson(n_sig, n),
        "ols_unclustered_sig_pos_rate": n_ols/n,
        "rows": rows,
    }

def main():
    t0 = time.time()
    # Power under main effect (S2-like) and Type I under null (S3-like)
    s2 = run_scenario("C1m_S2_main", tau0=0.35, n_rep=500)
    s3 = run_scenario("C1m_S3_null", tau0=0.0, n_rep=500)
    out = {
        "meta": {
            "procedure": "C1m_cluster",
            "spec_ref": "CRO Demonstration Specification v2.0.5 § / predeclaration",
            "demo_master_seed": D.DEMO_SEED,
            "n_rep": 500,
            "design": "G=12, n=5, ICC=0.20, CRT within 2 strata",
            "finished_utc": datetime.now(timezone.utc).isoformat(),
            "elapsed_seconds": time.time()-t0,
            "note": "Synthetic evaluation only; not partner validation",
        },
        "S2_main_effect": {k:v for k,v in s2.items() if k!="rows"},
        "S3_null": {k:v for k,v in s3.items() if k!="rows"},
        "rows": {"S2": s2["rows"], "S3": s3["rows"]},
    }
    path = Path(__file__).resolve().parent / "C1M_CLUSTER_EVAL.json"
    path.write_text(json.dumps(out, indent=2))
    print(json.dumps({"meta": out["meta"], "S2": out["S2_main_effect"], "S3": out["S3_null"]}, indent=2))
    print("Wrote", path)

if __name__ == "__main__":
    main()
