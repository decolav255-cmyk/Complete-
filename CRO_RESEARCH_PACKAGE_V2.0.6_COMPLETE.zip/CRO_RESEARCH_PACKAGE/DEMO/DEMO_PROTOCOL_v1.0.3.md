# CRO Independent Demonstration Protocol v1.0.3

**Status:** DRAFT FOR INSPECTION — strategy agreed; **not** formally approved as frozen protocol
**Inspection note:** Formal phrase “Approve Demo Protocol v1.0.3 as written” is reserved until reviewer accepts this text, runner, and commercial docs.  
**Date:** 2026-11-06  
**Amends:** v1.0.2 (direction retained; C1m inferential claim corrected)  
**Historical results:** All **v1.0.1 confirmatory** S1/S2/S3 numbers remain frozen. **No new confirmatory runs** are authorized by this document alone.

---

## 1. Purpose of this correction

Independent review identified a **blocking methodological defect** in v1.0.2 Path C wording:

- Implementation `ols_T_pvalue()` is **pooled OLS with IID residual SE and normal p-value**.
- It does **not** account for cluster-level assignment.
- Therefore the historical **31.2% “C1m” rate on S2 must not be described as valid CRT main-effect detection**.

v1.0.3 keeps Path C’s architecture (dual readout; D1 = sharp-null only) but **downgrades the OLS comparator’s inferential status** and **predeclares** a cluster-aware main-effect procedure for any future claim of CRT-valid main-effect detection.

A second defect: child seeds used Python `hash()`, which is **not stable** across processes. Runners must use **SHA-256–derived** integers for SeedSequence (see §6). **Already-reported v1.0.1 confirmatory numbers are retained as historical outputs of the then-current runner**; they are not re-issued as “bit-reproducible under v1.0.3 seeds” without a new approved run.

---

## 2. What remains valid (unchanged numbers)

| Result | Rate (n=500) | Status under v1.0.3 |
|--------|----------------|---------------------|
| S1 primary success | 0.982 (0.966, 0.991) | **Retain** — D1 gated on missing record |
| S2 D1 authorize (sharp-null rejection) | 0.046 (0.031, 0.068) | **Retain** historical |
| S2 V3 (floor 0.20) | **NOT MET** | **Retain failure** |
| S3 D1 Type I | 0.046 (0.031, 0.068) | **Retain** with limitations |
| S2 OLS “C1m” sig pos | 0.312 (0.273, 0.354) | **Retain only as C1_OLS_unclustered** — **not** CRT-valid main-effect inference |

---

## 3. Comparator taxonomy (binding)

| ID | Definition | Valid CRT inference? | Allowed commercial use |
|----|------------|----------------------|------------------------|
| **D1** | R23 `sharp_null_test` with verified `randomization_record` | Design-based sharp-null rejection only | `AUTHORIZE_DESIGN_BASED_REJECTION_OF_SHARP_NULL` |
| **C1_OLS_unclustered** | Pooled OLS \(Y\sim 1+T\), IID SE, normal \(p\) | **No** | “Unclustered OLS significance rate (descriptive / anti-conservative risk at small G)” |
| **C1m_cluster** | **Predeclared** cluster-aware main-effect test (§4) | Only after implemented + approved evaluation | CRT main-effect detection **only after** such evaluation exists |
| **C2** | Naive CR1-normal **interaction** | No (naive) | Stress comparator only |

**Retired label for inference:** “C1m” as used in v1.0.1/v1.0.2 commercial text for the 31.2% figure.  
**Replacement label for that figure:** **`C1_OLS_unclustered`**.

---

## 4. Predeclared cluster-aware main-effect procedure (C1m_cluster)

**Status:** PREDECLARED ONLY — not implemented as an evaluated confirmatory procedure; **no performance claim**.  
**Not executed** by approval of wording alone. Choices below are fixed **before** any future results are examined.

### 4.1 Estimand

For a scenario with complete cluster randomization within strata and cluster-level treatment \(T_c\in\{0,1\}\):

- **Primary estimand:** the **average treatment effect on the individual-level outcome** under the **observed design**, identified by the randomization distribution of cluster assignments:
  \[
  \tau = \mathbb{E}\big[Y_{ic}(1)-Y_{ic}(0)\big]
  \]
  with expectation over the super-population / design measure used in the scenario DGP documentation (demo S2: synthetic DGP with constant additive effect \(\tau_0\) when that scenario is used).

- **Not the estimand:** moderation, interaction \(\beta\), or policy “benefit” beyond this average effect.

### 4.2 Assignment mechanism (required)

Identical to D1 design-eligible requirements:

- `mechanism = complete_cluster_randomization_within_strata`
- Two equal strata in the S2 evaluation design (unless a later amendment changes the evaluation scenario)
- Fixed treated counts per stratum (half treated per stratum in S2)
- Verified `randomization_record` with algorithm `numpy.PCG64_uniform_without_replacement_v1`
- Treatment constant within cluster

If the record does not verify, **C1m_cluster abstains** (no p-value).

### 4.3 Analysis model and test statistic

**Working model (individual-level):**

\[
Y_{ic} = \alpha + \tau T_c + \sum_{s}\gamma_s\mathbf{1}\{s(c)=s\} + \varepsilon_{ic}
\]

- Include **stratum fixed effects** for all strata used in randomization.  
- **No** other covariate adjustment in the primary predeclared test (including no moderator \(M\), no confounding covariates).  
- Coefficient of interest: \(\tau\) (main effect of cluster treatment).

**Test statistic:**

\[
t_{\tau} = \frac{\hat\tau}{\widehat{\mathrm{SE}}_{\mathrm{CR1}}(\hat\tau)}
\]

where \(\hat\tau\) is the OLS coefficient on \(T\) from the working model and \(\widehat{\mathrm{SE}}_{\mathrm{CR1}}\) is the **cluster-robust CR1** standard error for that coefficient (clusters = randomization clusters; CR1 finite-sample factor as in the R23/engine CR1 definition already used for sandwich estimation in this codebase).

**Primary p-value (predeclared):** two-sided normal reference

\[
p = 2\Phi\big(-|t_{\tau}|\big)
\]

with significance threshold \(\alpha = 0.05\).

**Secondary diagnostic (report, not primary authorization):** degrees-of-freedom note \(G-1\) or stratum-adjusted cluster DF when implemented; may report a t-reference p-value as **diagnostic only**, clearly labeled, not as the primary predeclared decision.

### 4.4 Null hypothesis

\[
H_0: \tau = 0
\]

under the declared randomization scheme and working model.  
This is a **main-effect null**, distinct from D1’s sharp global null tested via the interaction functional.

### 4.5 Decision labels (when evaluated)

| Outcome | Condition |
|---------|-----------|
| `C1m_cluster_sig` | not abstained and \(p < 0.05\) |
| `C1m_cluster_nonsig` | not abstained and \(p \ge 0.05\) |
| `C1m_cluster_abstain` | failed record verification, rank deficiency, non-finite SE, or fewer clusters than engine minimum |

**Commercial use when evaluated:** “cluster-robust main-effect test significant under declared CRT” — **still not** interchangeable with D1 sharp-null authorization.

### 4.6 Confidence interval (planned)

Report Wald 95% interval using the same CR1 SE:

\[
\hat\tau \pm z_{0.975}\,\widehat{\mathrm{SE}}_{\mathrm{CR1}}(\hat\tau)
\]

with \(z_{0.975} = \Phi^{-1}(0.975)\).  
Interval is **approximate** (normal/CR1); not an exact randomization CI unless a later amendment replaces it with inversion under the allocation space.

### 4.7 Missing observations

- **Primary rule:** require **complete finite** \((Y,T)\) on all individuals in the analysis sample (same spirit as R23 exact path).  
- If any non-finite \(Y\) or \(T\), or empty clusters after listwise deletion: **abstain** (`C1m_cluster_abstain`).  
- **No** imputation in the primary predeclared procedure.  
- Any future missing-data variant requires a protocol amendment before use.

### 4.8 Evaluation design (frozen for first future run)

When a confirmatory evaluation is **separately** approved:

| Item | Value |
|------|--------|
| Scenario | Same as demo S2: \(G=12\), \(n_c=5\), ICC=0.20, \(\tau_0=0.35\), \(\beta=0\), valid CRT record |
| Replicates | 500 unless amendment states otherwise |
| Metrics | Rate of `C1m_cluster_sig`; Wilson 95% CI; abstention rate; mean \(\hat\tau\) |
| Seed namespace | SHA-256 child derivation; demo master seed 20261108; role labels fixed in runner before run |
| Relationship to V3 | Does **not** re-open or “fix” V3 on D1; V3 failure on D1 remains |

### 4.9 Explicit non-claims for C1m_cluster

Until an approved evaluation exists:

- No detection rate, power, or Type I claim for `C1m_cluster`.  
- Historical 31.2% remains **`C1_OLS_unclustered` only**.

## 5. S2i (optional interaction arm)

Unchanged intent from v1.0.2: separate demonstration with β≠0.  
Passing a 0.20 floor on S2i **does not** rehabilitate V3 on pure main-effect S2.

---

## 6. Reproducibility requirements

```text
child_seed_material = SHA256(utf8(label))[0:4] as uint32
SeedSequence([demo_master_seed, u32(scenario), replicate_id, u32(role)]) → PCG64
```

Python `hash()` is **forbidden** for seed derivation in demo runners.

**Note:** Changing seed derivation means **new runs will not match** v1.0.1 row-level draws. Aggregate historical rates stay cited as historical; bit-identical re-execution requires the original runner or a recorded seed manifest from that run.

---

## 7. Commercial wording rules (corrected)

**Allowed**

- S1: record-gated non-authorization vs unclustered OLS significance under confounding.  
- S2 D1: sharp-null rejection rate under CRT (historical 4.6%); not moderation; not proven benefit.  
- S2 OLS 31.2%: **unclustered OLS** significance rate only.  
- V3 failure: explicit.

**Forbidden**

- Calling the 31.2% figure “valid CRT main-effect detection.”  
- “Improvement” as a causal benefit claim from D1 or from unclustered OLS alone.  
- Implying S2i validates main-effect V3.

---

## 8. Relationship to OC v1.1

Unchanged: demo does **not** replace OC Protocol v1.1.

---

## 9. Approval gate

Approve direction of Path C **with this correction** via:

`Approve Demo Protocol v1.0.3 as written.`

Effects of approval:

1. Freeze comparator taxonomy and commercial wording above.  
2. Reclassify historical 31.2% as `C1_OLS_unclustered`.  
3. Require SHA-256 seed derivation in runners.  
4. **Do not** start new confirmatory batches (including `C1m_cluster` or S2i) until separately requested.

