# Demo Protocol v1.0.1 — Confirmatory Results Report

Generated (UTC): 2026-11-06T17:25:12.959034+00:00
Protocol: DEMO_PROTOCOL_v1.0.1 (approved). **Does not replace OC Protocol v1.1.**
Seed: demo_master_seed=20261108. Smoke results remain in RESULTS_smoke.json only.

## Runtime
- S1: 2.1s for 500 reps
- S2: completed 500 reps with checkpoint resume (see CONFIRMATORY_S2 logs); final segment meta elapsed in RESULTS_confirmatory_S2.json
- S3: completed 500 reps with checkpoint resume; final segment elapsed 456.6s for last resume portion

## S1 — Confounded false improvement (no randomization record)
| Metric | Rate | Wilson 95% |
|--------|------|------------|
| C1 sig pos | 0.982 | — |
| D1 authorize sharp-null rejection | 0.000 | — |
| D1 do not authorize | 1.000 | — |
| D1 abstain | 1.000 | — |
| **Primary success** (C1 sig ∧ D1 no-auth ∧ allowed reason) | **0.982** | (0.966, 0.991) |
| Reasons | {'missing_randomization_record': 500} | all allowed |

Checks: never authorizes; no confounding_flag_demo; all reasons missing_randomization_record.

## S2 — Randomized main effect τ₀=0.35 (valid CRT record)
| Metric | Rate | Wilson 95% |
|--------|------|------------|
| D1 AUTHORIZE_DESIGN_BASED_REJECTION_OF_SHARP_NULL | 0.046 | (0.031, 0.068) |
| D1 do not authorize | 0.954 | — |
| D1 abstain | 0.000 | — |
| C1m sig pos (main-effect comparator) | 0.312 | (0.273, 0.354) |
| V3 demo adequacy (≥0.20) | **NOT MET** | threshold=0.20 |

Interpretation: D1 tests sharp-null rejection via interaction functional; pure main-effect alternative yields low D1 authorization. C1m shows higher detection of main effect. **Not** a moderation finding. **V3 failure is reported as failure.**

## S3 — Randomized sharp null (Type I)
| Metric | Rate | Wilson 95% |
|--------|------|------------|
| D1 authorize (Type I) | 0.046 | (0.031, 0.068) |
| D1 do not authorize | 0.954 | — |
| D1 abstain | 0.000 | — |
| C1m sig pos | 0.072 | (0.052, 0.098) |

Type I near 4.6% with CI covering values below and slightly above 5% depending on interpretation; abstentions 0. Not a claim of universal 5% calibration.

## Value tests (predeclared)
- **V1 (S1 blocks while C1 fires):** supported (primary success 0.982).
- **V2 (S3 Type I vs naive methods):** D1 Type I=0.046; descriptive only.
- **V3 (S2 demo power floor 0.20):** **FAILED** (rate=0.046, CI upper=0.068).

## Commercial constraints (unchanged)
- P1 = exact randomization under stated design; not universally calibrated at 5%.
- P2/C2 = naive CR1-normal interaction comparator only.
- Low power at small G / against pure main effect = limitation, not absence of effects.
- Demo ≠ OC v1.1 confirmatory study.
