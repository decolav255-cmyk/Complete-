# DEMO

| Protocol | Status |
|----------|--------|
| v1.0.1 | Approved; confirmatory S1/S2/S3 × 500 **done** (historical) |
| v1.0.2 | Superseded by v1.0.3 correction on C1m claim |
| v1.0.3 | **Draft correction** — approve to freeze wording; **no new runs** until requested |

Blocking fix: historical 31.2% = **C1_OLS_unclustered**, not CRT-valid C1m.  
Seeds: SHA-256 child derivation in `run_demo.py` (new runs ≠ bit-identical to v1.0.1 rows).
