# Path C narrative (v1.0.3)

## Allowed

1. S1: unclustered OLS often significant; D1 never authorizes without record (primary success 98.2%).
2. S2 D1: sharp-null rejection 4.6% (CI 3.1–6.8%); V3 failed.
3. S2 OLS 31.2%: label **C1_OLS_unclustered** only — not CRT-valid main-effect detection.
4. C1m_cluster: predeclared; **no rate until evaluated**.

## Forbidden

- Inferential use of 31.2% as CRT main-effect detection  
- D1 = improvement or moderation  
- S2i pass cures main-effect V3  
