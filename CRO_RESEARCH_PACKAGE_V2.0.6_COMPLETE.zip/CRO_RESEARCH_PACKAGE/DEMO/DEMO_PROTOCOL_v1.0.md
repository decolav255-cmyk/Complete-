# CRO Independent Demonstration Protocol v1.0

**Status:** DRAFT FOR FREEZE — no confirmatory demo runs until explicitly approved  
**Suggested approval phrase:** `Approve Demo Protocol v1.0 as written.`  
**Date:** 2026-11-05  
**Scope:** Stages 1–3 only (controlled experiments, adversarial tests, independent comparison). Stage 4 (public data) and Stage 5 (commercial packaging of results) are out of scope for this document except as interfaces.

---

## 0. Purpose and non-claims

### Purpose

Produce a **reproducible, inspectable demonstration** that an independent statistician can challenge, showing that CRO:

1. **Refuses** causal authorization when a conventional analysis reports a misleading “improvement” driven by confounding (or other design failure).
2. **Detects** unreliable evidence under adversarial contamination (confounding, misleading feedback, missingness, weak overlap).
3. **Agrees** with a genuine effect under a **declared, complete cluster-randomized** design when the design-based procedure is applicable.
4. **Adds measurable value** relative to a fixed set of conventional comparators on the same datasets.

### Non-claims (binding)

This protocol does **not** authorize claims of:

- Partner or production validation  
- Guaranteed real-world ROI or lift  
- Automatic moderator discovery on observational agent traces  
- That synthetic results equal field performance  
- That Phase 1 pooled-screen alone is the entire CRO product  

All results must be labeled **synthetic demonstration evidence** unless a later Stage 4 protocol is approved.

---

## 1. Primary demonstration narrative (required story)

Exactly one **headline comparison** must be reported as the primary commercial-facing scientific story:

| Arm | Data-generating truth | Conventional analysis (C1) | CRO decision rule (D1) | Success criterion |
|-----|----------------------|----------------------------|-------------------------|-------------------|
| **A — Confounded false improvement** | No treatment effect; apparent gain is confounding | Reports “significant improvement” at \(\alpha=0.05\) | **Does not authorize** causal improvement claim (abstain or non-authorization) | C1 significant **and** D1 non-authorization |
| **B — Randomized genuine improvement** | Real cluster-level treatment effect under declared randomization | May or may not be significant (recorded) | **Authorizes** design-based evidence of effect under sharp-null rejection **or** reports valid design-based \(p\) consistent with protocol rules | D1 authorization only when design record verifies; under true effect, rejection rate of design-based test materially above null calibration |

Arms A and B use **parallel reporting templates**. No arm may be dropped after seeing results.

---

## 2. System under test

### 2.1 CRO decision layer (D1) — primary

For this demo, **D1** is defined as the **gated Phase 1 path** only when the scenario supplies a valid cluster-randomized design record; otherwise D1 must **abstain**.

**When design-eligible (Arm B and any scenario that declares CRT):**

- Call R23 `sharp_null_test` (exact-rational path) with:
  - `assignment_config.mechanism = complete_cluster_randomization_within_strata`
  - Cluster-level strata  
  - `randomization_record` reproducible under `numpy.PCG64_uniform_without_replacement_v1`  
- Engine config: `min_clusters_threshold ≤ G` for the scenario (document value); `exact_enumeration_threshold ≥ N_A` so exact enumeration is used when \(N_A\) is tractable  
- **Authorization rule (binary):**  
  - `AUTHORIZE_DESIGN_BASED_EFFECT_EVIDENCE` if not abstained and \(p < 0.05\) (two-sided)  
  - `DO_NOT_AUTHORIZE` if abstained **or** \(p \ge 0.05\)

**When design-ineligible (Arm A and adversarial observational scenarios):**

- D1 must **not** call a randomization test as if a CRT existed  
- D1 outcome: `DO_NOT_AUTHORIZE` with machine-readable reason in  
  `{missing_randomization_record, observational_assignment, confounding_flag_demo, weak_overlap, insufficient_clusters, rank_deficient, other_abstain}`

Optional (reported, not primary): full CRO pipeline findings on synthetic traces **if** implemented without changing D1 rules above. If not wired, demo stays on D1 alone and states that limitation.

### 2.2 Conventional comparators (fixed list — no post-hoc adds)

| ID | Method | Authorization analogue |
|----|--------|---------------------------|
| **C1** | OLS or pooled OLS of \(Y\) on \(T\) (individual-level), two-sided \(t\) or normal \(p\), \(\alpha=0.05\) | “Significant improvement” if \(\hat\beta_T>0\) and \(p<0.05\) |
| **C2** | Cluster-robust CR1 interaction or main-effect model as specified per scenario; **naive normal** \(p=2\Phi(-|t|)\) | Significant if \(p<0.05\) |
| **C3** | Same as C2 but **ignore clustering** (IID SE) | Significant if \(p<0.05\) |

C1 is required for the headline story. C2–C3 are required for Stage 3 value comparison.

No other methods may be added after results are inspected without a protocol amendment.

---

## 3. Stage 1 — Controlled experiments (known truth)

### 3.1 Shared DGP elements

Unless a scenario overrides:

\[
Y_{ic} = \mu + \gamma_{s(c)} + u_c + \varepsilon_{ic} + T_c(\tau_0 + \beta M_c) + \mathbf{1}_{\text{conf}}\,\delta C_c
\]

- Two strata where applicable; \(\gamma_1=-0.15\), \(\gamma_2=+0.15\)  
- \(u_c\sim\mathcal N(0,\sigma_u^2)\), \(\varepsilon_{ic}\sim\mathcal N(0,\sigma_e^2)\), marginal \(\mathrm{Var}(Y)=1\) at target ICC  
- Master seed root: **20261108** (demo namespace; distinct from OC master seed 20261107)  
- Seed derivation: `SeedSequence([20261108, scenario_id, replicate_id, stream_role])` → PCG64  

### 3.2 Scenario S1 — Confounded false improvement (Arm A)

| Field | Specification |
|-------|----------------|
| **ID** | `S1_confounded_false_improvement` |
| **Truth** | \(\tau_0=0\), \(\beta=0\); no causal effect of \(T\) |
| **Confounding** | Cluster covariate \(C_c\sim\mathcal N(0,1)\); \(T_c = \mathbf{1}\{C_c > 0\}\) (observational split, **not** randomized); outcome includes \(\delta C_c\) with \(\delta=0.6\) |
| **Design record** | **None** — must not pass a fake `randomization_record` |
| **G, n** | \(G=20\) clusters, \(n_c=10\) individuals |
| **ICC** | 0.20 |
| **Replicates** | 500 independent datasets |
| **Primary success** | Rate that **C1 is significant positive** *and* **D1 = DO_NOT_AUTHORIZE** |
| **Secondary** | Rate C1 significant; rate D1 abstain reason = observational / missing record |

### 3.3 Scenario S2 — Randomized genuine main effect (Arm B)

| Field | Specification |
|-------|----------------|
| **ID** | `S2_randomized_genuine_effect` |
| **Truth** | \(\tau_0=0.35\), \(\beta=0\); genuine constant treatment effect |
| **Assignment** | Complete cluster randomization, 2 equal strata, half treated per stratum; **valid** `randomization_record` |
| **G, n** | \(G=12\), \(n_c=5\) (exact enum tractable under R23) |
| **ICC** | 0.20 |
| **Replicates** | 500 |
| **Primary success** | D1 authorization rate (expect substantially \(>\) null calibration; report with Wilson CI) |
| **Secondary** | C1/C2 significance rates; P1 \(p\)-value distribution summary |

### 3.4 Scenario S3 — Randomized null (negative control)

| Field | Specification |
|-------|----------------|
| **ID** | `S3_randomized_sharp_null` |
| **Truth** | \(\tau_0=0\), \(\beta=0\) |
| **Assignment** | Same CRT mechanism as S2; valid record |
| **G, n, ICC** | Same as S2 |
| **Replicates** | 500 |
| **Primary success** | D1 authorization rate near nominal 5% (report unconditional + abstentions separately) |
| **Secondary** | C2 naive normal false-positive rate (expect inflation) |

### 3.5 Scenario S4 — Randomized interaction (optional Stage 1 extension)

| Field | Specification |
|-------|----------------|
| **ID** | `S4_randomized_interaction` |
| **Truth** | \(\tau_0=0\), \(\beta=0.35\) |
| **Assignment** | Same CRT as S2 |
| **G, n, ICC** | \(G=12\), \(n_c=5\), ICC 0.20 |
| **Replicates** | 200 (descriptive power; not for tuning \(\beta\)) |
| **Primary metric** | D1 authorization rate (descriptive only) |

S4 must not be used to select effect sizes after seeing results.

---

## 4. Stage 2 — Adversarial / reliability tests

Each scenario: **200 replicates**, report D1 non-authorization rate (expect high) and whether C1 still “finds” an effect.

### 4.1 S5 — Measured confounding with analysis that conditions wrong

| ID | `S5_wrong_adjustment` |
|----|------------------------|
| Truth | No effect; \(T\) depends on \(C\); \(Y\) depends on \(C\) |
| Trap | C1 ignores \(C\); optional misspecified control set |
| Expect | C1 false positive common; D1 DO_NOT_AUTHORIZE |

### 4.2 S6 — Selection / missingness dependent on latent outcome

| ID | `S6_missingness_selection` |
|----|----------------------------|
| Mechanism | Drop observations with probability increasing in latent \(Y\) before treatment coding noise |
| Design | Observational \(T\) as in S1 |
| Expect | D1 DO_NOT_AUTHORIZE; record missingness rate |

### 4.3 S7 — Weak overlap

| ID | `S7_weak_overlap` |
|----|-------------------|
| Mechanism | Propensity for \(T=1\) is 0.05 or 0.95 as function of \(C\) (near separation) |
| Expect | D1 DO_NOT_AUTHORIZE; conventional methods may still return \(p<0.05\) |

### 4.4 S8 — Feedback poisoning (label noise on “success”)

| ID | `S8_feedback_poisoning` |
|----|-------------------------|
| Mechanism | With probability 0.3, flip recorded outcome sign contribution for treated units only (demo of misleading feedback) |
| Base | Start from S2 assignment but **corrupt Y** post-randomization for analysis dataset only |
| Expect | Report D1 and C1; **truth** is still \(\tau_0=0.35\) on latent clean Y — **analysis Y is poisoned**. Primary demo metric: **discrepancy warning** — if implementation cannot flag poisoning, D1 may authorize on poisoned data; **must report this as a limitation**, not hide it |

S8 is explicitly a **stress test of honesty**: if CRO cannot detect poisoning, the report must say so.

### 4.5 S9 — Sparse observability

| ID | `S9_sparse_observability` |
|----|---------------------------|
| Mechanism | Only 30% of individuals observed per cluster (MCAR for Stage 2 baseline) |
| Base | S2 design on full data; analysis uses sparse subset |
| Expect | Higher abstention or wider uncertainty; report authorization rate vs full-data S2 |

---

## 5. Stage 3 — Independent comparison (value table)

### 5.1 Required metrics (per scenario)

For each scenario S1–S9 (as completed):

| Metric | Definition |
|--------|------------|
| C1_sig_pos | Fraction C1 significant with positive effect direction |
| C2_sig | Fraction C2 \(p<0.05\) |
| C3_sig | Fraction C3 \(p<0.05\) |
| D1_authorize | Fraction D1 AUTHORIZE |
| D1_abstain | Fraction D1 DO_NOT_AUTHORIZE with abstain/ineligible reason |
| Headline_A | For S1 only: fraction (C1_sig_pos ∧ ¬D1_authorize) |
| TypeI_D1 | For S3 only: D1_authorize rate |
| Power_D1 | For S2 only: D1_authorize rate |

### 5.2 Value propositions to test (predeclared)

| Claim ID | Statement to evaluate | Supported only if |
|----------|----------------------|-------------------|
| V1 | On S1, CRO blocks causal authorization more often than C1 avoids false significance | Headline_A high; C1_sig_pos high |
| V2 | On S3, D1 Type I closer to nominal than C2/C3 | \|TypeI_D1−0.05\| < \|C2_sig−0.05\| (descriptive) |
| V3 | On S2, D1 has non-trivial power | Power_D1 Wilson CI excludes 0.05 or exceeds predeclared floor **0.20** |

V3 floor 0.20 is a **demo adequacy floor**, not an optimality claim. If missed, report failure honestly; do not retune \(\tau_0\) without amendment.

### 5.3 Comparison figure (required)

One figure:

- Panel A: S1 rates (C1_sig_pos vs D1_authorize)  
- Panel B: S3 Type I (D1 vs C2 vs C3)  
- Panel C: S2 power (D1 vs C1)

---

## 6. Implementation and environment freeze

Before confirmatory demo runs:

1. Freeze this protocol file; record SHA-256.  
2. Freeze R23 `pooled_screen.py` and tests hashes (or record if unchanged from research package).  
3. Freeze Python / NumPy / SymPy versions.  
4. Implement comparators in a single `DEMO/run_demo.py` (or equivalent) with no hidden parameters.  
5. Unit-test: S1 single draw → no randomization_record → D1 non-authorization; S2 single draw with record → runs sharp_null_test without abstain on mechanism grounds.

### 6.1 Outputs

```
DEMO/
  DEMO_PROTOCOL_v1.0.md          # this file
  SCENARIO_SPECS_STAGE1_3.json   # machine-readable specs
  SEED_MANIFEST.json
  RESULTS.json
  RESULTS.csv
  FIGURES/headline_panels.png
  REPORT.md                      # synthetic demo only language
  REPRODUCE.md                   # one-command reproduce
```

### 6.2 Reporting language

**Allowed:**  
> “Under Demo Protocol v1.0 synthetic scenarios, conventional method C1 reported a significant positive effect in X% of confounded replicates while CRO decision rule D1 authorized a causal improvement in Y%.”

**Forbidden:** production proven; partner validated; guarantees; any claim that S1–S9 equal customer traces.

---

## 7. Amendments

Changes to DGPs, G, replicates, α, decision rules, or comparator list require **Demo Protocol v1.1+** with rationale. No silent retuning after seeing RESULTS.json.

---

## 8. Approval gate

No confirmatory Stage 1–3 batch is authorized until:

`Approve Demo Protocol v1.0 as written.`

Exploratory single-seed smoke tests (≤5 replicates per scenario) may run for engineering integration only and must be labeled **smoke**, not confirmatory.
