#!/usr/bin/env python3
"""Run one confirmatory scenario with checkpoints. Protocol v1.0.1 rules unchanged."""
from __future__ import annotations
import argparse, json, sys, time
from pathlib import Path
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_demo as D

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--scenario', required=True, choices=['S1','S2','S3'])
    ap.add_argument('--reps', type=int, default=500)
    ap.add_argument('--checkpoint-every', type=int, default=25)
    args = ap.parse_args()

    out_dir = Path(__file__).resolve().parent
    ckpt = out_dir / f'CHECKPOINT_{args.scenario}.json'
    final = out_dir / f'RESULTS_confirmatory_{args.scenario}.json'

    rows = []
    start_rep = 0
    if ckpt.exists():
        prev = json.loads(ckpt.read_text())
        rows = prev.get('rows', [])
        start_rep = len(rows)
        print(f'Resuming {args.scenario} from rep {start_rep}', flush=True)

    engine = D.RobustPooledScreenEngine(min_clusters_threshold=8, exact_enumeration_threshold=1_000_000)
    t0 = time.time()
    for i in range(start_rep, args.reps):
        if args.scenario == 'S1':
            rows.append(D.run_S1(i, engine))
        elif args.scenario == 'S2':
            rows.append(D.run_S2_or_S3('S2', i, engine, tau0=0.35))
        else:
            rows.append(D.run_S2_or_S3('S3', i, engine, tau0=0.0))
        if (i + 1) % args.checkpoint_every == 0 or (i + 1) == args.reps:
            payload = {
                'scenario': args.scenario,
                'completed_reps': len(rows),
                'target_reps': args.reps,
                'elapsed_seconds': time.time() - t0,
                'rows': rows,
            }
            ckpt.write_text(json.dumps(payload, default=str))
            print(f'{args.scenario} checkpoint {len(rows)}/{args.reps} elapsed={time.time()-t0:.1f}s', flush=True)

    if args.scenario == 'S1':
        summary = D.summarize_S1(rows)
        checks = {
            'S1_never_authorizes': all(not r['D1_authorize_sharp_null_rejection'] for r in rows),
            'S1_reasons_allowed': all(r['reason'] in ('missing_randomization_record','observational_assignment') for r in rows),
            'S1_no_confounding_flag': all(r['reason'] != 'confounding_flag_demo' for r in rows),
        }
    else:
        summary = D.summarize_S2S3(rows, args.scenario)
        checks = {'n_abstain': sum(r['D1_abstain'] for r in rows)}

    out = {
        'meta': {
            'protocol': 'DEMO_PROTOCOL_v1.0.1',
            'mode': 'confirmatory',
            'scenario': args.scenario,
            'demo_master_seed': D.DEMO_SEED,
            'does_not_replace_oc_v1_1': True,
            'authorize_label': 'AUTHORIZE_DESIGN_BASED_REJECTION_OF_SHARP_NULL',
            'reps': len(rows),
            'finished_utc': datetime.now(timezone.utc).isoformat(),
            'elapsed_seconds': time.time() - t0,
            'checks': checks,
        },
        'summary': summary,
        'rows': rows,
    }
    final.write_text(json.dumps(out, indent=2, default=str))
    print(json.dumps({'meta': out['meta'], 'summary': summary}, indent=2), flush=True)
    print('Wrote', final, flush=True)

if __name__ == '__main__':
    main()
