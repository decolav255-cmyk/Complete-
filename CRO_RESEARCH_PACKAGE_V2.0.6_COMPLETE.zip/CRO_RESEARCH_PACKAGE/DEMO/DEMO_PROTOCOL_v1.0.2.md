# CRO Independent Demonstration Protocol v1.0.2

**Status:** DRAFT FOR APPROVAL — does not auto-run; confirmatory batches need explicit approval  
**Amends:** v1.0.1 (approved; confirmatory results retained as historical under v1.0.1)  
**Date:** 2026-11-06  

## Why v1.0.2

Confirmatory v1.0.1 showed:

- **S1 success** under record-gated non-authorization.
- **V3 failure** on S2: D1 (interaction-based sharp-null test) authorization ≈ 4.6% against a **pure main-effect** alternative (τ₀=0.35, β=0), while C1m detected the main effect more often (~31%).

v1.0.2 **does not retune τ₀ or hide V3 failure**. It **separates claims**:

| Label | Meaning |
|-------|---------|
| **Path C (primary)** | Dual readout: D1 = sharp-null rejection only; “improvement” language only on **C1m** under a valid CRT |
| **Path B (optional arm)** | Separate scenario **S2i** with β≠0 so the interaction functional matches an interaction alternative (descriptive; new runs require approval) |

## Inherited from v1.0.1 (unchanged)

- S1 primary success = C1 sig pos ∧ DO_NOT_AUTHORIZE ∧ reason ∈ `{missing_randomization_record, observational_assignment}`  
- Authorize label = `AUTHORIZE_DESIGN_BASED_REJECTION_OF_SHARP_NULL` only  
- Explicit ban: D1 authorization ≠ moderation ≠ beneficial improvement  
- V3 0.20 = demo adequacy only; Wilson CIs required; failure stays failure  
- Demo ≠ OC Protocol v1.1  
- Commercial: P1 not universally 5%-calibrated; P2 = naive CR1-normal **interaction** only; low power at small G = limitation  

## Path C — dual readout (binding for commercial S2 language)

On randomized designs with a valid record:

1. **D1** reports only sharp-null rejection / non-rejection / abstention.  
2. **C1m** (OLS main effect of T) is the only series allowed to use “detected positive main-effect association/improvement under CRT” language in the demo pack.  
3. Side-by-side table is required; agreement is **not** required.

**v1.0.1 S2 confirmatory numbers remain the Path C evidence base** until a new approved run is executed.

## Path B — optional S2i (interaction alternative)

| Field | Spec |
|-------|------|
| ID | `S2i_randomized_interaction_alternative` |
| Truth | τ₀=0, β=0.35 |
| Design | Same CRT as S2 (G=12, n=5, ICC=0.20, valid record) |
| Replicates (if approved) | 500 |
| D1 metric | Authorization rate + Wilson CI |
| V3i | Same 0.20 demo floor on D1 rate (optional; report fail/pass honestly) |

S2i does **not** erase V3 failure on main-effect S2.

## Historical v1.0.1 confirmatory summary (frozen numbers)

| Scenario | n | Key rate | Wilson / notes |
|----------|---|----------|----------------|
| S1 primary success | 500 | 0.982 | (0.966, 0.991); reasons all missing_randomization_record |
| S2 D1 authorize | 500 | 0.046 | (0.031, 0.068); **V3 NOT MET** |
| S2 C1m sig pos | 500 | 0.312 | (0.273, 0.354) |
| S3 D1 Type I | 500 | 0.046 | (0.031, 0.068); abstain 0 |

## Approval

Smoke only until: `Approve Demo Protocol v1.0.2 as written.`  
Approving v1.0.2 adopts Path C for commercial language immediately; S2i runs only if explicitly requested after approval.
