# CRO Independent Demonstration Protocol v1.0.1

**Status:** APPROVED 2026-11-06 — confirmatory Stage 1–3 batches authorized under this freeze  
**Suggested approval phrase:** `Approve Demo Protocol v1.0.1 as written.`  
**Date:** 2026-11-06  
**Amends:** Demo Protocol v1.0  
**Relationship to OC:** This demonstration **does not replace** Phase 1 Operating-Characteristics Protocol v1.1 (or its 5,000/2,000 replication targets). Demo replicate counts (typically 200–500 per scenario) are **demonstration studies only**.

---

## 0. Purpose, scope, and non-claims

### Purpose

Produce a reproducible demonstration that an independent statistician can inspect, showing that the gated CRO Phase 1 decision rule (D1):

1. **Does not authorize** a design-based causal claim when there is **no authentic randomization record** (even if a conventional regression is significant under confounding).
2. Under a **declared complete cluster-randomized design**, implements an **exact randomization test of the sharp global null**, and reports authorization only as **rejection of that null** (not as moderation or proven benefit).
3. On a randomized null design, exhibits Type I behavior that can be compared to naive comparators.
4. Is reported with explicit **authorize / do-not-authorize / abstain** distinctions.

### Non-claims (binding)

- Not partner or production validation; not ROI proof.  
- Not automatic moderator discovery.  
- Synthetic demonstration evidence only (unless a later Stage 4 protocol is approved).  
- **P1 is an exact randomization procedure under stated design assumptions**, not a claim of universal 5% calibration in all finite samples.  
- **P2/C2 is only a naive CR1-normal *interaction* comparator** — not proof that “conventional statistics generally fail.”  
- **Low power at small \(G\) (e.g. \(G=8\), small \(N_A\)) is a limitation**, not evidence that genuine effects are absent.

---

## 1. Primary demonstration narrative

| Arm | Truth | Conventional C1 | D1 success criterion |
|-----|--------|------------------|----------------------|
| **A (S1)** | No effect; observational \(T\) induced by confounder | Often significant positive | **DO_NOT_AUTHORIZE** with reason ∈ `{missing_randomization_record, observational_assignment}` **and** C1 significant positive |
| **B (S2)** | Genuine **main** treatment effect under valid CRT | Recorded (main-effect C1m) | Rate of **`AUTHORIZE_DESIGN_BASED_REJECTION_OF_SHARP_NULL`** (see §2); **not** “moderation” or “beneficial improvement confirmed” |
| **Null (S3)** | Sharp null under valid CRT | — | D1 authorization rate as Type I metric (with Wilson CI); abstentions reported separately |

---

## 2. Decision rule D1 and comparators

### 2.1 D1 (primary)

**Design-eligible** (valid `randomization_record` + mechanism  
`complete_cluster_randomization_within_strata` + consistent strata / treated counts):

- Procedure: R23 `sharp_null_test` (exact-rational fixed-τ=0 path).  
- Null: sharp global null \(H_0: Y_i(1)=Y_i(0)\) for all units (under the declared randomization).  
- Outcomes:
  - **`AUTHORIZE_DESIGN_BASED_REJECTION_OF_SHARP_NULL`** iff not abstained and \(p < 0.05\).  
  - **`DO_NOT_AUTHORIZE`** iff abstained or \(p \ge 0.05\).  
  - **`ABSTAIN`** is recorded whenever the engine abstains; commercial tables must not fold abstain into “negative finding” without a separate column.

**Binding interpretation rule**

> Authorization means: the observed data are extreme under the sharp global null given the verified assignment mechanism and estimable allocation set.  
> It does **not** mean: moderation is established; a beneficial improvement is established; or an estimand-specific causal effect size is signed for policy.

**Design-ineligible** (no authentic record, observational assignment, etc.):

- D1 **must not** fabricate a `randomization_record`.  
- D1 **must not** run `sharp_null_test` as if a CRT existed.  
- Outcome: **`DO_NOT_AUTHORIZE`** with reason ∈  
  `{missing_randomization_record, observational_assignment, weak_overlap, insufficient_clusters, rank_deficient, other_abstain}`.  
- **`confounding_flag_demo` is forbidden as a primary success reason.** Hard-coded scenario labels must not drive D1.

### 2.2 Comparators (fixed)

| ID | Definition |
|----|------------|
| **C1** | Individual-level OLS of \(Y\) on \(T\); two-sided \(p\); “sig pos” if \(\hat\beta_T>0\) and \(p<0.05\) |
| **C1m** | Same as C1; **required on S2/S3** as the **main-effect** conventional comparator (genuine improvement language attaches only to C1m, never to D1 authorization) |
| **C2** | Cluster-robust CR1 **interaction** \(T\times M\) \(t\); naive normal \(p=2\Phi(-|t|)\). **Label in all outputs:** `naive_CR1_normal_interaction_comparator` |
| **C3** | Same coefficient as C2 analysis path but IID / ignore-cluster SE |

Do not generalize C2 failure modes to “all conventional methods.”

---

## 3. Stage 1 — Controlled scenarios

**Demo master seed:** `20261108`  
`SeedSequence([20261108, scenario_id, replicate_id, stream_role])` → PCG64.

Shared DGP (unless overridden):

\[
Y_{ic}=\mu+\gamma_{s(c)}+u_c+\varepsilon_{ic}+T_c(\tau_0+\beta M_c)+\mathbf{1}_{\mathrm{conf}}\delta C_c
\]

Marginal variance 1 at target ICC; \(\gamma_1=-0.15\), \(\gamma_2=+0.15\).

### S1 — Confounded false improvement (Arm A)

| Field | Spec |
|-------|------|
| ID | `S1_confounded_false_improvement` |
| Truth | \(\tau_0=0\), \(\beta=0\); \(\delta=0.6\); \(T_c=\mathbf{1}\{C_c>0\}\) |
| Record | **None** — no fake CRT metadata |
| G, n, ICC | 20, 10, 0.20 |
| Replicates (demo) | 500 |
| **Primary success** | Fraction with **C1 sig pos** ∧ **D1=DO_NOT_AUTHORIZE** ∧ **reason ∈ {missing_randomization_record, observational_assignment}** |
| Secondary | C1 sig rate; reason-code histogram |

### S2 — Randomized genuine **main effect** (Arm B)

| Field | Spec |
|-------|------|
| ID | `S2_randomized_genuine_main_effect` |
| Truth | \(\tau_0=0.35\), \(\beta=0\) (**main effect, not interaction**) |
| Assignment | Complete cluster randomization within 2 equal strata; half treated per stratum; **valid** `randomization_record` |
| G, n, ICC | 12, 5, 0.20 |
| Replicates (demo) | 500 |
| **D1 primary metric** | Rate of `AUTHORIZE_DESIGN_BASED_REJECTION_OF_SHARP_NULL` + Wilson 95% CI |
| **C1m primary metric** | Rate C1m detects positive main effect (conventional “improvement” story) |
| **Prohibited readout** | “D1 confirmed moderation”; “D1 confirmed beneficial improvement” |
| Note | Interaction-based sharp-null statistic may have **limited power** against pure main effects; report C1m and D1 **side by side** without forcing them to agree |

### S3 — Randomized sharp null (Type I)

| Field | Spec |
|-------|------|
| ID | `S3_randomized_sharp_null` |
| Truth | \(\tau_0=0\), \(\beta=0\) |
| Assignment | Same CRT machinery as S2; valid record |
| G, n, ICC | 12, 5, 0.20 |
| Replicates (demo) | 500 |
| **Primary** | Unconditional D1 authorization rate (Type I) + Wilson CI; **separate** abstention rate |
| Secondary | C2 / C3 false-positive rates as naive comparators only |

### S4 — Optional interaction arm (descriptive)

| Field | Spec |
|-------|------|
| ID | `S4_randomized_interaction` |
| Truth | \(\tau_0=0\), \(\beta=0.35\) |
| Design | Same CRT as S2 |
| Replicates | 200 (demo) |
| Metric | D1 authorization rate + Wilson CI (descriptive; **not** for tuning β) |

---

## 4. Stage 2 — Adversarial (summary; unchanged intent)

S5 wrong adjustment; S6 selection missingness; S7 weak overlap; S8 feedback poisoning (report limitation if undetected); S9 sparse observability.  
**200 demo replicates** each. D1 must remain record/eligibility driven where observational; no confounding-flag success path.

---

## 5. Stage 3 — Value tests

| ID | Statement | Support rule |
|----|-----------|--------------|
| **V1** | On S1, conventional C1 is often sig pos while D1 does not authorize **for record/eligibility reasons** | Primary S1 success rate high |
| **V2** | On S3, D1 Type I is closer to nominal than C2/C3 (descriptive) | Compare point estimates + CIs; no universal claim |
| **V3** | On S2, D1 authorization rate shows non-trivial sensitivity to the alternative **under this statistic** | Report \(\hat p\) **and Wilson 95% CI**. **Demo adequacy threshold:** \(\hat p \ge 0.20\) **or** CI excludes 0.05. **Missing the threshold is a reported demo failure.** Do not retune \(\tau_0\) or \(\beta\). The 0.20 level is a **demonstration adequacy threshold only**, not a product/clinical power requirement |

### Required result distinctions

Every scenario table must include separate columns:

1. `D1_authorize_sharp_null_rejection`  
2. `D1_do_not_authorize`  
3. `D1_abstain`  
4. Comparator sig rates (C1/C1m/C2/C3 as applicable)

---

## 6. Commercial reporting rules (P1 / P2 / small-G power)

When presenting OC or demo numbers commercially:

1. **P1:** Describe as an **exact randomization test of the sharp global null under the stated CRT assumptions and estimable allocation set**. Do **not** claim universal calibration at 5% for all \(G\) and all finite \(N_A\).  
2. **P2/C2:** Describe as **naive CR1-normal interaction comparator**. Do **not** claim conventional statistical methods generally fail.  
3. **Low power at \(G=8\)** (small discrete allocation space): state as a **design/statistic limitation**. Do **not** interpret as proof that genuine effects are absent.

---

## 7. Freeze, outputs, amendments

Before confirmatory demo execution:

1. Freeze this file; record SHA-256.  
2. Confirm R23 source hashes unchanged from research package (or record new hashes).  
3. Implement `DEMO/run_demo.py` with unit checks:  
   - S1 draw → no record → DO_NOT_AUTHORIZE with allowed reason codes only  
   - S2 draw → valid record → sharp_null_test runs; labels use `AUTHORIZE_DESIGN_BASED_REJECTION_OF_SHARP_NULL` only  

Outputs under `DEMO/`: RESULTS.json/csv, FIGURES/, REPORT.md, SEED_MANIFEST.json, REPRODUCE.md.

Amendments require v1.0.2+.

---

## 8. Approval gate

Smoke tests (≤5 replicates/scenario), labeled **smoke**, may run for integration.

Confirmatory Stage 1–3 batches require:

**`Approve Demo Protocol v1.0.1 as written.`**
