# R23 allocation exclusion audit (pinned source)

Source SHA-256: 92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6

## Findings
1. Rank of H(A) is design/pretreatment-only; rank failures exclude individual allocations.
2. Variance polynomial "identically zero" requires z1-all-zero (design) as well as z0 structure; not a pure Y-only silent drop when sum(z1^2)>0.
3. At tau=0, vm<=0 iff sum(z0^2)=0 (Y-dependent) → whole-test raise → ABSTAIN, not a reduced-universe p-value.
4. Probe (G=8, N_A=36): random Y → valid=36; zero/constant/T-only Y → ABSTAIN on observed estimability.

## Implication
Historical AUTHORIZE rates remain historical engine outputs; design-only exactness not retro-certified without retained-set logs.
