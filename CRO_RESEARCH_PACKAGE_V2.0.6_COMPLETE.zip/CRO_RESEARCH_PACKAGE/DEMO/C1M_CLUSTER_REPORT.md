# C1m_cluster synthetic evaluation report

**Date:** 2026-11-07T00:12:03.741906+00:00  
**Spec reference:** Predeclaration in Demonstration Specification v2.0.5 / earlier C1m_cluster section  
**Design:** G=12, n_per=5, ICC=0.20, complete cluster randomization within 2 strata  
**Replicates:** 500 per scenario | Seed namespace: demo_master_seed=20261108  
**Note:** Synthetic only — not partner validation. Does not change frozen v2.0.5 historical D1 rates.

## Procedure
- Model: Y ~ 1 + T + stratum FE (drop-first dummies)
- SE: cluster-robust CR1 for coefficient on T
- Primary p: two-sided normal reference, alpha=0.05
- Wald 95% CI using CR1 SE (computed per replicate in implementation)

## Results

### Main-effect alternative (tau0=0.35) — power snapshot
| Metric | Rate | Wilson 95% |
|--------|------|------------|
| C1m_cluster significant | **0.232** | (0.197, 0.271) |
| Abstain | 0.000 | — |
| C1_OLS_unclustered sig pos | 0.320 | — |

### Sharp null (tau0=0) — Type I snapshot
| Metric | Rate | Wilson 95% |
|--------|------|------------|
| C1m_cluster significant | **0.094** | (0.071, 0.123) |
| Abstain | 0.000 | — |
| C1_OLS_unclustered sig pos | 0.072 | — |

## Interpretation
- Under pure main effect, C1m_cluster detects more often (~23.2%) than historical D1 AUTHORIZE (~4.6%) on the same design family — expected because D1 uses an interaction functional.
- Type I at G=12 with CR1+normal reference is **inflated** (~9.4% vs 5%). Treat as approximate; do not market as exact 5% calibration.
- Still **not** a moderation claim. Still **not** a substitute for D1’s design-gated sharp-null authorization.

## Commercial use under frozen v2.0.5
Allowed: report C1m_cluster as a **separate cluster-robust main-effect readout** with these synthetic operating characteristics.  
Forbidden: imply D1 V3 is cured; imply CRT-exactness of normal CR1 p-values at G=12.
