# Technical appendix

- Main product archive: CRO v0.6.16-DEV (unchanged bytes).
- Phase 1: R23 exact-rational `sharp_null_test` / `constant_effect_inversion` using Fraction + SymPy QQ isolation.
- Legacy float `cluster_permutation_test` retained for compatibility; not the confirmatory P1 reference.
- OC Protocol v1.1: confirmatory P1 for G∈{8,12}; G=40 unavailable without verified exact-rational MC.
- Primary p-value: design-based exact enumeration under complete cluster randomization within strata.
