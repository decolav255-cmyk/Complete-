# Install and run

```bash
# Verify originals
sha256sum -c CHECKSUMS.sha256

# Phase 1 tests
cd SOURCE
pip install numpy sympy  # sklearn optional for imputation path
PYTHONPATH=. python -m pytest -q tests/test_pooled_screen.py

# OC cell example
cd ..
PYTHONPATH=SOURCE python OC/run_oc_cell.py --G 8 --n 5 --icc 0.05 --beta 0 --reps 50 --scenario sharp_null
```

Main CRO archive: extract `ORIGINALS/CRO_v0.6.16_DEV_VALIDATED.zip` and run its own test suite.
