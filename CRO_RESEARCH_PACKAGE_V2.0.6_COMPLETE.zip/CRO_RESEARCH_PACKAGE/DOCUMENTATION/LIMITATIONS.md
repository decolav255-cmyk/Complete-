# Limitations (authoritative short list)

1. Synthetic demonstration and partial OC only — not partner or production validation.
2. Demo n=500 ≠ OC Protocol v1.1 targets (5,000 / 2,000).
3. D1 authorization = rejection of sharp global null under a verified CRT record only — **not** moderation, **not** signed beneficial improvement.
4. Against pure main effects, interaction-based sharp-null rejection can have **low power** (V3 failed on S2 under v1.0.1). That is a limitation, not proof effects are absent.
5. At small G / small allocation spaces (e.g. G=8, N_A=36), exact tests are discrete and can be conservative.
6. P2 / C2 is a **naive CR1-normal interaction** comparator only — not an indictment of all conventional methods.
7. R23 exact path requires complete finite data and a reproducible randomization_record for design-eligible tests.
8. No missing-data correction in the exact-rational path.
