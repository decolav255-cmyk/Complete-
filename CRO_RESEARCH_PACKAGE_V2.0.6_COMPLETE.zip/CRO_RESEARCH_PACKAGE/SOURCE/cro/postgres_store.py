"""PostgreSQL SERIALIZABLE transaction store for CRO's durable outbox.

This module intentionally implements the outbox contract only. It is not a
claim that SQLite-specific policy/engine/authority/receiver schemas have been
migrated to PostgreSQL.
"""
from __future__ import annotations

from contextlib import contextmanager
import time
from typing import Callable, TypeVar

T = TypeVar("T")


class _CursorAdapter:
    """Small DB-API adapter for the qmark SQL used by the outbox contract."""
    def __init__(self, cursor):
        self._cursor = cursor

    def execute(self, sql, params=()):
        out, quote, i = [], None, 0
        while i < len(sql):
            c = sql[i]
            if quote:
                out.append(c)
                if c == quote:
                    if i + 1 < len(sql) and sql[i + 1] == quote:
                        out.append(sql[i + 1]); i += 1
                    else:
                        quote = None
            elif c in ("'", '"'):
                quote = c; out.append(c)
            elif c == "?":
                out.append("%s")
            else:
                out.append(c)
            i += 1
        self._cursor.execute("".join(out), params)
        return self

    def fetchone(self): return self._cursor.fetchone()
    def fetchall(self): return self._cursor.fetchall()


class PostgresDurableStore:
    """PostgreSQL store with explicit SERIALIZABLE transactions.

    `run_serializable` retries only PostgreSQL serialization/deadlock errors;
    callers must keep the callback free of non-transactional side effects.
    """
    RETRYABLE_SQLSTATES = {"40001", "40P01"}

    def __init__(self, dsn: str, *, connect_timeout: int = 10):
        if not isinstance(dsn, str) or not dsn.strip():
            raise ValueError("PostgreSQL DSN is required")
        try:
            import psycopg
        except ImportError as e:
            raise RuntimeError("Install optional dependency psycopg[binary]>=3.1") from e
        self._psycopg = psycopg
        self._conn = psycopg.connect(dsn, autocommit=True, connect_timeout=connect_timeout)
        with self._conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS durable_outbox (
                    id TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at DOUBLE PRECISION NOT NULL DEFAULT EXTRACT(EPOCH FROM clock_timestamp()),
                    updated_at DOUBLE PRECISION NOT NULL DEFAULT EXTRACT(EPOCH FROM clock_timestamp())
                )
            """)

    @contextmanager
    def atomic_transaction(self):
        """Yield a qmark-compatible cursor inside a SERIALIZABLE transaction."""
        with self._conn.transaction():
            with self._conn.cursor() as cur:
                cur.execute("SET TRANSACTION ISOLATION LEVEL SERIALIZABLE")
                yield _CursorAdapter(cur)

    def run_serializable(self, operation: Callable, *, max_attempts: int = 5, base_delay: float = 0.025):
        """Run a database-only callback with bounded serialization retries."""
        if not callable(operation):
            raise TypeError("operation must be callable")
        if isinstance(max_attempts, bool) or not isinstance(max_attempts, int) or max_attempts < 1 or max_attempts > 10:
            raise ValueError("max_attempts must be an integer between 1 and 10")
        for attempt in range(max_attempts):
            try:
                with self.atomic_transaction() as tx:
                    result = operation(tx)
                return result
            except self._psycopg.Error as exc:
                sqlstate = getattr(exc, "sqlstate", None)
                if sqlstate not in self.RETRYABLE_SQLSTATES or attempt + 1 >= max_attempts:
                    raise
                time.sleep(base_delay * (2 ** attempt))

    def close(self):
        self._conn.close()
