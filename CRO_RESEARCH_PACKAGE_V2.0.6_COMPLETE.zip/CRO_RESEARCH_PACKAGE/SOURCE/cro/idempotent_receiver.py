"""Reference side-effect receiver: verifies CRO fencing tokens and deduplicates effects."""
from __future__ import annotations
import base64, hashlib, json, math, sqlite3, time
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric import ed25519
from cro.trace_integrity import canonical_serialize
from cro.postgres_compat import PostgresConnection, retry_postgres_serialization

class IdempotentReceiver:
    def __init__(self, db_path: str, authority_public_key: ed25519.Ed25519PublicKey,
                 authority_epoch_provider=None, *, require_shared_postgres: bool = True):
        """
        Pilot invariant (default): authority and receiver share one PostgreSQL database.
        authority_state is read inside the receiver SERIALIZABLE transaction.
        An external epoch callback is never treated as an atomic substitute under the pilot path.
        Laboratory escape hatch: require_shared_postgres=False requires a callable provider.
        """
        if not isinstance(db_path, str) or not db_path.strip():
            raise ValueError("db_path is required")
        self.db_path = db_path
        self.public_key = authority_public_key
        self.require_shared_postgres = bool(require_shared_postgres)
        self._is_postgres = db_path.startswith(("postgres://", "postgresql://"))

        if self.require_shared_postgres:
            if not self._is_postgres:
                raise ValueError(
                    "CRO pilot requires shared PostgreSQL: receiver DSN must be "
                    "postgres:// or postgresql:// so authority_state can be read "
                    "atomically inside the effect transaction"
                )
            self.authority_epoch_provider = None
        else:
            if not callable(authority_epoch_provider):
                raise ValueError(
                    "authority_epoch_provider is required when require_shared_postgres=False (lab only)"
                )
            self.authority_epoch_provider = authority_epoch_provider

        db = PostgresConnection(db_path) if self._is_postgres else sqlite3.connect(db_path)
        try:
            with db:
                db.execute("CREATE TABLE IF NOT EXISTS receiver_epochs(candidate_id TEXT PRIMARY KEY, epoch INTEGER NOT NULL)")
                db.execute(
                    "CREATE TABLE IF NOT EXISTS receiver_effects("
                    "idempotency_key TEXT PRIMARY KEY, candidate_id TEXT NOT NULL, "
                    "epoch INTEGER NOT NULL, payload_hash TEXT NOT NULL, "
                    "response_json TEXT NOT NULL, committed_at REAL NOT NULL)"
                )
        finally:
            db.close()

    @retry_postgres_serialization(dsn_attr="db_path")
    def accept(self, idempotency_key: str, token: dict, payload: dict) -> dict:
        if not isinstance(idempotency_key, str) or not idempotency_key.strip() or len(idempotency_key) > 200:
            raise ValueError("valid idempotency_key required")
        if not isinstance(token, dict) or set(token) != {"claims", "signature_b64"}:
            raise ValueError("malformed token")
        claims = token["claims"]
        try:
            signature = base64.b64decode(token["signature_b64"], validate=True)
        except Exception as e:
            raise ValueError("malformed token signature") from e
        raw = canonical_serialize(claims)
        try:
            self.public_key.verify(signature, b"CRO_LEASE_AUTH_V1" + len(raw).to_bytes(8, "big") + raw)
        except InvalidSignature as e:
            raise PermissionError("invalid authority signature") from e
        issued_at, expires_at = claims.get("issued_at"), claims.get("expires_at")
        authority_epoch = claims.get("authority_epoch")
        nonce = claims.get("nonce")
        if (isinstance(issued_at, bool) or not isinstance(issued_at, (int, float)) or not math.isfinite(float(issued_at))
                or isinstance(expires_at, bool) or not isinstance(expires_at, (int, float)) or not math.isfinite(float(expires_at))
                or isinstance(authority_epoch, bool) or not isinstance(authority_epoch, int) or authority_epoch < 0
                or not isinstance(nonce, str) or not nonce):
            raise ValueError("invalid authority lease claims")
        cid, worker, epoch = claims.get("candidate_id"), claims.get("worker_id"), claims.get("epoch")
        if (not isinstance(cid, str) or not cid or not isinstance(worker, str) or not worker
                or isinstance(epoch, bool) or not isinstance(epoch, int) or epoch < 0):
            raise ValueError("invalid lease claims")
        payload_raw = canonical_serialize(payload)
        payload_hash = hashlib.sha256(payload_raw).hexdigest()
        db = (PostgresConnection(self.db_path) if self._is_postgres
              else sqlite3.connect(self.db_path, timeout=15, isolation_level=None))
        try:
            db.execute("BEGIN IMMEDIATE")
            try:
                prior = db.execute(
                    "SELECT candidate_id,epoch,payload_hash,response_json FROM receiver_effects WHERE idempotency_key=?",
                    (idempotency_key,),
                ).fetchone()
                if prior:
                    if prior[:3] != (cid, epoch, payload_hash):
                        raise ValueError("idempotency key reused with different request")
                    db.commit()
                    return json.loads(prior[3])
                now = time.time()
                if expires_at <= now or issued_at > now + 1.5 or expires_at <= issued_at or expires_at - issued_at > 60:
                    raise PermissionError("expired, future-dated, or overlong lease")
                # Pilot path: authority_state must be readable from the same PostgreSQL
                # database inside this SERIALIZABLE transaction. External callbacks are
                # never used as an atomic substitute under require_shared_postgres=True.
                if self.require_shared_postgres:
                    if not isinstance(db, PostgresConnection):
                        raise PermissionError("shared-PostgreSQL invariant violated at accept time")
                    live_row = db.execute("SELECT authority_epoch FROM authority_state WHERE id=1").fetchone()
                    if live_row is None:
                        raise PermissionError("authority state unavailable; refusing closed")
                    live_epoch = int(live_row[0])
                else:
                    live_epoch = self.authority_epoch_provider()
                if (isinstance(live_epoch, bool) or not isinstance(live_epoch, int)
                        or live_epoch != claims.get("authority_epoch")):
                    raise PermissionError("lease invalidated by current authority epoch")
                current = db.execute("SELECT epoch FROM receiver_epochs WHERE candidate_id=?", (cid,)).fetchone()
                if current and epoch < current[0]:
                    raise PermissionError("stale fencing epoch")
                db.execute(
                    "INSERT INTO receiver_epochs(candidate_id,epoch) VALUES(?,?) "
                    "ON CONFLICT(candidate_id) DO UPDATE SET epoch=MAX(epoch,excluded.epoch)",
                    (cid, epoch),
                )
                response = {
                    "accepted": True,
                    "idempotency_key": idempotency_key,
                    "candidate_id": cid,
                    "worker_id": worker,
                    "epoch": epoch,
                    "payload_sha256": payload_hash,
                }
                inserted = db.execute(
                    "INSERT INTO receiver_effects VALUES(?,?,?,?,?,?) ON CONFLICT(idempotency_key) DO NOTHING",
                    (idempotency_key, cid, epoch, payload_hash, json.dumps(response, separators=(",", ":")), now),
                )
                if inserted.rowcount == 0:
                    raced = db.execute(
                        "SELECT candidate_id,epoch,payload_hash,response_json FROM receiver_effects WHERE idempotency_key=?",
                        (idempotency_key,),
                    ).fetchone()
                    if raced is None or raced[:3] != (cid, epoch, payload_hash):
                        raise ValueError("idempotency key reused with different request")
                    response = json.loads(raced[3])
                db.commit()
                return response
            except BaseException:
                db.rollback()
                raise
        finally:
            db.close()
