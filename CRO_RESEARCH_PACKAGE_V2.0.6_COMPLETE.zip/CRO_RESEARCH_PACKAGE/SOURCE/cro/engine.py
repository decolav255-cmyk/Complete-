"""Durable execution lifecycle state machine with atomic persisted transitions (G3)."""
from __future__ import annotations

from enum import Enum
import sqlite3
import time
from cro.postgres_compat import retry_postgres_serialization


class EngineState(Enum):
    INIT = "INIT"
    PREPARING = "PREPARING"
    RUNNING = "RUNNING"
    RECOVERY_PENDING = "RECOVERY_PENDING"
    AUDIT_COMMITTED = "AUDIT_COMMITTED"
    DECISION_RELEASED = "DECISION_RELEASED"
    MARK_FAILED = "MARK_FAILED"
    REJECTED = "REJECTED"
    COMPLETED = "COMPLETED"
    FAILED_TERMINAL = "FAILED_TERMINAL"


class DurableEngine:
    TERMINAL_STATES = {
        EngineState.DECISION_RELEASED, EngineState.MARK_FAILED,
        EngineState.REJECTED, EngineState.COMPLETED, EngineState.FAILED_TERMINAL,
    }
    TRANSITION_RULES = {
        EngineState.INIT: {EngineState.PREPARING, EngineState.RECOVERY_PENDING, EngineState.FAILED_TERMINAL, EngineState.REJECTED},
        EngineState.PREPARING: {EngineState.RUNNING, EngineState.RECOVERY_PENDING, EngineState.MARK_FAILED, EngineState.REJECTED},
        EngineState.RUNNING: {EngineState.AUDIT_COMMITTED, EngineState.DECISION_RELEASED, EngineState.RECOVERY_PENDING, EngineState.MARK_FAILED, EngineState.REJECTED},
        EngineState.AUDIT_COMMITTED: {EngineState.DECISION_RELEASED, EngineState.COMPLETED, EngineState.RECOVERY_PENDING, EngineState.MARK_FAILED},
        EngineState.RECOVERY_PENDING: {EngineState.RUNNING, EngineState.MARK_FAILED, EngineState.FAILED_TERMINAL},
        EngineState.DECISION_RELEASED: set(), EngineState.MARK_FAILED: set(),
        EngineState.REJECTED: set(), EngineState.COMPLETED: set(), EngineState.FAILED_TERMINAL: set(),
    }

    def __init__(self, db_conn: sqlite3.Connection, job_id: str):
        if not isinstance(job_id, str) or not job_id.strip():
            raise ValueError("job_id must be a non-empty string")
        self.conn = db_conn
        self.job_id = job_id
        self._init_schema()
        self.state = self._load_persisted_state()

    def _init_schema(self) -> None:
        with self.conn:
            self.conn.execute("""CREATE TABLE IF NOT EXISTS engine_states (
                job_id TEXT PRIMARY KEY, state TEXT NOT NULL, reason TEXT)""")
            self.conn.execute("""CREATE TABLE IF NOT EXISTS state_transition_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT, job_id TEXT NOT NULL,
                from_state TEXT NOT NULL, to_state TEXT NOT NULL,
                reason TEXT, timestamp REAL NOT NULL)""")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS state_transition_log_no_update BEFORE UPDATE ON state_transition_log BEGIN SELECT RAISE(ABORT,'append-only transition log'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS state_transition_log_no_delete BEFORE DELETE ON state_transition_log BEGIN SELECT RAISE(ABORT,'append-only transition log'); END")

    def _load_persisted_state(self) -> EngineState:
        row = self.conn.execute("SELECT state FROM engine_states WHERE job_id=?", (self.job_id,)).fetchone()
        return EngineState(row[0]) if row else EngineState.INIT

    @retry_postgres_serialization(connection_attr="conn")
    def transition(self, target_state: EngineState, reason: str = "") -> None:
        if not isinstance(target_state, EngineState):
            raise TypeError("target_state must be an EngineState")
        if self.conn.in_transaction:
            raise RuntimeError("transition requires a connection with no active transaction")
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            row = self.conn.execute("SELECT state FROM engine_states WHERE job_id=?", (self.job_id,)).fetchone()
            current = EngineState(row[0]) if row else EngineState.INIT
            if target_state not in self.TRANSITION_RULES[current]:
                raise RuntimeError(f"invalid lifecycle transition: {current.value} -> {target_state.value}")
            now = time.time()
            self.conn.execute(
                """INSERT INTO engine_states(job_id,state,reason) VALUES(?,?,?)
                   ON CONFLICT(job_id) DO UPDATE SET state=excluded.state,reason=excluded.reason""",
                (self.job_id, target_state.value, reason),
            )
            self.conn.execute(
                "INSERT INTO state_transition_log(job_id,from_state,to_state,reason,timestamp) VALUES(?,?,?,?,?)",
                (self.job_id, current.value, target_state.value, reason, now),
            )
            self.conn.commit()
            self.state = target_state
        except BaseException:
            self.conn.rollback()
            self.state = self._load_persisted_state()
            raise
