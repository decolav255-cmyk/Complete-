"""Canonical serialization, Ed25519 verification, and append-only key history (G2)."""
from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from typing import Any, Dict, Optional
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.exceptions import InvalidSignature
from cro.postgres_compat import retry_postgres_serialization

DOMAIN_EVENT = b"CRO_EVENT_BINDING_V1"
DOMAIN_DATASET = b"CRO_DATASET_BINDING_V1"
DOMAIN_PROTOCOL = b"CRO_PROTOCOL_BINDING_V1"
DOMAIN_CHECKPOINT = b"CRO_CHECKPOINT_BINDING_V1"
DOMAIN_MANIFEST = b"CRO_MANIFEST_BINDING_V1"


def canonical_serialize(data: Dict[str, Any]) -> bytes:
    """Serialize a JSON-compatible object deterministically; reject ambiguous values."""
    if not isinstance(data, dict):
        raise TypeError("canonical serialization requires a dictionary at the top level")

    def sanitize(obj: Any) -> Any:
        if isinstance(obj, dict):
            for key in obj:
                if not isinstance(key, str):
                    raise TypeError(f"non-string dictionary key rejected: {type(key).__name__}")
            return {key: sanitize(obj[key]) for key in sorted(obj)}
        if isinstance(obj, list):
            return [sanitize(value) for value in obj]
        if isinstance(obj, float):
            if not __import__("math").isfinite(obj):
                raise ValueError("non-finite floats are not permitted")
            return obj
        if obj is None or isinstance(obj, (str, int, bool)):
            return obj
        raise TypeError(f"unsupported canonical JSON type: {type(obj).__name__}")

    return json.dumps(
        sanitize(data), sort_keys=True, separators=(",", ":"),
        ensure_ascii=False, allow_nan=False,
    ).encode("utf-8")


class DurableKeyHistoryManager:
    def __init__(self, db_conn: sqlite3.Connection, root_admin_key_id: str,
                 root_public_key: ed25519.Ed25519PublicKey):
        if not root_admin_key_id or not isinstance(root_admin_key_id, str):
            raise ValueError("root_admin_key_id must be a non-empty string")
        self.conn = db_conn
        self.root_admin_key_id = root_admin_key_id
        self._init_schema()
        self._ensure_root_key(root_admin_key_id, root_public_key)

    @retry_postgres_serialization(connection_attr="conn")
    def _init_schema(self) -> None:
        with self.conn:
            self.conn.execute("""CREATE TABLE IF NOT EXISTS trusted_keys (
                key_id TEXT PRIMARY KEY, public_bytes BLOB NOT NULL,
                added_at REAL NOT NULL, enrolled_by TEXT NOT NULL)""")
            self.conn.execute("""CREATE TABLE IF NOT EXISTS trusted_key_history (
                sequence INTEGER PRIMARY KEY AUTOINCREMENT, key_id TEXT NOT NULL,
                public_sha256 TEXT NOT NULL, action TEXT NOT NULL,
                recorded_at REAL NOT NULL, enrolled_by TEXT NOT NULL)""")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS trusted_key_history_no_update BEFORE UPDATE ON trusted_key_history BEGIN SELECT RAISE(ABORT,'append-only key history'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS trusted_key_history_no_delete BEFORE DELETE ON trusted_key_history BEGIN SELECT RAISE(ABORT,'append-only key history'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS trusted_keys_no_update BEFORE UPDATE ON trusted_keys BEGIN SELECT RAISE(ABORT,'trusted key records are immutable'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS trusted_keys_no_delete BEFORE DELETE ON trusted_keys BEGIN SELECT RAISE(ABORT,'trusted key records are immutable'); END")
            self.conn.execute("""CREATE TABLE IF NOT EXISTS revoked_keys (
                key_id TEXT PRIMARY KEY, revoked_at REAL NOT NULL,
                revoked_by TEXT NOT NULL, reason TEXT NOT NULL)""")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS revoked_keys_no_update BEFORE UPDATE ON revoked_keys BEGIN SELECT RAISE(ABORT,'revoked key records are immutable'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS revoked_keys_no_delete BEFORE DELETE ON revoked_keys BEGIN SELECT RAISE(ABORT,'revoked key records are immutable'); END")

    @staticmethod
    def _public_bytes(key: ed25519.Ed25519PublicKey) -> bytes:
        return key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)

    @retry_postgres_serialization(connection_attr="conn")
    def _ensure_root_key(self, key_id: str, key: ed25519.Ed25519PublicKey) -> None:
        raw = self._public_bytes(key)
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            row = self.conn.execute("SELECT public_bytes FROM trusted_keys WHERE key_id=?", (key_id,)).fetchone()
            if row and row[0] != raw:
                raise RuntimeError("root key ID already exists with different public-key material")
            if row is None:
                now = time.time()
                inserted = self.conn.execute(
                    "INSERT INTO trusted_keys VALUES(?,?,?,?) ON CONFLICT(key_id) DO NOTHING",
                    (key_id, raw, now, "ROOT_INIT"),
                )
                if inserted.rowcount:
                    self.conn.execute(
                        "INSERT INTO trusted_key_history(key_id,public_sha256,action,recorded_at,enrolled_by) VALUES(?,?,?,?,?)",
                        (key_id, hashlib.sha256(raw).hexdigest(), "ENROLLED_ROOT", now, "ROOT_INIT"),
                    )
                else:
                    raced = self.conn.execute("SELECT public_bytes FROM trusted_keys WHERE key_id=?", (key_id,)).fetchone()
                    if raced is None or raced[0] != raw:
                        raise RuntimeError("root key ID concurrently enrolled with different public-key material")
            self.conn.commit()
        except BaseException:
            self.conn.rollback()
            raise

    def get_public_key_bytes(self, key_id: str) -> Optional[bytes]:
        if self.conn.execute("SELECT 1 FROM revoked_keys WHERE key_id=?", (key_id,)).fetchone():
            return None
        row = self.conn.execute("SELECT public_bytes FROM trusted_keys WHERE key_id=?", (key_id,)).fetchone()
        return row[0] if row else None

    @retry_postgres_serialization(connection_attr="conn")
    def add_trusted_key_authorized(self, admin_key_id: str, admin_signature: bytes,
                                   new_key_id: str, new_public_key: ed25519.Ed25519PublicKey) -> None:
        if not isinstance(new_key_id, str) or not new_key_id.strip():
            raise ValueError("new_key_id must be a non-empty string")
        raw = self._public_bytes(new_public_key)
        payload = {"admin_key_id": admin_key_id, "new_key_id": new_key_id, "new_pub_hex": raw.hex()}
        serialized = canonical_serialize(payload)
        message = b"CRO_KEY_ENROLL_V1" + len(serialized).to_bytes(8, "big") + serialized
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            if self.conn.execute("SELECT 1 FROM trusted_keys WHERE key_id=?", (new_key_id,)).fetchone():
                raise ValueError(f"key ID collision rejected: {new_key_id}")
            admin_raw = self.get_public_key_bytes(admin_key_id)
            if admin_raw is None:
                raise PermissionError(f"unknown admin key: {admin_key_id}")
            try:
                ed25519.Ed25519PublicKey.from_public_bytes(admin_raw).verify(admin_signature, message)
            except InvalidSignature as exc:
                raise PermissionError("key enrollment denied: invalid administrator signature") from exc
            now = time.time()
            self.conn.execute("INSERT INTO trusted_keys VALUES(?,?,?,?)", (new_key_id, raw, now, admin_key_id))
            self.conn.execute(
                "INSERT INTO trusted_key_history(key_id,public_sha256,action,recorded_at,enrolled_by) VALUES(?,?,?,?,?)",
                (new_key_id, hashlib.sha256(raw).hexdigest(), "ENROLLED", now, admin_key_id),
            )
            self.conn.commit()
        except BaseException:
            self.conn.rollback()
            raise

    @retry_postgres_serialization(connection_attr="conn")
    def revoke_trusted_key_authorized(self, admin_key_id: str, admin_signature: bytes,
                                      target_key_id: str, reason: str) -> None:
        """Append-only revocation. Requires a valid non-revoked administrator signature.

        Already-revoked targets still require valid admin authorization before
        returning success (idempotent only after authorization succeeds).
        Root administrator key cannot be revoked through this path.
        """
        if not isinstance(target_key_id, str) or not target_key_id.strip():
            raise ValueError("target_key_id must be a non-empty string")
        if not isinstance(reason, str) or not reason.strip():
            raise ValueError("revocation reason is required")
        if target_key_id == self.root_admin_key_id:
            raise PermissionError("root admin key cannot be revoked through this path")
        payload = {"admin_key_id": admin_key_id, "target_key_id": target_key_id, "reason": reason}
        serialized = canonical_serialize(payload)
        message = b"CRO_KEY_REVOKE_V1" + len(serialized).to_bytes(8, "big") + serialized
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            # Administrator must be known and not revoked.
            admin_row = self.conn.execute(
                "SELECT public_bytes FROM trusted_keys WHERE key_id=?", (admin_key_id,)
            ).fetchone()
            if admin_row is None:
                raise PermissionError(f"unknown admin key: {admin_key_id}")
            if self.conn.execute("SELECT 1 FROM revoked_keys WHERE key_id=?", (admin_key_id,)).fetchone():
                raise PermissionError(f"revoked admin key: {admin_key_id}")
            try:
                ed25519.Ed25519PublicKey.from_public_bytes(admin_row[0]).verify(admin_signature, message)
            except InvalidSignature as exc:
                raise PermissionError("key revocation denied: invalid administrator signature") from exc

            already = self.conn.execute(
                "SELECT 1 FROM revoked_keys WHERE key_id=?", (target_key_id,)
            ).fetchone()
            if already:
                # Authorization already verified; idempotent success.
                self.conn.commit()
                return

            enrolled = self.conn.execute(
                "SELECT public_bytes FROM trusted_keys WHERE key_id=?", (target_key_id,)
            ).fetchone()
            if enrolled is None:
                raise ValueError(f"unknown key: {target_key_id}")

            now = time.time()
            self.conn.execute(
                "INSERT INTO revoked_keys(key_id,revoked_at,revoked_by,reason) VALUES(?,?,?,?)",
                (target_key_id, now, admin_key_id, reason),
            )
            self.conn.execute(
                "INSERT INTO trusted_key_history(key_id,public_sha256,action,recorded_at,enrolled_by) VALUES(?,?,?,?,?)",
                (target_key_id, hashlib.sha256(enrolled[0]).hexdigest(), "REVOKED", now, admin_key_id),
            )
            self.conn.commit()
        except BaseException:
            self.conn.rollback()
            raise

    def verify_signature(self, key_id: str, domain_tag: bytes,
                         payload: Dict[str, Any], signature: bytes) -> bool:
        raw = self.get_public_key_bytes(key_id)
        if raw is None:
            return False
        serialized = canonical_serialize(payload)
        message = domain_tag + len(serialized).to_bytes(8, "big") + serialized
        try:
            ed25519.Ed25519PublicKey.from_public_bytes(raw).verify(signature, message)
            return True
        except InvalidSignature:
            return False


def sign_payload(private_key: ed25519.Ed25519PrivateKey, domain_tag: bytes,
                 payload: Dict[str, Any]) -> bytes:
    """Sign canonical payload bytes with domain separation and 8-byte length framing."""
    if not isinstance(domain_tag, bytes) or not domain_tag:
        raise ValueError("a non-empty bytes domain tag is required")
    serialized = canonical_serialize(payload)
    return private_key.sign(domain_tag + len(serialized).to_bytes(8, "big") + serialized)


def verify_payload(public_key: ed25519.Ed25519PublicKey, domain_tag: bytes,
                   payload: Dict[str, Any], signature: bytes) -> bool:
    """Verify a domain-separated canonical payload signature."""
    if not isinstance(signature, bytes) or len(signature) != 64:
        return False
    serialized = canonical_serialize(payload)
    message = domain_tag + len(serialized).to_bytes(8, "big") + serialized
    try:
        public_key.verify(signature, message)
        return True
    except InvalidSignature:
        return False


def sign_release_manifest(manifest: Dict[str, Any],
                          private_key: ed25519.Ed25519PrivateKey) -> Dict[str, Any]:
    """Create a detached Ed25519 signature over a manifest with validated SHA-256 entries."""
    files = manifest.get("files") if isinstance(manifest, dict) else None
    if not isinstance(files, dict):
        raise ValueError("release manifest must contain a files mapping")
    for path, digest in files.items():
        if (not isinstance(path, str) or not path or not isinstance(digest, str)
                or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest)):
            raise ValueError(f"invalid SHA-256 manifest entry for {path!r}")
    return {"manifest": manifest, "signature": sign_payload(private_key, DOMAIN_MANIFEST, manifest)}


def verify_release_manifest(signed_manifest: Dict[str, Any],
                            public_key: ed25519.Ed25519PublicKey,
                            file_bytes_by_path: Optional[Dict[str, bytes]] = None) -> bool:
    """Verify the detached manifest signature and, if supplied, each listed file hash."""
    if not isinstance(signed_manifest, dict) or set(signed_manifest) != {"manifest", "signature"}:
        return False
    manifest = signed_manifest["manifest"]
    if not verify_payload(public_key, DOMAIN_MANIFEST, manifest, signed_manifest["signature"]):
        return False
    if file_bytes_by_path is None:
        return True
    files = manifest.get("files") if isinstance(manifest, dict) else None
    if not isinstance(files, dict) or set(files) != set(file_bytes_by_path):
        return False
    for path, raw in file_bytes_by_path.items():
        if not isinstance(raw, bytes) or hashlib.sha256(raw).hexdigest() != files[path]:
            return False
    return True
