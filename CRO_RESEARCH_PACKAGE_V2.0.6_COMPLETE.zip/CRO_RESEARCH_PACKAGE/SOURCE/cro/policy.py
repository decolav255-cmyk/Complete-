"""Durable lease reservation and atomic downstream fencing (G1/G4)."""
from __future__ import annotations

import sqlite3
import time
import secrets
from typing import Callable, TypeVar
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.exceptions import InvalidSignature
from cro.trace_integrity import canonical_serialize
from cro.postgres_compat import retry_postgres_serialization

T = TypeVar("T")


class DurablePolicyManager:
    def __init__(self, db_conn: sqlite3.Connection, ttl_seconds: int = 60,
                 rollback_tolerance: float = 1.5, require_authority: bool = True):
        if isinstance(ttl_seconds, bool) or not isinstance(ttl_seconds, int) or ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be a positive integer")
        self.conn = db_conn
        self.ttl_seconds = ttl_seconds
        self.rollback_tolerance = float(rollback_tolerance)
        self.require_authority = bool(require_authority)
        self._last_monotonic = time.monotonic()
        self._init_schema()

    def _init_schema(self) -> None:
        with self.conn:
            self.conn.execute("""CREATE TABLE IF NOT EXISTS reservations (
                candidate_id TEXT PRIMARY KEY, worker_id TEXT NOT NULL,
                epoch INTEGER NOT NULL CHECK(epoch >= 0), expires_at REAL NOT NULL,
                authorized_at REAL NOT NULL)""")
            self.conn.execute("""CREATE TABLE IF NOT EXISTS policy_clock_watermark (
                id INTEGER PRIMARY KEY CHECK(id=1), max_observed_wall REAL NOT NULL)""")
            self.conn.execute("""CREATE TABLE IF NOT EXISTS reservation_history (
                sequence INTEGER PRIMARY KEY AUTOINCREMENT, candidate_id TEXT NOT NULL,
                worker_id TEXT NOT NULL, epoch INTEGER NOT NULL, action TEXT NOT NULL,
                recorded_at REAL NOT NULL)""")
            self.conn.execute("""CREATE TABLE IF NOT EXISTS fenced_mutation_log (
                sequence INTEGER PRIMARY KEY AUTOINCREMENT, candidate_id TEXT NOT NULL,
                worker_id TEXT NOT NULL, epoch INTEGER NOT NULL, recorded_at REAL NOT NULL)""")
            self.conn.execute("""CREATE TABLE IF NOT EXISTS authority_state (
                id INTEGER PRIMARY KEY CHECK(id=1), authority_epoch INTEGER NOT NULL)""")
            self.conn.execute("INSERT OR IGNORE INTO authority_state(id,authority_epoch) VALUES(1,0)")
            self.conn.execute("""CREATE TABLE IF NOT EXISTS revoked_workers (
                worker_id TEXT PRIMARY KEY, revoked_at REAL NOT NULL, reason TEXT NOT NULL,
                authority_epoch INTEGER NOT NULL)""")
            self.conn.execute("""CREATE TABLE IF NOT EXISTS authority_audit (
                sequence INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL,
                worker_id TEXT NOT NULL, candidate_id TEXT, authority_epoch INTEGER NOT NULL,
                recorded_at REAL NOT NULL, detail TEXT NOT NULL)""")
            self.conn.execute("CREATE TABLE IF NOT EXISTS consumed_authority_tokens (nonce TEXT PRIMARY KEY, consumed_at REAL NOT NULL)")
            self.conn.execute("CREATE TABLE IF NOT EXISTS reservations (candidate_id TEXT PRIMARY KEY, worker_id TEXT NOT NULL, epoch INTEGER NOT NULL CHECK(epoch >= 0), expires_at REAL NOT NULL, authorized_at REAL NOT NULL)")
            self.conn.execute("CREATE TABLE IF NOT EXISTS reservation_history (sequence INTEGER PRIMARY KEY AUTOINCREMENT, candidate_id TEXT NOT NULL, worker_id TEXT NOT NULL, epoch INTEGER NOT NULL, action TEXT NOT NULL, recorded_at REAL NOT NULL)")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS reservation_history_no_update BEFORE UPDATE ON reservation_history BEGIN SELECT RAISE(ABORT,'append-only audit log'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS reservation_history_no_delete BEFORE DELETE ON reservation_history BEGIN SELECT RAISE(ABORT,'append-only audit log'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS authority_audit_no_update BEFORE UPDATE ON authority_audit BEGIN SELECT RAISE(ABORT,'append-only authority audit'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS authority_audit_no_delete BEFORE DELETE ON authority_audit BEGIN SELECT RAISE(ABORT,'append-only authority audit'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS revoked_workers_no_update BEFORE UPDATE ON revoked_workers BEGIN SELECT RAISE(ABORT,'worker revocation records are immutable'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS revoked_workers_no_delete BEFORE DELETE ON revoked_workers BEGIN SELECT RAISE(ABORT,'worker revocation records are immutable'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS consumed_authority_tokens_no_update BEFORE UPDATE ON consumed_authority_tokens BEGIN SELECT RAISE(ABORT,'consumed authority tokens are immutable'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS consumed_authority_tokens_no_delete BEFORE DELETE ON consumed_authority_tokens BEGIN SELECT RAISE(ABORT,'consumed authority tokens are immutable'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS reservation_history_no_update BEFORE UPDATE ON reservation_history BEGIN SELECT RAISE(ABORT,'append-only audit log'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS reservation_history_no_delete BEFORE DELETE ON reservation_history BEGIN SELECT RAISE(ABORT,'append-only audit log'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS fenced_mutation_log_no_update BEFORE UPDATE ON fenced_mutation_log BEGIN SELECT RAISE(ABORT,'append-only audit log'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS fenced_mutation_log_no_delete BEFORE DELETE ON fenced_mutation_log BEGIN SELECT RAISE(ABORT,'append-only audit log'); END")
            now = time.time()
            row = self.conn.execute("SELECT max_observed_wall FROM policy_clock_watermark WHERE id=1").fetchone()
            if row is None:
                self.conn.execute("INSERT INTO policy_clock_watermark(id,max_observed_wall) VALUES(1,?)", (now,))
            elif now < row[0] - self.rollback_tolerance:
                raise RuntimeError("CRITICAL: persisted wall-clock rollback detected; refusing lease operations")
            else:
                self.conn.execute("UPDATE policy_clock_watermark SET max_observed_wall=MAX(max_observed_wall,?) WHERE id=1", (now,))

    @staticmethod
    def _validate_ids(candidate_id: str, worker_id: str, epoch: int) -> None:
        if not isinstance(candidate_id, str) or not candidate_id.strip():
            raise ValueError("candidate_id must be a non-empty string")
        if not isinstance(worker_id, str) or not worker_id.strip():
            raise ValueError("worker_id must be a non-empty string")
        if isinstance(epoch, bool) or not isinstance(epoch, int) or epoch < 0:
            raise ValueError("epoch must be a non-negative integer")

    def _check_clock_in_transaction(self, now: float) -> None:
        mono = time.monotonic()
        if mono < self._last_monotonic:
            raise RuntimeError("CRITICAL: monotonic clock violation; refusing lease operation")
        row = self.conn.execute("SELECT max_observed_wall FROM policy_clock_watermark WHERE id=1").fetchone()
        if row and now < row[0] - self.rollback_tolerance:
            raise RuntimeError("CRITICAL: persisted wall-clock rollback detected; refusing lease operation")
        self.conn.execute("UPDATE policy_clock_watermark SET max_observed_wall=MAX(max_observed_wall,?) WHERE id=1", (now,))
        self._last_monotonic = mono

    def _reserve_in_transaction(self, candidate_id: str, worker_id: str, epoch: int,
                                now: float, expires_at: float | None = None) -> bool:
        expires = min(now + self.ttl_seconds, expires_at) if expires_at is not None else now + self.ttl_seconds
        row = self.conn.execute(
            "SELECT worker_id,epoch,expires_at FROM reservations WHERE candidate_id=?",
            (candidate_id,),
        ).fetchone()
        action = "RESERVED"
        if row:
            old_worker, old_epoch, old_expiry = row
            same_lease = old_worker == worker_id and old_epoch == epoch
            action = "RENEWED" if same_lease else "EPOCH_TAKEOVER"
            if not same_lease and epoch <= old_epoch:
                return False
            if same_lease and now >= old_expiry:
                return False
        self.conn.execute(
            """INSERT INTO reservations(candidate_id,worker_id,epoch,expires_at,authorized_at)
               VALUES(?,?,?,?,?) ON CONFLICT(candidate_id) DO UPDATE SET
               worker_id=excluded.worker_id, epoch=excluded.epoch,
               expires_at=excluded.expires_at, authorized_at=excluded.authorized_at""",
            (candidate_id, worker_id, epoch, expires, now),
        )
        self.conn.execute(
            "INSERT INTO reservation_history(candidate_id,worker_id,epoch,action,recorded_at) VALUES(?,?,?,?,?)",
            (candidate_id, worker_id, epoch, action, now),
        )
        return True

    @retry_postgres_serialization(connection_attr="conn")
    def atomic_reserve(self, candidate_id: str, worker_id: str, epoch: int) -> bool:
        """Local primitive. Disabled by default; production path requires authority token."""
        if self.require_authority:
            raise PermissionError("online authority-signed lease token is required")
        self._validate_ids(candidate_id, worker_id, epoch)
        if self.conn.in_transaction:
            raise RuntimeError("atomic_reserve requires a connection with no active transaction")
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            now = time.time()
            self._check_clock_in_transaction(now)
            if self.conn.execute("SELECT 1 FROM revoked_workers WHERE worker_id=?", (worker_id,)).fetchone():
                raise PermissionError(f"worker {worker_id} has been revoked")
            result = self._reserve_in_transaction(candidate_id, worker_id, epoch, now)
            if result:
                self.conn.commit()
            else:
                self.conn.rollback()
            return result
        except BaseException:
            self.conn.rollback()
            raise

    @retry_postgres_serialization(connection_attr="conn")
    def atomic_reserve_authorized(self, token: dict, authority_public_key: ed25519.Ed25519PublicKey) -> bool:
        """Consume an online authority token; issuance/revocation epoch is checked atomically."""
        if not isinstance(token, dict) or set(token) != {"claims", "signature"}:
            raise ValueError("malformed authority token")
        claims, signature = token["claims"], token["signature"]
        if not isinstance(claims, dict) or not isinstance(signature, bytes):
            raise ValueError("malformed authority token fields")
        serialized = canonical_serialize(claims)
        message = b"CRO_LEASE_AUTH_V1" + len(serialized).to_bytes(8, "big") + serialized
        try:
            authority_public_key.verify(signature, message)
        except InvalidSignature as exc:
            raise PermissionError("invalid authority signature") from exc
        candidate_id, worker_id, epoch = claims.get("candidate_id"), claims.get("worker_id"), claims.get("epoch")
        self._validate_ids(candidate_id, worker_id, epoch)
        if self.conn.in_transaction:
            raise RuntimeError("authorized reserve requires a connection with no active transaction")
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            now = time.time()
            self._check_clock_in_transaction(now)
            issued_at, expires_at = claims.get("issued_at"), claims.get("expires_at")
            authority_epoch = claims.get("authority_epoch")
            nonce = claims.get("nonce")
            if (isinstance(issued_at, bool) or not isinstance(issued_at, (int, float))
                    or isinstance(expires_at, bool) or not isinstance(expires_at, (int, float))
                    or isinstance(authority_epoch, bool) or not isinstance(authority_epoch, int)
                    or not isinstance(nonce, str) or not nonce):
                raise ValueError("invalid authority token claims")
            if issued_at > now + 1.5 or expires_at <= now or expires_at <= issued_at or expires_at - issued_at > 60:
                raise PermissionError("authority token is expired, future-dated, or exceeds the 60-second maximum TTL")
            current_epoch = self.conn.execute("SELECT authority_epoch FROM authority_state WHERE id=1").fetchone()[0]
            if authority_epoch != current_epoch:
                raise PermissionError("authority token invalidated by a later authorization/revocation event")
            if self.conn.execute("SELECT 1 FROM revoked_workers WHERE worker_id=?", (worker_id,)).fetchone():
                raise PermissionError(f"worker {worker_id} has been revoked")
            if self.conn.execute("SELECT 1 FROM consumed_authority_tokens WHERE nonce=?", (nonce,)).fetchone():
                raise PermissionError("authority token nonce has already been consumed")
            result = self._reserve_in_transaction(candidate_id, worker_id, epoch, now, float(expires_at))
            if result:
                consumed = self.conn.execute(
                    "INSERT INTO consumed_authority_tokens(nonce,consumed_at) VALUES(?,?) ON CONFLICT(nonce) DO NOTHING",
                    (nonce, now),
                )
                if consumed.rowcount == 0:
                    raise PermissionError("authority token nonce has already been consumed")
                self.conn.execute(
                    "INSERT INTO authority_audit(action,worker_id,candidate_id,authority_epoch,recorded_at,detail) VALUES(?,?,?,?,?,?)",
                    ("LEASE_AUTHORIZED", worker_id, candidate_id, authority_epoch, now, claims["nonce"]),
                )
                self.conn.commit()
            else:
                self.conn.rollback()
            return result
        except BaseException:
            self.conn.rollback()
            raise

    @retry_postgres_serialization(connection_attr="conn")
    def assert_and_enforce_downstream_fence_atomic(
        self, candidate_id: str, worker_id: str, epoch: int,
        mutation: Callable[[sqlite3.Connection], T],
    ) -> T:
        """Validate the lease and perform the protected mutation in ONE transaction.

        The callback must use the supplied connection. No external side effect
        (network call, filesystem write, etc.) can be made transactionally here.
        """
        self._validate_ids(candidate_id, worker_id, epoch)
        if not callable(mutation):
            raise TypeError("mutation must be a callable accepting the transaction connection")
        if self.conn.in_transaction:
            raise RuntimeError("fenced mutation requires a connection with no active transaction")
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            now = time.time()
            self._check_clock_in_transaction(now)
            row = self.conn.execute(
                "SELECT worker_id,epoch,expires_at FROM reservations WHERE candidate_id=?",
                (candidate_id,),
            ).fetchone()
            if row is None:
                raise RuntimeError(f"FENCE VIOLATION: no reservation for candidate {candidate_id}")
            actual_worker, actual_epoch, expires_at = row
            if self.conn.execute("SELECT 1 FROM revoked_workers WHERE worker_id=?", (worker_id,)).fetchone():
                raise RuntimeError("FENCE VIOLATION: worker has been revoked")
            if actual_worker != worker_id or actual_epoch != epoch:
                raise RuntimeError(
                    f"FENCE VIOLATION: stale holder ({worker_id}, epoch {epoch}); "
                    f"current holder is ({actual_worker}, epoch {actual_epoch})"
                )
            if now >= expires_at:
                raise RuntimeError("FENCE VIOLATION: lease has expired")
            result = mutation(self.conn)
            self.conn.execute(
                "INSERT INTO fenced_mutation_log(candidate_id,worker_id,epoch,recorded_at) VALUES(?,?,?,?)",
                (candidate_id, worker_id, epoch, now),
            )
            self.conn.commit()
            return result
        except BaseException:
            self.conn.rollback()
            raise

    def assert_lease_valid(self, candidate_id: str, worker_id: str, epoch: int) -> bool:
        """Read-only diagnostic. Use the atomic mutation method for protected writes."""
        self._validate_ids(candidate_id, worker_id, epoch)
        row = self.conn.execute(
            "SELECT worker_id,epoch,expires_at FROM reservations WHERE candidate_id=?",
            (candidate_id,),
        ).fetchone()
        if row is None or row[0] != worker_id or row[1] != epoch or time.time() >= row[2]:
            raise RuntimeError("FENCE VIOLATION: lease is absent, stale, or expired")
        return True


class AuthorizationAuthority:
    """Transactional authority core for short-lived signed lease tokens.

    SQLite remains the local-test backend; the PostgreSQL adapter and the separately
    deployed remote_authority service provide the production reference path.
    """
    def __init__(self, db_conn: sqlite3.Connection, signing_key: ed25519.Ed25519PrivateKey):
        self.conn = db_conn
        self.signing_key = signing_key
        with self.conn:
            self.conn.execute("CREATE TABLE IF NOT EXISTS authority_state (id INTEGER PRIMARY KEY CHECK(id=1), authority_epoch INTEGER NOT NULL)")
            self.conn.execute("INSERT OR IGNORE INTO authority_state(id,authority_epoch) VALUES(1,0)")
            self.conn.execute("CREATE TABLE IF NOT EXISTS revoked_workers (worker_id TEXT PRIMARY KEY, revoked_at REAL NOT NULL, reason TEXT NOT NULL, authority_epoch INTEGER NOT NULL)")
            self.conn.execute("CREATE TABLE IF NOT EXISTS authority_audit (sequence INTEGER PRIMARY KEY AUTOINCREMENT, action TEXT NOT NULL, worker_id TEXT NOT NULL, candidate_id TEXT, authority_epoch INTEGER NOT NULL, recorded_at REAL NOT NULL, detail TEXT NOT NULL)")
            self.conn.execute("CREATE TABLE IF NOT EXISTS consumed_authority_tokens (nonce TEXT PRIMARY KEY, consumed_at REAL NOT NULL)")
            self.conn.execute("CREATE TABLE IF NOT EXISTS reservations (candidate_id TEXT PRIMARY KEY, worker_id TEXT NOT NULL, epoch INTEGER NOT NULL CHECK(epoch >= 0), expires_at REAL NOT NULL, authorized_at REAL NOT NULL)")
            self.conn.execute("CREATE TABLE IF NOT EXISTS reservation_history (sequence INTEGER PRIMARY KEY AUTOINCREMENT, candidate_id TEXT NOT NULL, worker_id TEXT NOT NULL, epoch INTEGER NOT NULL, action TEXT NOT NULL, recorded_at REAL NOT NULL)")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS reservation_history_no_update BEFORE UPDATE ON reservation_history BEGIN SELECT RAISE(ABORT,'append-only audit log'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS reservation_history_no_delete BEFORE DELETE ON reservation_history BEGIN SELECT RAISE(ABORT,'append-only audit log'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS authority_audit_no_update BEFORE UPDATE ON authority_audit BEGIN SELECT RAISE(ABORT,'append-only authority audit'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS authority_audit_no_delete BEFORE DELETE ON authority_audit BEGIN SELECT RAISE(ABORT,'append-only authority audit'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS revoked_workers_no_update BEFORE UPDATE ON revoked_workers BEGIN SELECT RAISE(ABORT,'worker revocation records are immutable'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS revoked_workers_no_delete BEFORE DELETE ON revoked_workers BEGIN SELECT RAISE(ABORT,'worker revocation records are immutable'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS consumed_authority_tokens_no_update BEFORE UPDATE ON consumed_authority_tokens BEGIN SELECT RAISE(ABORT,'consumed authority tokens are immutable'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS consumed_authority_tokens_no_delete BEFORE DELETE ON consumed_authority_tokens BEGIN SELECT RAISE(ABORT,'consumed authority tokens are immutable'); END")

    @retry_postgres_serialization(connection_attr="conn")
    def issue_lease_token(self, candidate_id: str, worker_id: str, epoch: int, ttl_seconds: int = 60) -> dict:
        DurablePolicyManager._validate_ids(candidate_id, worker_id, epoch)
        if isinstance(ttl_seconds, bool) or not isinstance(ttl_seconds, int) or not 1 <= ttl_seconds <= 60:
            raise ValueError("authority lease TTL must be an integer from 1 to 60 seconds")
        if self.conn.in_transaction:
            raise RuntimeError("token issuance requires a connection with no active transaction")
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            now = time.time()
            if self.conn.execute("SELECT 1 FROM revoked_workers WHERE worker_id=?", (worker_id,)).fetchone():
                raise PermissionError(f"worker {worker_id} is revoked")
            authority_epoch = self.conn.execute("SELECT authority_epoch FROM authority_state WHERE id=1").fetchone()[0]
            claims = {
                "candidate_id": candidate_id, "worker_id": worker_id, "epoch": epoch,
                "issued_at": now, "expires_at": now + ttl_seconds,
                "authority_epoch": authority_epoch, "nonce": secrets.token_hex(16),
            }
            serialized = canonical_serialize(claims)
            signature = self.signing_key.sign(b"CRO_LEASE_AUTH_V1" + len(serialized).to_bytes(8, "big") + serialized)
            self.conn.execute(
                "INSERT INTO authority_audit(action,worker_id,candidate_id,authority_epoch,recorded_at,detail) VALUES(?,?,?,?,?,?)",
                ("LEASE_ISSUED", worker_id, candidate_id, authority_epoch, now, claims["nonce"]),
            )
            self.conn.commit()
            return {"claims": claims, "signature": signature}
        except BaseException:
            self.conn.rollback()
            raise

    @retry_postgres_serialization(connection_attr="conn")
    def revoke_worker(self, worker_id: str, reason: str) -> int:
        if not isinstance(worker_id, str) or not worker_id.strip() or not isinstance(reason, str) or not reason.strip():
            raise ValueError("worker_id and revocation reason are required")
        if self.conn.in_transaction:
            raise RuntimeError("revocation requires a connection with no active transaction")
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            now = time.time()
            existing = self.conn.execute("SELECT authority_epoch FROM revoked_workers WHERE worker_id=?", (worker_id,)).fetchone()
            if existing:
                self.conn.commit()
                return existing[0]
            self.conn.execute("UPDATE authority_state SET authority_epoch=authority_epoch+1 WHERE id=1")
            epoch = self.conn.execute("SELECT authority_epoch FROM authority_state WHERE id=1").fetchone()[0]
            self.conn.execute("INSERT INTO revoked_workers(worker_id,revoked_at,reason,authority_epoch) VALUES(?,?,?,?)", (worker_id, now, reason, epoch))
            self.conn.execute("UPDATE reservations SET expires_at=MIN(expires_at,?) WHERE worker_id=?", (now, worker_id))
            self.conn.execute("INSERT INTO reservation_history(candidate_id,worker_id,epoch,action,recorded_at) SELECT candidate_id,worker_id,epoch,'REVOKED',? FROM reservations WHERE worker_id=?", (now, worker_id))
            self.conn.execute("INSERT INTO authority_audit(action,worker_id,candidate_id,authority_epoch,recorded_at,detail) VALUES(?,?,?,?,?,?)", ("WORKER_REVOKED", worker_id, "", epoch, now, reason))
            self.conn.commit()
            return epoch
        except BaseException:
            self.conn.rollback()
            raise
