"""Durable transaction store with SQLite local and PostgreSQL production backends."""
from __future__ import annotations

import contextlib
import sqlite3
import threading
from typing import Iterator
from cro.postgres_compat import PostgresConnection


class DurableStore:
    def __init__(self, db_path: str = "cro.sqlite3", backend: str = "sqlite"):
        self.db_path = db_path
        self.backend = backend
        if backend == "postgresql":
            if not isinstance(db_path, str) or not db_path.startswith(("postgres://", "postgresql://")):
                raise ValueError("backend=postgresql requires a PostgreSQL DSN, not a SQLite path")
            self._lock = threading.RLock()
            self._conn = PostgresConnection(db_path)
            self._conn.execute("CREATE TABLE IF NOT EXISTS durable_outbox (id TEXT PRIMARY KEY, payload TEXT NOT NULL, status TEXT NOT NULL)")
            return
        if backend != "sqlite":
            raise ValueError(f"Unsupported storage backend: {backend}")
        self._lock = threading.RLock()
        # Keep one connection alive so :memory: databases remain usable after init.
        self._conn = sqlite3.connect(db_path, check_same_thread=False, isolation_level=None)
        self._conn.execute("PRAGMA foreign_keys=ON")
        if db_path != ":memory:":
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=FULL")
        self._conn.execute(
            "CREATE TABLE IF NOT EXISTS durable_outbox ("
            "id TEXT PRIMARY KEY, payload TEXT NOT NULL, status TEXT NOT NULL)"
        )

    @contextlib.contextmanager
    def atomic_transaction(self) -> Iterator[object]:
        """Yield a connection inside a serialized transaction; rollback on error."""
        with self._lock:
            if self._conn.in_transaction:
                raise RuntimeError("Nested transactions are not supported by DurableStore")
            self._conn.execute("BEGIN IMMEDIATE" if self.backend == "sqlite" else "BEGIN ISOLATION LEVEL SERIALIZABLE")
            try:
                yield self._conn
                self._conn.commit()
            except BaseException:
                self._conn.rollback()
                raise

    def close(self) -> None:
        with self._lock:
            self._conn.close()
