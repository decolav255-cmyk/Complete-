"""CRO (Continuous Retrospective Optimization) Package v2.0.5-hardened"""
__version__ = "2.0.5-hardened"
