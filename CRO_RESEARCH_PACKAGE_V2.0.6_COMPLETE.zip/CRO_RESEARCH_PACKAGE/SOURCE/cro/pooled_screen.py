"""
cro/pooled_screen.py: Phase 1 Revision 23 candidate - Cluster-Randomized Safeguard Engine
Author: Statistical Verification & Methodological Taskforce
Date: 2026

CONFINEMENT NOTICE:
This module is strictly confined to cro/pooled_screen.py and tests/test_pooled_screen.py.
No core CRO files or policies (including cro/policy.py) are modified in this phase.

R23 STATUS: candidate hardening layered on R22. Certified interval inversion and FLINT/Arb rank-conditioning certification are NOT implemented; R23 must not be represented as complete or production-ready.

STATISTICAL FOUNDATION & INFERENTIAL NULL HYPOTHESIS SPECIFICATION:
1. Inferential Null Hypothesis & P-Value Interpretation:
   - The permutation procedure tested here evaluates the sharp global null of zero treatment effect for every unit 
     across all clusters: H_0: Y_i(1) = Y_i(0) for all i.
   - A statistically significant interaction statistic under this permutation procedure indicates rejection of 
     the sharp global null, but does NOT independently establish treatment-effect moderation in isolation without 
     assuming constant treatment effects across clusters.
   - The reported p-value is calculated either via exact permutation enumeration (when total allocation space <= exact_enumeration_threshold)
     or via Monte Carlo randomization p-value with standard plus-one correction:
     p_MC = (sum_{i=1}^M I(|t^*_i| >= |t_obs|) + 1) / (M + 1)

2. Assignment Mechanism Declaration & Strata Alignment:
   - Requires explicit declaration: assignment_config['mechanism'] == 'complete_cluster_randomization_within_strata'.
   - Strata identifiers are strictly validated (numeric or categorical string; no mixed types, nulls, NaNs, or unhashable objects).
   - First-appearance cluster-strata ordering is explicitly preserved for cluster-level strata vectors without relying on np.unique() sorting.
"""

import math
from dataclasses import dataclass, asdict
from fractions import Fraction
from itertools import combinations, product
import numpy as np

class MixedTypeError(ValueError):
    """Raised when identifier collections mix incompatible scalar types."""

@dataclass(frozen=True)
class SharpNullResult:
    statistic: float | None
    p_value: float | None
    abstained: bool
    reason: str
    null_hypothesis: str = "sharp_global_zero_effect"
    method: str = "cluster_randomization_test"
    validity_classification: str = "design_based_if_assignment_mechanism_is_correctly_declared"
    diagnostics: dict | None = None

@dataclass(frozen=True)
class ConstantEffectResult:
    tau_null: float | None
    p_value: float | None
    ci_lower: float | None
    ci_upper: float | None
    abstained: bool
    reason: str
    null_hypothesis: str = "constant_additive_treatment_effect"
    method: str = "design_based_inversion"
    validity_classification: str = "not_certified"
    diagnostics: dict | None = None

@dataclass(frozen=True)
class HolmResult:
    adjusted_p_values: tuple[float, ...]
    rejected: tuple[bool, ...]
    untestable_indices: tuple[int, ...]
    alpha: float
    method: str = "holm_step_down"
# sklearn is an optional dependency used only by fit_pipeline / transform_pipeline

class RobustPooledScreenEngine:
    """
    Safeguard engine for cluster-randomized experimental treatment moderation 
    under complete cluster randomization within strata, featuring strictly lazy 
    exact enumeration, zero combination pre-materialization in Monte Carlo mode, 
    unambiguous structured hypothesis identifiers, exposed CR1 covariance outputs, 
    and robust diagnostic tracking.
    """
    def __init__(
        self,
        alpha: float = 0.05,
        n_permutations: int = 2000,
        missingness_threshold: float = 0.40,
        min_clusters_threshold: int = 10,
        exact_enumeration_threshold: int = 1000,
        random_state: int = 42,
        test_mode: bool = False
    ):
        if isinstance(n_permutations, bool) or not isinstance(n_permutations, int) or n_permutations <= 0:
            raise ValueError("n_permutations must be a positive integer.")
        if isinstance(alpha, bool) or not isinstance(alpha, (float, int)) or not (0.0 < alpha < 1.0):
            raise ValueError("alpha must be strictly between 0 and 1.")
        if isinstance(min_clusters_threshold, bool) or not isinstance(min_clusters_threshold, int) or min_clusters_threshold <= 0:
            raise ValueError("min_clusters_threshold must be a positive integer.")
        if isinstance(exact_enumeration_threshold, bool) or not isinstance(exact_enumeration_threshold, int) or exact_enumeration_threshold <= 0:
            raise ValueError("exact_enumeration_threshold must be a positive integer.")
        if isinstance(missingness_threshold, bool) or not isinstance(missingness_threshold, (float, int)) or not (0.0 <= missingness_threshold < 1.0):
            raise ValueError("missingness_threshold must be within [0, 1).")

        self.alpha = alpha
        self.test_mode = bool(test_mode)
        self.n_permutations = n_permutations
        self.missingness_threshold = missingness_threshold
        self.min_clusters_threshold = min_clusters_threshold
        self.exact_enumeration_threshold = exact_enumeration_threshold
        self.rng = np.random.default_rng(random_state)
        self.fitted = False
        self.imputer_type = 'zero'
        self.imputer = None
        self.missing_cols_ = []
        self.family_hypotheses_ = []
        self.untestable_flags_ = []
        self.last_permutation_diagnostics_ = {}
        self.last_cr1_model_fit_ = {}
        self.last_observed_cr1_model_fit_ = {}
        # Test-only hook: when set to a 1-d array of length n_permutations, MC path
        # uses these statistics for the p-value calculation after assignments are formed.
        self._test_mc_perm_stats = None
        # Test-only: if set to a square ndarray, replaces computed vcov before validation.
        self._test_vcov_override = None

    @staticmethod
    def monte_carlo_plus_one_pvalue(observed_stat: float, perm_stats) -> tuple[float, int, int]:
        """
        Two-sided Monte Carlo p-value with plus-one correction.
        p = (b + 1) / (M + 1), where b = #{|t*| >= |t_obs|}, M = len(perm_stats).
        Returns (p, exceedances_b, M).
        """
        stats = np.asarray(perm_stats, dtype=float)
        if stats.ndim != 1:
            raise ValueError("perm_stats must be one-dimensional.")
        M = int(stats.size)
        if M <= 0:
            raise ValueError("perm_stats must be non-empty.")
        if not np.isfinite(observed_stat):
            raise ValueError("observed_stat must be finite.")
        if not np.isfinite(stats).all():
            raise ValueError("perm_stats must be finite.")
        b = int(np.sum(np.abs(stats) >= np.abs(observed_stat)))
        p = float((b + 1) / (M + 1))
        return p, b, M

    def _clear_inference_state(self) -> None:
        """Clear diagnostics and CR1 fit state (observed and last)."""
        self.last_permutation_diagnostics_ = {}
        self.last_cr1_model_fit_ = {}
        self.last_observed_cr1_model_fit_ = {}

    def _abstain(self, reason: str) -> tuple[float, float, bool, str]:
        """Abort permutation inference without leaving residual observed-fit state."""
        self._clear_inference_state()
        return 0.0, 1.0, True, reason

    def _validate_label_collection(self, labels, name: str) -> list:
        """Validates action, moderator, or response labels, rejecting invalid, empty, or unhashable objects."""
        if labels is None or not isinstance(labels, (list, tuple, set)) or len(labels) == 0:
            raise ValueError(f"{name} must be a non-empty collection of labels.")

        seen = set()
        validated = []
        for lbl in labels:
            if isinstance(lbl, bool):
                raise TypeError(f"Boolean labels are strictly rejected in {name}.")
            if lbl is None:
                raise ValueError(f"Null labels are strictly rejected in {name}.")
            if isinstance(lbl, str):
                if lbl.strip() == "" or lbl.lower() in ("nan", "none", "null"):
                    raise ValueError(f"Invalid string label detected in {name}.")
            elif isinstance(lbl, (int, float, np.number)):
                if not np.isfinite(float(lbl)):
                    raise ValueError(f"Non-finite numeric label detected in {name}.")
            else:
                try:
                    hash(lbl)
                except Exception:
                    raise TypeError(f"Unsupported or unhashable label type in {name}: {type(lbl)}")

            if lbl in seen:
                raise ValueError(f"Duplicate label detected within {name}: {lbl}")
            seen.add(lbl)
            validated.append(lbl)
        return validated

    def construct_family(self, actions: list, moderators: list, responses: list) -> int:
        """
        Constructs predeclared hypothesis family using structured tuple identifiers to prevent 
        delimiter collision ambiguity. Failed construction preserves the previous valid state.
        """
        val_actions = self._validate_label_collection(actions, "actions")
        val_moderators = self._validate_label_collection(moderators, "moderators")
        val_responses = self._validate_label_collection(responses, "responses")

        new_hypotheses = []
        seen_tuples = set()
        for a in val_actions:
            for m in val_moderators:
                for r in val_responses:
                    h_tuple = (a, m, r)
                    if h_tuple in seen_tuples:
                        raise ValueError(f"Duplicate hypothesis identifier detected: {h_tuple}")
                    seen_tuples.add(h_tuple)
                    new_hypotheses.append({
                        'action': a,
                        'moderator': m,
                        'response': r,
                        'id': f"A:{repr(a)}__M:{repr(m)}__R:{repr(r)}",
                        'tuple_id': h_tuple
                    })

        self.family_hypotheses_ = new_hypotheses
        self.untestable_flags_ = [False] * len(self.family_hypotheses_)
        return len(self.family_hypotheses_)

    def mark_untestable(self, index: int) -> None:
        """Marks a hypothesis as untestable after validating index."""
        if isinstance(index, bool) or not isinstance(index, int):
            raise TypeError("Hypothesis index must be an integer.")
        if not self.family_hypotheses_:
            raise RuntimeError("Cannot mark untestable before constructing hypothesis family.")
        if 0 <= index < len(self.untestable_flags_):
            self.untestable_flags_[index] = True
        else:
            raise IndexError("Hypothesis index out of range for family.")

    def fit_pipeline(self, X_train: np.ndarray, imputer_type: str = 'zero') -> None:
        """Fits training-only imputation parameters and enforces missingness safeguards."""
        self.fitted = False
        self.imputer = None

        if imputer_type not in ('zero', 'mice'):
            raise ValueError(f"Unsupported imputation method '{imputer_type}'. Must be 'zero' or 'mice'.")

        self.imputer_type = imputer_type
        try:
            X_train_arr = np.array(X_train, dtype=float)
        except Exception:
            raise ValueError("Failed to convert training features to numeric numpy array.")

        if X_train_arr.ndim != 2:
            raise ValueError("Training feature matrix must be two-dimensional.")

        n_rows, n_cols = X_train_arr.shape
        if n_rows == 0 or n_cols == 0:
            raise ValueError("Training feature matrix cannot be empty.")

        if not np.isfinite(X_train_arr).all():
            finite_mask = np.isfinite(X_train_arr) | np.isnan(X_train_arr)
            if not finite_mask.all():
                raise ValueError("Training feature matrix contains non-finite values (e.g., inf).")

        all_missing_mask = np.isnan(X_train_arr).all(axis=0)
        if np.any(all_missing_mask):
            raise ValueError("Abstention: Training data contains one or more columns with 100% missing values.")

        missing_rates = np.isnan(X_train_arr).mean(axis=0)
        if np.any(missing_rates > self.missingness_threshold):
            raise ValueError(
                f"Abstention: Training feature missingness exceeds threshold {self.missingness_threshold} "
                f"(max observed: {np.max(missing_rates):.2f})."
            )

        if imputer_type == 'mice':
            try:
                from sklearn.experimental import enable_iterative_imputer  # noqa: F401
                from sklearn.impute import IterativeImputer
            except ImportError as e:
                raise ImportError("scikit-learn is required for imputer_type='mice'") from e
            self.imputer = IterativeImputer(random_state=int(self.rng.integers(0, 1e6)), max_iter=10)
        else:
            try:
                from sklearn.impute import SimpleImputer
            except ImportError as e:
                raise ImportError("scikit-learn is required for imputer_type='zero'") from e
            self.imputer = SimpleImputer(strategy='constant', fill_value=0.0)

        self.imputer.fit(X_train_arr)
        self.fitted = True

    def transform_pipeline(self, X: np.ndarray) -> np.ndarray:
        """Applies pre-fitted training imputation and appends explicit missingness indicator flags."""
        if not self.fitted or self.imputer is None:
            raise RuntimeError("Pipeline must be fitted successfully on training data prior to transformation.")
        
        try:
            X_arr = np.array(X, dtype=float)
        except Exception:
            raise ValueError("Failed to convert evaluation features to numeric numpy array.")

        if X_arr.ndim != 2:
            raise ValueError("Evaluation feature matrix must be two-dimensional.")

        n_eval_rows, n_eval_cols = X_arr.shape
        if n_eval_rows == 0 or n_eval_cols == 0:
            raise ValueError("Evaluation feature matrix cannot be empty.")

        if n_eval_cols != self.imputer.n_features_in_:
            raise ValueError(
                f"Feature dimension mismatch: Evaluation data has {n_eval_cols} columns, "
                f"but training data had {self.imputer.n_features_in_} columns."
            )

        if not np.isfinite(X_arr).all():
            finite_mask = np.isfinite(X_arr) | np.isnan(X_arr)
            if not finite_mask.all():
                raise ValueError("Evaluation feature matrix contains non-finite values (e.g., inf).")

        eval_missing_rates = np.isnan(X_arr).mean(axis=0)
        if np.any(eval_missing_rates > self.missingness_threshold):
            raise ValueError(
                f"Abstention: Evaluation feature missingness exceeds threshold {self.missingness_threshold} "
                f"(max observed: {np.max(eval_missing_rates):.2f})."
            )

        missing_flags = np.isnan(X_arr).astype(float)
        imputed_X = self.imputer.transform(X_arr)

        return np.hstack([imputed_X, missing_flags])

    def _validate_and_extract_clusters(self, clusters, n: int) -> tuple[np.ndarray, list, np.ndarray]:
        """
        Validates cluster identifier array, enforcing strict homogeneous identifier types 
        and preserving exact appearance ordering.
        """
        if np.isscalar(clusters) or not isinstance(clusters, (np.ndarray, list, tuple)):
            raise ValueError("Cluster input must be a vector/array of observation-level cluster labels, not a scalar.")

        clusters_list = list(clusters)
        if len(clusters_list) != n:
            raise ValueError("Cluster vector dimensions are incompatible with observation count.")

        first_type = None
        unique_order = []
        seen = set()

        for c_id in clusters_list:
            if isinstance(c_id, bool):
                raise ValueError("Boolean cluster identifiers are strictly rejected.")
            if c_id is None:
                raise ValueError("Null cluster identifier encountered.")
            if isinstance(c_id, (int, float, np.number)):
                if not np.isfinite(float(c_id)):
                    raise ValueError("Non-finite numeric cluster identifier encountered.")
                t_cat = "numeric"
            elif isinstance(c_id, str):
                if c_id.strip() == "" or c_id.lower() in ("nan", "none", "null"):
                    raise ValueError("Invalid string cluster identifier encountered.")
                t_cat = "string"
            else:
                raise ValueError(f"Unsupported cluster identifier type: {type(c_id)}")

            if first_type is None:
                first_type = t_cat
            elif first_type != t_cat:
                raise MixedTypeError("Mixed cluster identifier types (numeric and string) detected.")

            if c_id not in seen:
                seen.add(c_id)
                unique_order.append(c_id)

        clusters_arr = np.array(clusters_list, dtype=object)
        return clusters_arr, unique_order, np.array(unique_order, dtype=object)

    def _validate_strata_vector(self, strata_list: list, expected_type: str) -> list:
        """Enforces numeric or string homogeneity, rejecting nulls, non-finites, empty strings, and unhashables."""
        first_type = None
        validated = []
        for s_val in strata_list:
            if isinstance(s_val, bool):
                raise ValueError(f"Boolean stratum identifiers are strictly rejected in {expected_type}.")
            if s_val is None:
                raise ValueError(f"Missing (None) stratum identifier detected in {expected_type}.")
            
            if isinstance(s_val, (int, float, np.number)):
                if not np.isfinite(float(s_val)):
                    raise ValueError(f"Non-finite numeric stratum identifier detected in {expected_type}.")
                s_cat = "numeric"
            elif isinstance(s_val, str):
                if s_val.strip() == "" or s_val.lower() in ("nan", "none", "null"):
                    raise ValueError(f"Invalid string stratum identifier detected in {expected_type}.")
                s_cat = "string"
            else:
                raise ValueError(f"Unsupported or unhashable stratum value type in {expected_type}: {type(s_val)}")

            try:
                hash(s_val)
            except Exception:
                raise ValueError(f"Unhashable stratum value in {expected_type}: {type(s_val)}")

            if first_type is None:
                first_type = s_cat
            elif first_type != s_cat:
                raise MixedTypeError(f"Mixed stratum identifier types detected in {expected_type}.")

            validated.append(s_val)

        return validated


    def _validate_cr1_outputs(self, beta: np.ndarray, vcov: np.ndarray, tol: float = 1e-10):
        """
        Validate CR1 covariance and derived SE / t-statistics.
        Rejects non-finite, asymmetric, or non-positive diagonal entries before sqrt.
        """
        beta = np.asarray(beta, dtype=float)
        vcov = np.asarray(vcov, dtype=float)
        if beta.ndim != 1:
            raise ValueError("CR1 coefficient vector must be one-dimensional.")
        if vcov.ndim != 2 or vcov.shape[0] != vcov.shape[1]:
            raise ValueError("CR1 covariance matrix must be square.")
        if vcov.shape[0] != beta.shape[0]:
            raise ValueError("CR1 covariance dimension does not match coefficient vector.")
        if not np.isfinite(vcov).all():
            raise ValueError("CR1 covariance matrix contains non-finite entries.")
        if not np.isfinite(beta).all():
            raise ValueError("CR1 coefficient vector contains non-finite entries.")
        if not np.allclose(vcov, vcov.T, atol=tol, rtol=0.0):
            raise ValueError("CR1 covariance matrix is not symmetric within tolerance.")
        diag = np.diag(vcov)
        for i, v in enumerate(diag):
            if not np.isfinite(v) or v <= 0.0:
                raise ValueError(
                    f"CR1 diagonal variance at index {i} is invalid or non-positive: {v}"
                )
        se = np.sqrt(diag)
        if not np.isfinite(se).all() or np.any(se <= 0.0):
            raise ValueError("CR1 standard errors are invalid after square-root transform.")
        t_all = beta / se
        if not np.isfinite(t_all).all():
            raise ValueError("CR1 t-statistics contain non-finite values.")
        return se, t_all

    @staticmethod
    def exact_binary_rational_rank(matrix) -> dict:
        """Certify algebraic rank of the exact binary-float input matrix.

        Every finite IEEE-754 value is converted to its exact rational value;
        Gaussian elimination then uses Fraction arithmetic. This certifies
        algebraic rank of the supplied binary values, but does not certify a
        numerical condition-number class or a stable floating-point inverse.
        """
        arr=np.asarray(matrix,dtype=float)
        if arr.ndim != 2 or not np.isfinite(arr).all():
            raise ValueError("matrix must be a finite two-dimensional numeric array")
        rows, cols=arr.shape
        a=[[Fraction.from_float(float(arr[i,j])) for j in range(cols)] for i in range(rows)]
        rank=0; pivot_row=0
        for col in range(cols):
            pivot=next((r for r in range(pivot_row,rows) if a[r][col] != 0),None)
            if pivot is None: continue
            a[pivot_row],a[pivot]=a[pivot],a[pivot_row]
            pv=a[pivot_row][col]
            a[pivot_row]=[v/pv for v in a[pivot_row]]
            for r in range(rows):
                if r == pivot_row: continue
                factor=a[r][col]
                if factor:
                    a[r]=[a[r][j]-factor*a[pivot_row][j] for j in range(cols)]
            rank += 1; pivot_row += 1
            if pivot_row == rows: break
        return {"algebraic_rank":rank,"n_columns":cols,
                "algebraically_full_column_rank":bool(rank==cols),
                "numerical_condition_classification":"numerically_unresolved",
                "certification":"exact_fraction_elimination_on_binary_float_inputs",
                "limitation":"does_not_certify_singular_value_bounds_or_float64_inverse_stability"}

    def compute_cluster_robust_stat(
        self,
        y: np.ndarray,
        treatment: np.ndarray,
        moderator: np.ndarray,
        clusters: np.ndarray
    ) -> tuple[float, float, float]:
        """
        Calculates CR1 cluster-robust sandwich covariance t-statistic for the interaction coefficient, 
        strictly requiring G >= 2. Exposes full covariance matrix and coefficients in self.last_cr1_model_fit_.
        """
        # Clear any prior fit so a failed computation cannot leave a stale successful fit.
        self.last_cr1_model_fit_ = {}

        if y is None or treatment is None or moderator is None or clusters is None:
            raise ValueError("Inputs cannot be None in CR1 calculation.")

        try:
            y_arr = np.array(y, dtype=float)
            t_arr = np.array(treatment, dtype=float)
            m_arr = np.array(moderator, dtype=float)
        except Exception:
            raise ValueError("Failed to convert outcomes, treatment, or moderator to numeric arrays.")

        if y_arr.ndim != 1 or t_arr.ndim != 1 or m_arr.ndim != 1:
            raise ValueError("Outcomes, treatment, and moderator must be one-dimensional vectors.")

        n = len(y_arr)
        if n == 0 or len(t_arr) != n or len(m_arr) != n:
            raise ValueError("Input vector lengths are incompatible or empty in CR1 calculation.")

        if not (np.isfinite(y_arr).all() and np.isfinite(t_arr).all() and np.isfinite(m_arr).all()):
            raise ValueError("Non-finite values encountered in CR1 input vectors.")

        unique_t = np.unique(t_arr)
        if not set(unique_t).issubset({0.0, 1.0}):
            raise ValueError(f"Treatment values must be binary (0 or 1), found: {unique_t}")

        clusters_arr, unique_cluster_order, _ = self._validate_and_extract_clusters(clusters, n)
        G = len(unique_cluster_order)

        if G < 2:
            raise ValueError(f"Cluster count G={G} is insufficient for cluster-robust variance estimation (minimum required: 2).")

        if G < self.min_clusters_threshold:
            raise ValueError(f"Cluster count G={G} is below minimum threshold {self.min_clusters_threshold}.")

        for c in unique_cluster_order:
            t_vals = t_arr[clusters_arr == c]
            if len(np.unique(t_vals)) > 1:
                raise ValueError(f"Treatment is not homogeneous within cluster {c}.")

        if np.unique(t_arr).size < 2:
            raise ValueError("Treatment has no between-cluster variation; interaction is untestable.")
        if np.unique(m_arr).size < 2:
            raise ValueError("Moderator has no variation; interaction is untestable.")

        design = np.column_stack([np.ones_like(t_arr), t_arr, m_arr, t_arr * m_arr])
        _, k = design.shape

        if n <= k:
            raise ValueError(f"Insufficient observations (n={n}) for model parameters (k={k}).")

        rank = np.linalg.matrix_rank(design)
        if rank < k:
            raise ValueError("Design matrix is rank-deficient or singular.")

        xtx = design.T @ design
        try:
            xtx_inv = np.linalg.inv(xtx)
        except np.linalg.LinAlgError:
            raise ValueError("Matrix inversion failed in cluster robust variance calculation.")

        beta = xtx_inv @ (design.T @ y_arr)
        residuals = y_arr - design @ beta

        meat = np.zeros((k, k))
        for c in unique_cluster_order:
            idx = np.where(clusters_arr == c)[0]
            x_c = design[idx]
            e_c = residuals[idx]
            score_c = x_c.T @ e_c
            meat += np.outer(score_c, score_c)

        df_adj = (G / (G - 1)) * ((n - 1) / (n - k))
        vcov = df_adj * (xtx_inv @ meat @ xtx_inv)

        if self._test_vcov_override is not None:
            if not self.test_mode:
                raise RuntimeError("Test hooks are disabled; construct with test_mode=True only in tests.")
            vcov = np.asarray(self._test_vcov_override, dtype=float)
        se_cluster, t_all = self._validate_cr1_outputs(beta, vcov)

        # Store complete model fit parameters for independent inspection
        self.last_cr1_model_fit_ = {
            'beta': beta.copy(),
            'vcov': vcov.copy(),
            'se': se_cluster.copy(),
            't_stat': t_all.copy(),
            'df_adj': df_adj,
            'G': G,
            'n': n,
            'k': k
        }

        return float(t_all[3]), float(beta[3]), float(se_cluster[3])

    def cluster_permutation_test(
        self,
        y: np.ndarray,
        treatment: np.ndarray,
        moderator: np.ndarray,
        clusters: np.ndarray,
        assignment_design: str = 'cluster',
        assignment_config: dict | None = None
    ) -> tuple[float, float, bool, str]:
        """
        Executes complete cluster permutation within strata with lazy exact enumeration 
        (when theoretical allocation space <= exact_enumeration_threshold) or Monte Carlo sampling.
        Resets diagnostics on failure/abstention and guarantees caller configuration immutability.
        """
        self._clear_inference_state()

        if assignment_config is not None and not isinstance(assignment_config, dict):
            return self._abstain("ABSTAIN: assignment_config must be a dictionary.")

        config = assignment_config or {}

        mechanism = config.get('mechanism', None)
        if mechanism != 'complete_cluster_randomization_within_strata':
            return self._abstain(f"ABSTAIN: Missing or unsupported assignment mechanism declaration ('{mechanism}'). Required: 'complete_cluster_randomization_within_strata'.")

        if assignment_design != 'cluster':
            return self._abstain(f"ABSTAIN: Unsupported assignment design '{assignment_design}'.")

        if y is None or treatment is None or moderator is None or clusters is None:
            return self._abstain("ABSTAIN: Input vectors cannot be None.")

        try:
            y = np.array(y, dtype=float)
            treatment = np.array(treatment, dtype=float)
            moderator = np.array(moderator, dtype=float)
        except Exception:
            return self._abstain("ABSTAIN: Failed to convert input arrays to numeric types.")

        if y.ndim != 1 or treatment.ndim != 1 or moderator.ndim != 1:
            return self._abstain("ABSTAIN: All input vectors must be one-dimensional.")

        n = len(y)
        if n == 0 or len(treatment) != n or len(moderator) != n:
            return self._abstain("ABSTAIN: Input vector lengths are incompatible or empty.")

        if not np.isfinite(y).all() or not np.isfinite(moderator).all():
            return self._abstain("ABSTAIN: Non-finite values detected in response or moderator vectors.")

        if not np.isfinite(treatment).all():
            return self._abstain("ABSTAIN: Non-finite treatment assignments detected.")

        unique_t = np.unique(treatment)
        if not set(unique_t).issubset({0.0, 1.0}):
            return self._abstain(f"ABSTAIN: Treatment values must be binary (0 or 1), found: {unique_t}")

        try:
            clusters_arr, unique_cluster_order, _ = self._validate_and_extract_clusters(clusters, n)
        except ValueError as e:
            return self._abstain(f"ABSTAIN: {str(e)}")

        G = len(unique_cluster_order)
        if G < 2:
            return self._abstain(f"ABSTAIN: Cluster count G={G} is insufficient for variance estimation.")
        if G < self.min_clusters_threshold:
            return self._abstain(f"ABSTAIN: Cluster count G={G} is below minimum threshold {self.min_clusters_threshold}.")

        cluster_scalar_treatments = {}
        for c in unique_cluster_order:
            t_vals = treatment[clusters_arr == c]
            if len(np.unique(t_vals)) > 1:
                return self._abstain(f"ABSTAIN: Treatment is not homogeneous within cluster {c}.")
            cluster_scalar_treatments[c] = t_vals[0]

        strata_input = config.get('strata', None)
        if strata_input is None:
            strata_list = [0] * n
        elif isinstance(strata_input, (np.ndarray, list, tuple)):
            strata_list = list(strata_input)
        else:
            return self._abstain("ABSTAIN: Invalid strata configuration format.")

        if len(strata_list) == n:
            try:
                strata_validated = self._validate_strata_vector(strata_list, "observation-level strata")
            except ValueError as e:
                return self._abstain(f"ABSTAIN: {str(e)}")

            cluster_strata_map = {}
            for c in unique_cluster_order:
                idx = np.where(clusters_arr == c)[0]
                s_vals = [strata_validated[i] for i in idx]
                if len(set(s_vals)) > 1:
                    return self._abstain(f"ABSTAIN: Cluster {c} has mixed randomization strata assignments.")
                cluster_strata_map[c] = s_vals[0]
        elif len(strata_list) == G:
            try:
                strata_validated = self._validate_strata_vector(strata_list, "cluster-level strata")
            except ValueError as e:
                return self._abstain(f"ABSTAIN: {str(e)}")

            cluster_strata_map = dict(zip(unique_cluster_order, strata_validated))
        else:
            return self._abstain("ABSTAIN: Strata configuration length matches neither observation count nor cluster count.")

        try:
            obs_t, _, _ = self.compute_cluster_robust_stat(y, treatment, moderator, clusters_arr)
        except Exception as e:
            return self._abstain(f"ABSTAIN: {str(e)}")

        # Preserve observed-assignment CR1 fit; later permutations overwrite last_cr1_model_fit_
        self.last_observed_cr1_model_fit_ = {
            key: (val.copy() if hasattr(val, 'copy') else val)
            for key, val in self.last_cr1_model_fit_.items()
        }

        strata_groups = {}
        for c, s in cluster_strata_map.items():
            strata_groups.setdefault(s, []).append(c)

        theoretical_space_size = 1
        strata_combos_info = []
        for s, c_list in strata_groups.items():
            t_count = int(sum(cluster_scalar_treatments[c] == 1.0 for c in c_list))
            g_s = len(c_list)
            num_combos = math.comb(g_s, t_count)
            theoretical_space_size *= num_combos
            strata_combos_info.append((c_list, t_count))

        is_exact = theoretical_space_size <= self.exact_enumeration_threshold

        if is_exact:
            def stratum_generator(c_list, t_count):
                for combo in combinations(c_list, t_count):
                    yield {c: 1.0 if c in combo else 0.0 for c in c_list}

            strata_generators = [stratum_generator(c_list, t_count) for c_list, t_count in strata_combos_info]

            exact_p_stats = []
            evaluated_treated_sets = []
            for prod in product(*strata_generators):
                perm_scalar_map = {}
                for s_dict in prod:
                    perm_scalar_map.update(s_dict)

                treated = frozenset(c for c, t_val in perm_scalar_map.items() if float(t_val) == 1.0)
                evaluated_treated_sets.append(treated)

                perm_treatment = np.empty_like(treatment, dtype=float)
                for c, t_val in perm_scalar_map.items():
                    idx = np.where(clusters_arr == c)[0]
                    perm_treatment[idx] = t_val

                try:
                    p_t, _, _ = self.compute_cluster_robust_stat(y, perm_treatment, moderator, clusters_arr)
                    exact_p_stats.append(p_t)
                except Exception:
                    self.last_permutation_diagnostics_ = {}
                    self.last_cr1_model_fit_ = {}
                    return self._abstain("ABSTAIN: Numerical failure encountered during exact permutation evaluation.")

            exact_p_stats = np.array(exact_p_stats)
            p_val = float(np.mean(np.abs(exact_p_stats) >= np.abs(obs_t)))
            unique_treated = set(evaluated_treated_sets)
            self.last_permutation_diagnostics_ = {
                'evaluation_mode': 'exact_enumeration',
                'theoretical_allocation_space_size': theoretical_space_size,
                'distinct_sampled_allocations': len(unique_treated),
                'duplicate_allocation_count': len(evaluated_treated_sets) - len(unique_treated),
                'total_evaluations': len(evaluated_treated_sets),
                'observed_statistic': float(obs_t),
                'plus_one_correction_applied': False,
                'evaluated_treated_sets': evaluated_treated_sets,
            }
            self.last_cr1_model_fit_ = {
                key: (val.copy() if hasattr(val, 'copy') else val)
                for key, val in self.last_observed_cr1_model_fit_.items()
            }
            return obs_t, p_val, False, "OK"

        else:
            perm_stats = np.zeros(self.n_permutations)
            sampled_signatures = set()
            duplicate_count = 0
            # Expected treated count per stratum (assignment integrity target)
            expected_stratum_treated = {
                s: int(sum(cluster_scalar_treatments[c] == 1.0 for c in c_list))
                for s, c_list in strata_groups.items()
            }
            stratum_count_violations = 0
            sampled_stratum_treated_counts = []

            for i in range(self.n_permutations):
                perm_scalar_map = {}
                sample_counts = {}
                for s, c_list in strata_groups.items():
                    orig_t = [cluster_scalar_treatments[c] for c in c_list]
                    shuffled_t = self.rng.permutation(orig_t)
                    sample_counts[s] = int(sum(float(v) == 1.0 for v in shuffled_t))
                    if sample_counts[s] != expected_stratum_treated[s]:
                        stratum_count_violations += 1
                    for c, t_val in zip(c_list, shuffled_t):
                        perm_scalar_map[c] = float(t_val)
                sampled_stratum_treated_counts.append(sample_counts)

                sig = tuple((type(c).__name__, c, float(perm_scalar_map[c])) for c in unique_cluster_order)
                if sig in sampled_signatures:
                    duplicate_count += 1
                else:
                    sampled_signatures.add(sig)

                perm_treatment = np.empty_like(treatment, dtype=float)
                for c, t_val in perm_scalar_map.items():
                    idx = np.where(clusters_arr == c)[0]
                    perm_treatment[idx] = t_val

                try:
                    p_t, _, _ = self.compute_cluster_robust_stat(y, perm_treatment, moderator, clusters_arr)
                    perm_stats[i] = p_t
                except Exception:
                    self.last_permutation_diagnostics_ = {}
                    self.last_cr1_model_fit_ = {}
                    return self._abstain("ABSTAIN: Numerical failure encountered during Monte Carlo permutation evaluation.")

            if self._test_mc_perm_stats is not None:
                if not self.test_mode:
                    return self._abstain("ABSTAIN: Test hooks are disabled in production mode.")
                override = np.asarray(self._test_mc_perm_stats, dtype=float)
                if override.shape != (self.n_permutations,):
                    return self._abstain(
                        "ABSTAIN: _test_mc_perm_stats must have shape (n_permutations,)."
                    )
                perm_stats = override
            p_val, exceedances, M_eval = self.monte_carlo_plus_one_pvalue(obs_t, perm_stats)

            self.last_permutation_diagnostics_ = {
                'evaluation_mode': 'monte_carlo',
                'theoretical_allocation_space_size': theoretical_space_size,
                'distinct_sampled_allocations': len(sampled_signatures),
                'duplicate_allocation_count': duplicate_count,
                'duplicate_draw_fraction': float(duplicate_count / M_eval),
                'duplicate_draw_warning': bool(len(sampled_signatures) < 0.5 * M_eval),
                'total_evaluations': M_eval,
                'observed_statistic': float(obs_t),
                'exceedances': exceedances,
                'plus_one_correction_applied': True,
                'p_value_formula': '(exceedances + 1) / (n_permutations + 1)',
                'stratum_treated_count_violations': stratum_count_violations,
                'expected_stratum_treated_counts': expected_stratum_treated,
                'sampled_stratum_treated_counts': sampled_stratum_treated_counts,
            }
            self.last_cr1_model_fit_ = {
                key: (val.copy() if hasattr(val, 'copy') else val)
                for key, val in self.last_observed_cr1_model_fit_.items()
            }
            return obs_t, p_val, False, "OK"

    def verify_randomization_record(self, treatment, clusters, assignment_config) -> tuple[bool, str]:
        """Reproduce a declared uniform complete-cluster assignment from its seed.

        Protocol: NumPy PCG64; within each first-appearance stratum, select the
        recorded number of treated clusters uniformly without replacement.
        This verifies consistency with a reproducible assignment record; it
        cannot prove that the seed was preregistered or that data were not altered.
        """
        if not isinstance(assignment_config, dict):
            return False, "ABSTAIN: R23 requires an assignment_config dictionary with a reproducible randomization_record."
        if assignment_config.get("mechanism") != "complete_cluster_randomization_within_strata":
            return False, "ABSTAIN: unsupported or missing complete-cluster randomization mechanism."
        rec = assignment_config.get("randomization_record")
        if not isinstance(rec, dict):
            return False, "ABSTAIN: R23 requires randomization_record metadata; a mechanism string alone is insufficient."
        if rec.get("algorithm") != "numpy.PCG64_uniform_without_replacement_v1":
            return False, "ABSTAIN: unsupported randomization algorithm identifier."
        seed = rec.get("seed")
        if isinstance(seed, bool) or not isinstance(seed, (int, np.integer)) or int(seed) < 0:
            return False, "ABSTAIN: randomization_record seed must be a nonnegative integer."
        try:
            clusters_arr, cluster_order, _ = self._validate_and_extract_clusters(clusters, len(treatment))
            t = np.asarray(treatment, dtype=float)
            if t.ndim != 1 or not np.isfinite(t).all() or not set(np.unique(t)).issubset({0.0,1.0}):
                raise ValueError("treatment must be a finite binary vector")
            observed = {}
            for c in cluster_order:
                vals = np.unique(t[clusters_arr == c])
                if len(vals) != 1: raise ValueError(f"treatment varies within cluster {c}")
                observed[c] = float(vals[0])
            strata = assignment_config.get("strata")
            if strata is None: strata = [0] * len(cluster_order)
            if not isinstance(strata, (list, tuple, np.ndarray)) or len(strata) != len(cluster_order):
                raise ValueError("R23 randomization_record requires cluster-level strata aligned to first-appearance cluster order")
            strata = self._validate_strata_vector(list(strata), "R23 randomization record")
            groups = {}
            for c, st in zip(cluster_order, strata): groups.setdefault(st, []).append(c)
            count_rows = rec.get("treated_counts")
            if not isinstance(count_rows, list) or len(count_rows) != len(groups):
                raise ValueError("treated_counts must contain one row per stratum")
            count_map = {}
            for row in count_rows:
                if not isinstance(row, dict) or "stratum" not in row or "n_treated" not in row or "n_clusters" not in row:
                    raise ValueError("each treated_counts row requires stratum, n_treated, and n_clusters")
                st=row["stratum"]
                if st in count_map: raise ValueError("duplicate stratum in treated_counts")
                count_map[st]=(row["n_treated"],row["n_clusters"])
            rng=np.random.Generator(np.random.PCG64(int(seed)))
            expected={}
            for st, members in groups.items():
                if st not in count_map: raise ValueError(f"missing treated count for stratum {st}")
                nt, ng=count_map[st]
                if isinstance(nt,bool) or not isinstance(nt,(int,np.integer)) or int(nt)<0 or int(nt)>len(members):
                    raise ValueError(f"invalid treated-cluster count for stratum {st}")
                if isinstance(ng,bool) or not isinstance(ng,(int,np.integer)) or int(ng)!=len(members):
                    raise ValueError(f"cluster count mismatch for stratum {st}")
                selected=set(rng.choice(len(members),size=int(nt),replace=False).tolist())
                for j,c in enumerate(members): expected[c]=1.0 if j in selected else 0.0
            if any(observed[c] != expected[c] for c in cluster_order):
                return False, "ABSTAIN: observed assignment does not reproduce from the supplied PCG64 randomization record."
            return True, "OK: assignment reproduced from declared PCG64 seed and within-stratum treated counts."
        except Exception as exc:
            return False, f"ABSTAIN: invalid randomization record: {exc}"

    def sharp_null_test(self, y, treatment, moderator, clusters, assignment_design="cluster", assignment_config=None) -> SharpNullResult:
        """Exact-rational Fisher test of the zero-effect sharp global null.

        This is the tau=0 fixed-point form of the design-based inversion. It is
        not a test of a nonzero constant-effect null or a moderation null.
        """
        if assignment_design != "cluster":
            return SharpNullResult(None,None,True,"ABSTAIN: unsupported assignment design.",
                                   validity_classification="not_run_unsupported_design")
        out=self.constant_effect_inversion(y,treatment,moderator,clusters,
            assignment_config=assignment_config,tau_reference=0.0,fixed_tau_only=True)
        return SharpNullResult(
            statistic=None if out.abstained else (out.diagnostics or {}).get("absolute_t_statistic"),
            p_value=out.p_value,abstained=out.abstained,reason=out.reason,
            validity_classification=out.validity_classification,
            diagnostics=out.diagnostics)

    def constant_effect_inversion(self, y, treatment, moderator, clusters, *, tau_bounds=None,
                                  assignment_config=None, root_tolerance="1/100000000", tau_reference=0.0,
                                  fixed_tau_only=False) -> ConstantEffectResult:
        """Exact design-based inversion using rational arithmetic and Sturm-isolated roots.

        For each complete-cluster allocation A, the CR1 interaction t-statistic
        computed on Y - tau*T has a squared value B_A(tau)/V_A(tau), where both
        numerator and variance are rational polynomials of degree at most two.
        Pairwise permutation-statistic comparisons therefore reduce to exact
        rational polynomials of degree at most four. Their real roots are
        isolated by SymPy's exact QQ root-isolation routine. No floating-point
        tau grid is used.

        The reported confidence set is an OUTER enclosure: every isolating box
        around every comparison root is retained, while root-free intervals
        are classified exactly at a rational point. This can be conservative,
        especially when roots are close. It is conditional on the verified
        complete-cluster randomization record and on the declared assignment
        mechanism. Inputs are treated as their exact IEEE-754 binary rationals.
        """
        self._clear_inference_state()
        try:
            from sympy import Poly, Rational, symbols
            from sympy.polys.domains import QQ
        except Exception as exc:
            return ConstantEffectResult(None, None, None, None, True,
                f"ABSTAIN: exact polynomial root-isolation dependency unavailable: {exc}",
                validity_classification="not_run_missing_exact_polynomial_backend",
                diagnostics={"backend": "fractions_plus_sympy_QQ_root_isolation"})

        def F(v):
            return Fraction.from_float(float(v))

        def inv_matrix(A):
            n=len(A)
            aug=[list(row)+[Fraction(int(i==j),1) for j in range(n)] for i,row in enumerate(A)]
            for col in range(n):
                pivot=next((r for r in range(col,n) if aug[r][col]),None)
                if pivot is None: raise ValueError("exact design matrix is rank deficient")
                aug[col],aug[pivot]=aug[pivot],aug[col]
                z=aug[col][col]; aug[col]=[x/z for x in aug[col]]
                for r in range(n):
                    if r==col: continue
                    z=aug[r][col]
                    if z: aug[r]=[aug[r][j]-z*aug[col][j] for j in range(2*n)]
            return [row[n:] for row in aug]

        def dot(a,b): return sum((x*y for x,y in zip(a,b)), Fraction(0))
        def matvec(A,x): return [dot(row,x) for row in A]
        def transpose(A): return [list(x) for x in zip(*A)]
        def poly_add(a,b):
            n=max(len(a),len(b)); return [((a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0)) for i in range(n)]
        def poly_mul(a,b):
            z=[Fraction(0)]*(len(a)+len(b)-1)
            for i,x in enumerate(a):
                for j,y0 in enumerate(b): z[i+j]+=x*y0
            return z
        def poly_square(a): return poly_mul(a,a)
        def as_sympy_poly(a, tau):
            expr=sum((Rational(x.numerator,x.denominator)*tau**i for i,x in enumerate(a)), Rational(0))
            return Poly(expr,tau,domain=QQ)
        def exact_rank_and_fit(tvec, observed_treatment, yv, mv, cv, cluster_order):
            # Design uses the candidate reassignment tvec; the sharp-null-adjusted
            # outcome is Y - tau*T_observed, using the actually observed assignment.
            X=[[Fraction(1),tvec[i],mv[i],tvec[i]*mv[i]] for i in range(len(yv))]
            Xt=transpose(X); H=[[dot(Xt[i], [row[j] for row in X]) for j in range(4)] for i in range(4)]
            Hi=inv_matrix(H)
            xty=matvec(Xt,yv); xtt=matvec(Xt,observed_treatment)
            by=matvec(Hi,xty); bt=matvec(Hi,xtt)
            ry=[yv[i]-dot(X[i],by) for i in range(len(yv))]
            rt=[observed_treatment[i]-dot(X[i],bt) for i in range(len(yv))]
            u=[Hi[i][3] for i in range(4)]
            weights=[dot(row,u) for row in X]
            z0=[]; z1=[]
            for c in cluster_order:
                ix=[i for i,x in enumerate(cv) if x==c]
                z0.append(sum((weights[i]*ry[i] for i in ix),Fraction(0)))
                z1.append(sum((weights[i]*rt[i] for i in ix),Fraction(0)))
            G=len(cluster_order); n=len(yv); k=4
            if G<=1 or n<=k: raise ValueError("insufficient clusters or observations")
            df=Fraction(G,G-1)*Fraction(n-1,n-k)
            var=[df*sum((z*z for z in z0),Fraction(0)),
                 df*(-2*sum((z0[i]*z1[i] for i in range(G)),Fraction(0))),
                 df*sum((z*z for z in z1),Fraction(0))]
            beta=[by[3],-bt[3]]
            return poly_square(beta),var

        try:
            tau_ref=F(tau_reference)
            if fixed_tau_only and tau_bounds is None:
                lo=hi=tau_ref
            else:
                if tau_bounds is None or not isinstance(tau_bounds,(tuple,list)) or len(tau_bounds)!=2:
                    raise ValueError("analyst-supplied finite tau_bounds are required")
                lo,hi=F(tau_bounds[0]),F(tau_bounds[1])
            if fixed_tau_only:
                if lo!=hi or lo!=tau_ref: raise ValueError("fixed_tau_only requires tau_bounds=(tau_reference, tau_reference)")
            elif not lo<hi:
                raise ValueError("tau_bounds must be finite and increasing")
            tol=Fraction(root_tolerance)
            if tol<=0: raise ValueError("root_tolerance must be positive")
            if not fixed_tau_only and not lo<=tau_ref<=hi: raise ValueError("tau_reference must lie inside tau_bounds")
            yy=np.asarray(y,dtype=float); tt=np.asarray(treatment,dtype=float); mm=np.asarray(moderator,dtype=float)
            if any(a.ndim!=1 for a in (yy,tt,mm)) or len(yy)==0 or not (len(yy)==len(tt)==len(mm)):
                raise ValueError("input vectors must be nonempty, one-dimensional, and equal length")
            if not (np.isfinite(yy).all() and np.isfinite(tt).all() and np.isfinite(mm).all()):
                raise ValueError("input vectors must be finite")
            if not set(np.unique(tt)).issubset({0.0,1.0}): raise ValueError("treatment must be binary")
            ca, cluster_order, _=self._validate_and_extract_clusters(clusters,len(yy))
            for c in cluster_order:
                if len(np.unique(tt[ca==c]))!=1: raise ValueError(f"treatment varies within cluster {c}")
            ok,why=self.verify_randomization_record(tt,ca,assignment_config)
            if not ok: raise ValueError(why)
            # Normalize cluster-level strata exactly as required by the randomization record.
            cfg=assignment_config
            strata=list(cfg.get("strata",[0]*len(cluster_order)))
            if len(strata)!=len(cluster_order): raise ValueError("assignment_config['strata'] must be cluster-level and aligned to first-appearance cluster order")
            strata=self._validate_strata_vector(strata,"cluster-level strata")
            groups={}
            for c,st in zip(cluster_order,strata): groups.setdefault(st,[]).append(c)
            t_by={c:float(np.unique(tt[ca==c])[0]) for c in cluster_order}
            strata_info=[]; total=1
            for st,members in groups.items():
                k=sum(t_by[c]==1.0 for c in members); total*=math.comb(len(members),k)
                strata_info.append((members,k))
            if total>self.exact_enumeration_threshold:
                raise ValueError(f"exact inversion requires full enumeration; allocation space {total} exceeds threshold {self.exact_enumeration_threshold}")
            yq=[F(x) for x in yy]; mq=[F(x) for x in mm]; tq=[F(x) for x in tt]
            allocs=[]
            for pieces in product(*[list(combinations(members,k)) for members,k in strata_info]):
                treated=set().union(*(set(x) for x in pieces))
                av=[Fraction(int(c in treated),1) for c in cluster_order]
                amap=dict(zip(cluster_order,av))
                tv=[amap[c] for c in ca]
                allocs.append((treated,tv))
            observed_treated=frozenset(c for c in cluster_order if t_by[c]==1.0)
            observed_idx=next((i for i,(a,_) in enumerate(allocs) if a==observed_treated),None)
            if observed_idx is None: raise ValueError("observed assignment is absent from declared allocation space")
            fits=[]; excluded=[]
            for idx,(a,tv) in enumerate(allocs):
                try:
                    bpoly,vpoly=exact_rank_and_fit(tv,tq,yq,mq,ca,cluster_order)
                    if not any(vpoly): raise ValueError("CR1 variance polynomial is identically zero")
                    fits.append((idx,bpoly,vpoly))
                except Exception as exc:
                    excluded.append({"allocation_index":idx,"reason":str(exc)})
            if not fits or observed_idx not in {x[0] for x in fits}:
                raise ValueError("observed allocation is not exactly full rank / variance estimable")
            # Conditional randomization over the design-only set of estimable allocations.
            tau=symbols('tau')
            lo_s=Rational(lo.numerator,lo.denominator); hi_s=Rational(hi.numerator,hi.denominator)
            tol_s=Rational(tol.numerator,tol.denominator)
            def roots_in_domain(coeff):
                P=as_sympy_poly(coeff,tau)
                if P.is_zero: return []
                ints=P.intervals(eps=tol_s)
                out=[]
                for (a,b),mult in ints:
                    if b < lo_s or a > hi_s: continue
                    aa=max(a,lo_s); bb=min(b,hi_s)
                    out.append((Fraction(int(aa.p),int(aa.q)),Fraction(int(bb.p),int(bb.q))))
                return out
            # All variance polynomials must remain strictly positive throughout the declared tau domain.
            for idx,bp,vp in fits:
                if fixed_tau_only:
                    vm=sum((vp[j]*tau_ref**j for j in range(len(vp))),Fraction(0))
                else:
                    if roots_in_domain(vp): raise ValueError(f"CR1 variance reaches zero within tau_bounds for allocation {idx}")
                    vm=sum((vp[j]*(Fraction(1,2)*(lo+hi))**j for j in range(len(vp))),Fraction(0))
                if vm<=0: raise ValueError(f"CR1 variance is not positive for allocation {idx}")
            obs=next(x for x in fits if x[0]==observed_idx)
            comparisons=[]; root_boxes=[]
            for idx,bp,vp in fits:
                op=poly_mul(bp,obs[2]); oq=poly_mul(obs[1],vp)
                cp=poly_add(op,[-x for x in oq])
                comparisons.append((idx,cp))
                if not fixed_tau_only:
                    root_boxes.extend(roots_in_domain(cp))
            def p_at(x):
                count=0
                for _,cp in comparisons:
                    val=sum((coef*x**j for j,coef in enumerate(cp)),Fraction(0))
                    if val>=0: count+=1
                return Fraction(count,len(comparisons))
            if fixed_tau_only:
                p_ref=p_at(tau_ref)
                observed_fit=next(x for x in fits if x[0]==observed_idx)
                obs_b=sum((observed_fit[1][j]*tau_ref**j for j in range(len(observed_fit[1]))),Fraction(0))
                obs_v=sum((observed_fit[2][j]*tau_ref**j for j in range(len(observed_fit[2]))),Fraction(0))
                diag={"backend":"python_fractions_exact_rational_algebra",
                      "input_interpretation":"exact_binary64_rationals",
                      "allocation_space_size":len(allocs),"valid_allocation_count":len(fits),
                      "excluded_rank_or_variance_allocations":excluded,
                      "conditional_on_estimable_allocation_set":bool(excluded),
                      "tau_reference":str(tau_ref),"p_value_at_tau_reference":str(p_ref),
                      "observed_t_statistic_squared":str(obs_b/obs_v),
                      "absolute_t_statistic":math.sqrt(float(obs_b/obs_v)),
                      "validity":"exact Fisher sharp-null randomization p-value conditional on verified assignment and estimable allocation set"}
                return ConstantEffectResult(float(tau_ref),float(p_ref),None,None,False,
                    "OK: exact-rational fixed-tau randomization test.",
                    method="exact_rational_fixed_tau_randomization_test",
                    validity_classification="design_based_exact_conditional_on_verified_assignment_and_estimable_allocation_set",
                    diagnostics=diag)
            root_boxes.sort()
            merged=[]
            for a,b in root_boxes:
                if merged and a<=merged[-1][1]+tol:
                    merged[-1]=(merged[-1][0],max(merged[-1][1],b))
                else: merged.append((a,b))
            accepted=[]; cursor=lo
            for a,b in merged:
                if cursor<a:
                    mid=(cursor+a)/2
                    if p_at(mid)>Fraction(str(self.alpha)):
                        accepted.append((cursor,a))
                # Retain a root box only when the exact sign analysis cannot
                # rule out non-rejection somewhere inside it. Any comparison
                # polynomial with a root in the box is counted as potentially
                # nonnegative; root-free polynomials have constant sign there.
                possible_nonnegative=0
                mid=(a+b)/2
                for _,cp in comparisons:
                    has_root=any(ra<=b and rb>=a for ra,rb in roots_in_domain(cp))
                    val=sum((coef*mid**j for j,coef in enumerate(cp)),Fraction(0))
                    if has_root or val>=0: possible_nonnegative+=1
                if Fraction(possible_nonnegative,len(comparisons))>Fraction(str(self.alpha)):
                    accepted.append((max(lo,a),min(hi,b)))
                cursor=max(cursor,b)
            if cursor<hi:
                mid=(cursor+hi)/2
                if p_at(mid)>Fraction(str(self.alpha)): accepted.append((cursor,hi))
            if not merged and p_at((lo+hi)/2)>Fraction(str(self.alpha)):
                accepted=[(lo,hi)]
            accepted.sort(); components=[]
            for a,b in accepted:
                if components and a<=components[-1][1]: components[-1]=(components[-1][0],max(components[-1][1],b))
                else: components.append((a,b))
            if not components:
                ci_lo=ci_hi=None
            else:
                exact_lo=min(x[0] for x in components); exact_hi=max(x[1] for x in components)
                ci_lo=float(exact_lo); ci_hi=float(exact_hi)
                # Keep the public float hull outward-rounded relative to the
                # exact rational endpoints; diagnostics retain exact fractions.
                if Fraction.from_float(ci_lo)>exact_lo: ci_lo=math.nextafter(ci_lo,-math.inf)
                if Fraction.from_float(ci_hi)<exact_hi: ci_hi=math.nextafter(ci_hi,math.inf)
            diag={"backend":"python_fractions_exact_rational_algebra_plus_sympy_QQ_Sturm_root_isolation",
                  "input_interpretation":"exact_binary64_rationals",
                  "allocation_space_size":len(allocs),"valid_allocation_count":len(fits),
                  "excluded_rank_or_variance_allocations":excluded,
                  "conditional_on_estimable_allocation_set":bool(excluded),
                  "comparison_polynomial_degree_max":4,"root_tolerance_rational":str(tol),
                  "comparison_root_isolating_boxes":[[str(a),str(b)] for a,b in merged],
                  "confidence_set_outer_enclosure":[[str(a),str(b)] for a,b in components],
                  "confidence_set_components_count":len(components),
                  "alpha":self.alpha,"tau_reference":str(tau_ref),
                  "p_value_at_tau_reference":str(p_at(tau_ref)),
                  "validity":"design_based_conditional_randomization_inversion; exact rational comparisons; outer-enclosed root boxes",
                  "method_note":"All root-free cells classified by exact rational evaluation; all root boxes retained conservatively."}
            p_ref=p_at(tau_ref)
            return ConstantEffectResult(float(tau_ref),float(p_ref),ci_lo,ci_hi,False,
                "OK: exact design-based constant-effect inversion; p_value is for tau_reference and the reported interval is the hull of a certified outer enclosure.",
                method="exact_rational_design_based_inversion",
                validity_classification="design_based_exact_conditional_on_verified_assignment_and_estimable_allocation_set",
                diagnostics=diag)
        except Exception as exc:
            return ConstantEffectResult(None,None,None,None,True,f"ABSTAIN: {exc}",
                validity_classification="not_run_or_unresolved_exact_rational_backend",
                diagnostics={"backend":"python_fractions_exact_rational_algebra_plus_sympy_QQ_root_isolation"})

    def constant_effect_wald(self, y, treatment, moderator, clusters) -> ConstantEffectResult:
        """Secondary asymptotic CR1 Wald test for the treatment-by-moderator term.

        This tests zero interaction, not the Fisher sharp null. It is explicitly
        asymptotic in the number of clusters and must not be presented as exact.
        """
        from scipy.stats import t as student_t
        try:
            _, beta, se = self.compute_cluster_robust_stat(y, treatment, moderator, clusters)
            G = int(self.last_cr1_model_fit_["G"])
            df = G - 4  # conservative cluster degrees of freedom for the four-parameter model
            if df <= 0:
                raise ValueError("Insufficient cluster degrees of freedom for CR1 Wald inference.")
            statistic = float(beta / se)
            p = float(2.0 * student_t.sf(abs(statistic), df=df))
            return ConstantEffectResult(
                tau_null=0.0, p_value=p, ci_lower=None, ci_upper=None, abstained=False,
                reason="OK; asymptotic CR1 Wald inference only.", method="cr1_wald_interaction",
                validity_classification="asymptotic_in_G_not_finite_sample_exact",
                diagnostics={"beta_interaction": beta, "se_interaction": se, "t_statistic": statistic,
                             "degrees_of_freedom": df, "clusters": G}
            )
        except Exception as exc:
            return ConstantEffectResult(None, None, None, None, True, f"ABSTAIN: {exc}",
                                        method="cr1_wald_interaction",
                                        validity_classification="not_run")

    def holm_result(self, p_values: np.ndarray) -> HolmResult:
        adjusted = self.holm_bonferroni_adjustment(p_values)
        untestable = tuple(i for i, flag in enumerate(self.untestable_flags_) if flag)
        return HolmResult(tuple(float(x) for x in adjusted),
                          tuple(bool(x <= self.alpha) for x in adjusted),
                          untestable, float(self.alpha))

    def holm_bonferroni_adjustment(self, p_values: np.ndarray) -> np.ndarray:
        """Applies step-down Holm-Bonferroni FWER adjustment across hypothesis family."""
        if not self.family_hypotheses_:
            raise ValueError("Hypothesis family must be constructed via construct_family() before Holm adjustment.")

        if p_values is None:
            raise ValueError("p_values vector cannot be None.")

        try:
            p_vals_arr = np.array(p_values, dtype=float)
        except Exception:
            raise ValueError("Failed to convert p_values to numeric array.")

        if p_vals_arr.ndim != 1:
            raise ValueError("p_values vector must be one-dimensional.")

        if len(p_vals_arr) != len(self.family_hypotheses_):
            raise ValueError(
                f"Mismatch in hypothesis family size: expected {len(self.family_hypotheses_)}, "
                f"got p-value vector of length {len(p_vals_arr)}."
            )

        if not np.isfinite(p_vals_arr).all():
            raise ValueError("Non-finite p-values detected.")

        if np.any((p_vals_arr < 0.0) | (p_vals_arr > 1.0)):
            raise ValueError("p-values outside valid [0, 1] probability bounds detected.")

        for idx, is_untestable in enumerate(self.untestable_flags_):
            if is_untestable and p_vals_arr[idx] < 1.0:
                raise ValueError(f"Untestable hypothesis at index {idx} must be assigned p = 1.0.")

        m = len(p_vals_arr)
        if m == 0:
            return np.array([], dtype=float)

        sorted_indices = np.argsort(p_vals_arr)
        sorted_p = p_vals_arr[sorted_indices]
        adjusted_p = np.zeros_like(p_vals_arr, dtype=float)
        current_min = 0.0

        for i, idx in enumerate(sorted_indices):
            adj = (m - i) * sorted_p[i]
            adj = min(1.0, max(current_min, adj))
            current_min = adj
            adjusted_p[idx] = adj

        return adjusted_p
