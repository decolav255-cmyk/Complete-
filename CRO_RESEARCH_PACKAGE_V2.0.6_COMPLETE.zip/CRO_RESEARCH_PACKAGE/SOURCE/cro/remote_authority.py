"""Separately deployable CRO lease authority service (stdlib HTTP, PostgreSQL production state)."""
from __future__ import annotations
import base64, hmac, json, os, sqlite3, time, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519
from cro.policy import AuthorizationAuthority
from cro.postgres_compat import PostgresConnection


def load_authority_signing_key(path: str) -> ed25519.Ed25519PrivateKey:
    """Load a pre-provisioned authority key; never generate a new production identity."""
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError("authority signing key must be provisioned before service startup")
    if os.name != "nt":
        mode = p.stat().st_mode & 0o777
        if mode & 0o077 or not mode & 0o400:
            raise PermissionError(
                "authority signing key must be owner-readable and inaccessible to group/other users"
            )
    raw = p.read_bytes()
    key = serialization.load_pem_private_key(raw, password=None)
    if not isinstance(key, ed25519.Ed25519PrivateKey):
        raise TypeError("authority key must be Ed25519")
    return key


class _TokenBucket:
    """Per-process rate limiter. Not distributed; proxy-level limits remain required."""

    def __init__(self, rate: int = 30, per_seconds: float = 1.0):
        self.rate = max(1, int(rate))
        self.per = float(per_seconds)
        self._lock = threading.Lock()
        self._tokens = float(self.rate)
        self._updated = time.monotonic()

    def allow(self) -> bool:
        with self._lock:
            now = time.monotonic()
            elapsed = now - self._updated
            self._updated = now
            self._tokens = min(self.rate, self._tokens + elapsed * (self.rate / self.per))
            if self._tokens >= 1.0:
                self._tokens -= 1.0
                return True
            return False


class AuthorityApplication:
    def __init__(self, db_path: str, key_path: str, admin_token: str, admin_token_previous: str | None = None):
        if not admin_token or len(admin_token) < 32:
            raise ValueError("CRO_AUTHORITY_ADMIN_TOKEN must contain at least 32 characters")
        if admin_token_previous is not None:
            if len(admin_token_previous) < 32:
                raise ValueError("CRO_AUTHORITY_ADMIN_TOKEN_PREVIOUS must contain at least 32 characters")
            if admin_token_previous == admin_token:
                raise ValueError("CRO_AUTHORITY_ADMIN_TOKEN_PREVIOUS must differ from the primary token")
        self.db_path, self.key_path = db_path, key_path
        self.admin_token = admin_token
        self.admin_token_previous = admin_token_previous
        self.key = load_authority_signing_key(key_path)
        self.public_key_pem = (
            self.key.public_key()
            .public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
            .decode()
        )
        db = self._connect()
        try:
            AuthorizationAuthority(db, self.key)
        finally:
            db.close()

    def _connect(self):
        if self.db_path.startswith(("postgres://", "postgresql://")):
            return PostgresConnection(self.db_path)
        return sqlite3.connect(self.db_path, timeout=15, isolation_level=None)

    def issue(self, body: dict) -> dict:
        required = {"candidate_id", "worker_id", "epoch"}
        if not isinstance(body, dict) or set(body) - (required | {"ttl_seconds"}) or not required <= set(body):
            raise ValueError("request must contain candidate_id, worker_id, epoch and optional ttl_seconds")
        db = self._connect()
        try:
            result = AuthorizationAuthority(db, self.key).issue_lease_token(
                body["candidate_id"], body["worker_id"], body["epoch"], body.get("ttl_seconds", 30)
            )
        finally:
            db.close()
        return {"claims": result["claims"], "signature_b64": base64.b64encode(result["signature"]).decode()}

    def current_epoch(self) -> int:
        db = self._connect()
        try:
            row = db.execute("SELECT authority_epoch FROM authority_state WHERE id=1").fetchone()
            return int(row[0])
        finally:
            db.close()

    def revoke(self, body: dict) -> dict:
        if not isinstance(body, dict) or set(body) != {"worker_id", "reason"}:
            raise ValueError("request must contain worker_id and reason")
        db = self._connect()
        try:
            epoch = AuthorizationAuthority(db, self.key).revoke_worker(body["worker_id"], body["reason"])
        finally:
            db.close()
        return {"revocation_epoch": epoch, "worker_id": body["worker_id"]}

    def _check_admin(self, supplied: str) -> bool:
        if not isinstance(supplied, str):
            return False
        primary = "Bearer " + self.admin_token
        if hmac.compare_digest(supplied.encode("utf-8"), primary.encode("utf-8")):
            return True
        if self.admin_token_previous:
            previous = "Bearer " + self.admin_token_previous
            if hmac.compare_digest(supplied.encode("utf-8"), previous.encode("utf-8")):
                return True
        return False


def make_handler(app: AuthorityApplication):
    # Unauthenticated limiter is deliberately tighter so floods cannot exhaust
    # the authenticated allowance. Authenticated limiter applies after credential check.
    unauth_limiter = _TokenBucket(rate=int(os.environ.get("CRO_AUTHORITY_UNAUTH_RATE_LIMIT", "10")), per_seconds=1.0)
    auth_limiter = _TokenBucket(rate=int(os.environ.get("CRO_AUTHORITY_RATE_LIMIT", "30")), per_seconds=1.0)
    max_body = int(os.environ.get("CRO_AUTHORITY_MAX_BODY", "16384"))

    class Handler(BaseHTTPRequestHandler):
        server_version = "CROAuthority/1.0"

        def log_message(self, fmt, *args):
            # Never log Authorization headers, tokens, or request bodies.
            super().log_message(fmt, *args)

        def _send(self, status, data):
            raw = json.dumps(data, separators=(",", ":")).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self):
            if not unauth_limiter.allow():
                return self._send(429, {"error": "rate_limited"})
            path = urlparse(self.path).path
            if path == "/health":
                return self._send(200, {"status": "ok", "service": "cro-authorization-authority"})
            if path == "/v1/epoch":
                return self._send(200, {"authority_epoch": app.current_epoch()})
            return self._send(404, {"error": "not_found"})

        def do_POST(self):
            # Size check before any body read.
            try:
                length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                return self._send(400, {"error": "invalid_request_size"})
            if length <= 0 or length > max_body:
                return self._send(413, {"error": "invalid_request_size"})

            # Unauthenticated rate limit before credential work.
            if not unauth_limiter.allow():
                return self._send(429, {"error": "rate_limited"})

            supplied = self.headers.get("Authorization", "")
            if not app._check_admin(supplied):
                return self._send(401, {"error": "unauthorized"})

            # Authenticated rate limit after successful credential verification.
            if not auth_limiter.allow():
                return self._send(429, {"error": "rate_limited"})

            try:
                body = json.loads(self.rfile.read(length))
                route = urlparse(self.path).path
                if route == "/v1/lease":
                    result = app.issue(body)
                elif route == "/v1/revoke":
                    result = app.revoke(body)
                else:
                    return self._send(404, {"error": "not_found"})
                return self._send(200, result)
            except (ValueError, TypeError, KeyError, json.JSONDecodeError) as e:
                return self._send(400, {"error": "invalid_request", "detail": str(e)[:240]})
            except PermissionError as e:
                return self._send(403, {"error": "forbidden", "detail": str(e)[:240]})
            except Exception:
                return self._send(500, {"error": "internal_error"})

    return Handler


def serve_from_env():
    host = os.environ.get("CRO_AUTHORITY_HOST", "127.0.0.1")
    port = int(os.environ.get("CRO_AUTHORITY_PORT", "8765"))
    allow_cleartext = os.environ.get("CRO_AUTHORITY_ALLOW_CLEARTEXT", "").strip() == "1"
    loopback = host in ("127.0.0.1", "::1", "localhost")
    if not loopback and not allow_cleartext:
        raise RuntimeError(
            "CRO authority refuses non-loopback cleartext. "
            "Terminate TLS at a reverse proxy / load balancer, or set "
            "CRO_AUTHORITY_ALLOW_CLEARTEXT=1 for local laboratory use only. "
            "mTLS or network allow-lists are required for any non-lab deployment. "
            "TLS is not implemented inside this standard-library HTTP server."
        )
    previous = os.environ.get("CRO_AUTHORITY_ADMIN_TOKEN_PREVIOUS", "").strip() or None
    app = AuthorityApplication(
        os.environ.get("CRO_AUTHORITY_DSN", os.environ.get("CRO_AUTHORITY_DB", "./state/authority.sqlite3")),
        os.environ["CRO_AUTHORITY_KEY_FILE"],
        os.environ["CRO_AUTHORITY_ADMIN_TOKEN"],
        admin_token_previous=previous,
    )
    ThreadingHTTPServer((host, port), make_handler(app)).serve_forever()


if __name__ == "__main__":
    serve_from_env()
