"""PostgreSQL connection adapter for CRO's existing DB-API/qmark persistence code.

PostgreSQL is the target production backend; SQLite remains the local-test backend.
Append-only guarantees are enforced by PostgreSQL triggers installed by migration 002.
"""
from __future__ import annotations
import re
import time
from functools import wraps

class PostgresCursor:
    def __init__(self, cursor): self._cursor = cursor
    def fetchone(self): return self._cursor.fetchone() if self._cursor is not None else None
    def fetchall(self): return self._cursor.fetchall() if self._cursor is not None else []
    @property
    def rowcount(self): return self._cursor.rowcount if self._cursor is not None else -1
    def close(self):
        if self._cursor is not None: self._cursor.close()


def retry_postgres_serialization(*, connection_attr: str | None = None, dsn_attr: str | None = None, max_attempts: int = 5):
    """Retry an entire idempotent DB-only method after serialization/deadlock aborts.

    The decorated method must roll back/close its failed transaction before raising.
    External side effects are prohibited inside the method; retry only SQLSTATE 40001/40P01.
    """
    if (connection_attr is None) == (dsn_attr is None):
        raise ValueError("provide exactly one of connection_attr or dsn_attr")
    if isinstance(max_attempts, bool) or not isinstance(max_attempts, int) or not 1 <= max_attempts <= 10:
        raise ValueError("max_attempts must be between 1 and 10")

    def decorate(fn):
        @wraps(fn)
        def wrapped(self, *args, **kwargs):
            if connection_attr is not None:
                backend = isinstance(getattr(self, connection_attr, None), PostgresConnection)
            else:
                dsn = getattr(self, dsn_attr, "")
                backend = isinstance(dsn, str) and dsn.startswith(("postgres://", "postgresql://"))
            if not backend:
                return fn(self, *args, **kwargs)
            for attempt in range(max_attempts):
                try:
                    return fn(self, *args, **kwargs)
                except Exception as exc:
                    if getattr(exc, "sqlstate", None) not in {"40001", "40P01"} or attempt + 1 >= max_attempts:
                        raise
                    conn = getattr(self, connection_attr, None) if connection_attr else None
                    if isinstance(conn, PostgresConnection) and conn.in_transaction:
                        conn.rollback()
                    time.sleep(0.02 * (2 ** attempt))
            raise AssertionError("unreachable retry loop")
        return wrapped
    return decorate


class PostgresConnection:
    def __init__(self, dsn: str, connect_timeout: int = 10):
        try: import psycopg
        except ImportError as exc: raise RuntimeError("Install optional dependency psycopg[binary]>=3.1") from exc
        self._psycopg = psycopg
        self._conn = psycopg.connect(dsn, autocommit=True, connect_timeout=connect_timeout)
        self._active = False
        self._depth = 0

    @staticmethod
    def _sql(sql: str) -> str:
        # PostgreSQL equivalents are installed by migration 002; execute() verifies them.
        if re.match(r"\s*CREATE\s+TRIGGER\s+IF\s+NOT\s+EXISTS", sql, re.I): return sql
        sql = re.sub(r"INTEGER\s+PRIMARY\s+KEY\s+AUTOINCREMENT", "BIGSERIAL PRIMARY KEY", sql, flags=re.I)
        sql = re.sub(r"\bBLOB\b", "BYTEA", sql, flags=re.I)
        ignore_insert = bool(re.search(r"INSERT\s+OR\s+IGNORE\s+INTO", sql, re.I))
        sql = re.sub(r"INSERT\s+OR\s+IGNORE\s+INTO", "INSERT INTO", sql, flags=re.I)
        if ignore_insert and "ON CONFLICT" not in sql.upper():
            sql += " ON CONFLICT DO NOTHING"
        sql = re.sub(r"MAX\(([^(),]+),\s*([^()]+)\)", r"GREATEST(\1, \2)", sql, flags=re.I)
        sql = re.sub(r"MIN\(([^(),]+),\s*([^()]+)\)", r"LEAST(\1, \2)", sql, flags=re.I)
        sql = sql.replace("BEGIN IMMEDIATE", "BEGIN ISOLATION LEVEL SERIALIZABLE")
        out, quote, i = [], None, 0
        while i < len(sql):
            c = sql[i]
            if quote:
                out.append(c)
                if c == quote:
                    if i + 1 < len(sql) and sql[i+1] == quote: out.append(sql[i+1]); i += 1
                    else: quote = None
            elif c in ("'", '"'): quote = c; out.append(c)
            elif c == "?": out.append("%s")
            else: out.append(c)
            i += 1
        return "".join(out)

    def execute(self, sql, params=()):
        converted = self._sql(sql)
        trigger = re.match(r"\s*CREATE\s+TRIGGER\s+IF\s+NOT\s+EXISTS\s+(\w+)\s+BEFORE\s+(?:UPDATE|DELETE)\s+ON\s+(\w+)", converted, re.I)
        if trigger:
            name, table = trigger.group(1), trigger.group(2)
            with self._conn.cursor() as check:
                check.execute("SELECT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE t.tgname=%s AND c.relname=%s AND n.nspname=current_schema() AND NOT t.tgisinternal)", (name, table))
                if not check.fetchone()[0]:
                    raise RuntimeError(f"Required PostgreSQL append-only trigger {name} is missing; apply migration 002_cro_core.sql")
            return PostgresCursor(None)
        is_begin = converted.lstrip().upper().startswith("BEGIN")
        if is_begin and self._active:
            raise RuntimeError("transaction already active")
        cur = self._conn.cursor()
        try:
            cur.execute(converted, params)
        except BaseException:
            cur.close()
            raise
        if is_begin:
            self._active = True
        return PostgresCursor(cur)
    @property
    def in_transaction(self): return self._active
    def commit(self):
        try:
            self._conn.commit()
        except BaseException:
            try:
                self._conn.rollback()
            except BaseException:
                pass
            self._active = False
            raise
        else:
            self._active = False
    def rollback(self):
        try: self._conn.rollback()
        finally: self._active = False
    def __enter__(self):
        if not self._active:
            self.execute("BEGIN ISOLATION LEVEL SERIALIZABLE")
        self._depth += 1
        return self
    def __exit__(self, typ, value, tb):
        self._depth = max(0, self._depth - 1)
        if self._depth == 0 and self._active:
            self.commit() if typ is None else self.rollback()
    def close(self):
        if self._active:
            self.rollback()
        self._conn.close()
