"""Cryptographically verified remote anchors and durable clock rollback detection (G6)."""
from __future__ import annotations

import math
import sqlite3
import time
from typing import Any, Dict, Optional
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.exceptions import InvalidSignature
from cro.postgres_compat import retry_postgres_serialization


class CheckpointMonitor:
    def __init__(self, db_conn: sqlite3.Connection,
                 authority_public_key: Optional[ed25519.Ed25519PublicKey] = None,
                 max_unanchored_seconds: int = 3600, rollback_tolerance: float = 1.5):
        if max_unanchored_seconds <= 0:
            raise ValueError("max_unanchored_seconds must be positive")
        self.conn = db_conn
        self.authority_public_key = authority_public_key
        self.max_interval = max_unanchored_seconds
        self.rollback_tolerance = rollback_tolerance
        self._init_schema()

    @retry_postgres_serialization(connection_attr="conn")
    def _init_schema(self) -> None:
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            self.conn.execute("""CREATE TABLE IF NOT EXISTS verified_anchors (
                anchor_hash TEXT PRIMARY KEY, timestamp REAL NOT NULL,
                signature BLOB NOT NULL, recorded_at REAL NOT NULL)""")
            self.conn.execute("""CREATE TABLE IF NOT EXISTS clock_watermark (
                id INTEGER PRIMARY KEY CHECK(id=1), max_observed_wall REAL NOT NULL)""")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS verified_anchors_no_update BEFORE UPDATE ON verified_anchors BEGIN SELECT RAISE(ABORT,'verified anchors are append-only'); END")
            self.conn.execute("CREATE TRIGGER IF NOT EXISTS verified_anchors_no_delete BEFORE DELETE ON verified_anchors BEGIN SELECT RAISE(ABORT,'verified anchors are append-only'); END")
            now = time.time()
            row = self.conn.execute("SELECT max_observed_wall FROM clock_watermark WHERE id=1").fetchone()
            if row is None:
                self.conn.execute("INSERT INTO clock_watermark(id,max_observed_wall) VALUES(1,?)", (now,))
            elif now < row[0] - self.rollback_tolerance:
                raise RuntimeError(f"CRITICAL: clock rollback detected across restart ({now} < {row[0]})")
            else:
                self.conn.execute("UPDATE clock_watermark SET max_observed_wall=MAX(max_observed_wall,?) WHERE id=1", (now,))
            self.conn.commit()
        except BaseException:
            self.conn.rollback()
            raise

    def _update_watermark_in_transaction(self, now: float) -> None:
        row = self.conn.execute("SELECT max_observed_wall FROM clock_watermark WHERE id=1").fetchone()
        if row is None:
            raise RuntimeError("clock watermark is missing")
        if now < row[0] - self.rollback_tolerance:
            raise RuntimeError(f"CRITICAL: clock rollback detected ({now} < {row[0]})")
        self.conn.execute("UPDATE clock_watermark SET max_observed_wall=MAX(max_observed_wall,?) WHERE id=1", (now,))

    @retry_postgres_serialization(connection_attr="conn")
    def record_cryptographically_verified_anchor(self, anchor_payload: Dict[str, Any], signature: bytes) -> None:
        if self.authority_public_key is None:
            raise RuntimeError("independent remote authority public key is not configured")
        if not isinstance(anchor_payload, dict):
            raise TypeError("anchor_payload must be a dictionary")
        anchor_hash = anchor_payload.get("anchor_hash")
        timestamp = anchor_payload.get("timestamp")
        if not isinstance(anchor_hash, str) or not anchor_hash.strip():
            raise ValueError("anchor payload requires a non-empty anchor_hash")
        if isinstance(timestamp, bool) or not isinstance(timestamp, (int, float)) or not math.isfinite(float(timestamp)) or timestamp < 0:
            raise ValueError("anchor timestamp must be a finite non-negative number")
        from cro.trace_integrity import canonical_serialize
        serialized = canonical_serialize(anchor_payload)
        message = b"CRO_ANCHOR_VERIFY_V1" + len(serialized).to_bytes(8, "big") + serialized
        try:
            self.authority_public_key.verify(signature, message)
        except InvalidSignature as exc:
            raise ValueError("cryptographic verification of remote anchor signature failed") from exc

        self.conn.execute("BEGIN IMMEDIATE")
        try:
            now = time.time()
            self._update_watermark_in_transaction(now)
            if float(timestamp) > now + 2.0:
                raise ValueError("future-dated anchor evidence rejected")
            row = self.conn.execute("SELECT timestamp,signature FROM verified_anchors WHERE anchor_hash=?", (anchor_hash,)).fetchone()
            if row and (row[0] != float(timestamp) or row[1] != signature):
                raise ValueError("conflicting duplicate anchor hash rejected")
            inserted = self.conn.execute(
                "INSERT OR IGNORE INTO verified_anchors(anchor_hash,timestamp,signature,recorded_at) VALUES(?,?,?,?)",
                (anchor_hash, float(timestamp), signature, now),
            )
            if inserted.rowcount == 0:
                raced = self.conn.execute("SELECT timestamp,signature FROM verified_anchors WHERE anchor_hash=?", (anchor_hash,)).fetchone()
                if raced is None or raced[0] != float(timestamp) or raced[1] != signature:
                    raise ValueError("conflicting concurrent duplicate anchor hash rejected")
            self.conn.commit()
        except BaseException:
            self.conn.rollback()
            raise

    def get_latest_anchor_timestamp(self) -> Optional[float]:
        row = self.conn.execute("SELECT MAX(timestamp) FROM verified_anchors").fetchone()
        return row[0] if row and row[0] is not None else None

    @retry_postgres_serialization(connection_attr="conn")
    def evaluate_checkpoint(self) -> Dict[str, Any]:
        self.conn.execute("BEGIN IMMEDIATE")
        try:
            now = time.time()
            self._update_watermark_in_transaction(now)
            self.conn.commit()
        except RuntimeError as exc:
            self.conn.rollback()
            return {"anchored": False, "reason": str(exc), "status": "FAIL_CLOSED_RELEASE_BLOCKED"}
        latest = self.get_latest_anchor_timestamp()
        if latest is None:
            return {"anchored": False, "reason": "no cryptographically verified remote anchor established", "status": "FAIL_CLOSED_RELEASE_BLOCKED"}
        elapsed = now - latest
        if elapsed < -2.0 or elapsed > self.max_interval:
            return {"anchored": False, "reason": f"anchor age {elapsed:.1f}s is outside the permitted window", "status": "FAIL_CLOSED_RELEASE_BLOCKED"}
        return {"anchored": True, "reason": "within valid anchoring window and cryptographically verified", "status": "PASS"}
