# CRO source layout and verification

## Frozen scientific implementation

- `cro/pooled_screen.py` is the frozen R23 Phase 1 implementation, preserved byte-for-byte at approved SHA-256 `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`.
- `CRO_DEMONSTRATION_SPEC_v2.0.5.md` and its approval record remain the approved scientific baseline. The deployment work does not expand the scientific claims.

## Persistence and deployment implementation

- `cro/policy.py`, `engine.py`, `remote_authority.py`, `idempotent_receiver.py`, `trace_integrity.py` (durable trusted-key history), and `pilot.py` (checkpoint anchors/clock watermark) support SQLite local testing and the PostgreSQL compatibility adapter.
- `cro/postgres_compat.py` provides qmark SQL adaptation, SERIALIZABLE transaction handling, migration-trigger checks, and bounded retry decorators for retryable database-only operations.
- `cro/postgres_store.py` provides a PostgreSQL SERIALIZABLE durable-outbox store with bounded retry handling.
- `DEPLOYMENT/postgresql/001_durable_outbox.sql` and `002_cro_core.sql` provision PostgreSQL schemas and append-only triggers; `003_create_runtime_role.sh` creates a separate non-superuser `cro_app` runtime role for a fresh Compose database volume.
- `DEPLOYMENT/` contains Docker Compose, secret templates, security baseline and runbook. `scripts/run_postgres16_gate.sh` runs the live PostgreSQL 16/Docker gate.

## Local test suite

```bash
python -m pip install -r SOURCE/requirements-test.txt
PYTHONPATH=SOURCE python -m pytest -q SOURCE/tests
```

## Live PostgreSQL 16 gate

Follow `VALIDATION/POSTGRES16_LIVE_VERIFICATION_PROCEDURE.md`, provision local test secrets and run:

```bash
bash scripts/run_postgres16_gate.sh
```

This gate requires Docker Compose, PostgreSQL 16 image access, `psycopg`, and a reachable host DSN. Live integration tests are skipped when `CRO_TEST_POSTGRES_DSN` is absent. A local test-suite pass does not certify PostgreSQL compatibility or production readiness.

## Release status

The current artifact is an implementation candidate pending live PostgreSQL 16 and Docker verification, independent security review, customer-specific data controls, backup/restore checks and owner-controlled detached release signing. Keep production authorization traffic disabled until those gates are complete.
