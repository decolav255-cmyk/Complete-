"""PostgreSQL 16 live gates. Set CRO_TEST_POSTGRES_DSN to execute these tests."""
import base64
import os
import threading
import time
import uuid

import pytest
from cryptography.hazmat.primitives.asymmetric import ed25519

from cro.engine import DurableEngine, EngineState
from cro.idempotent_receiver import IdempotentReceiver
from cro.policy import AuthorizationAuthority, DurablePolicyManager
from cro.postgres_compat import PostgresConnection

DSN = os.environ.get("CRO_TEST_POSTGRES_DSN")
pytestmark = [pytest.mark.integration, pytest.mark.skipif(not DSN, reason="CRO_TEST_POSTGRES_DSN not configured")]


def _retry_db_race(fn, attempts=6):
    """Retry only PostgreSQL serialization/deadlock aborts; never mask other errors."""
    for attempt in range(attempts):
        try:
            return fn()
        except Exception as exc:
            if getattr(exc, "sqlstate", None) not in {"40001", "40P01"} or attempt + 1 == attempts:
                raise
            time.sleep(0.01 * (2 ** attempt))


def _epoch_provider():
    db = PostgresConnection(DSN)
    try:
        return int(db.execute("SELECT authority_epoch FROM authority_state WHERE id=1").fetchone()[0])
    finally:
        db.close()


def _token(authority, candidate, worker, epoch):
    signed = authority.issue_lease_token(candidate, worker, epoch, 30)
    return {"claims": signed["claims"], "signature_b64": base64.b64encode(signed["signature"]).decode()}


def test_postgres_policy_authority_engine_receiver_round_trip_and_fencing():
    suffix = uuid.uuid4().hex
    key = ed25519.Ed25519PrivateKey.generate()
    db = PostgresConnection(DSN)
    try:
        policy = DurablePolicyManager(db, require_authority=False)
        assert policy.atomic_reserve("candidate-" + suffix, "worker-" + suffix, 1)
        assert policy.assert_lease_valid("candidate-" + suffix, "worker-" + suffix, 1)

        engine = DurableEngine(db, "job-" + suffix)
        engine.transition(EngineState.PREPARING, "integration")
        engine.transition(EngineState.RUNNING, "integration")
        # Re-instantiation proves persisted state is recoverable after a process restart.
        assert DurableEngine(db, "job-" + suffix).state is EngineState.RUNNING

        authority = AuthorizationAuthority(db, key)
        # Exercise signed authorization consumption and the atomic fenced-write log.
        auth_token = authority.issue_lease_token("authorized-" + suffix, "authorized-worker-" + suffix, 1, 30)
        assert policy.atomic_reserve_authorized(auth_token, key.public_key()) is True
        db.execute("CREATE TABLE IF NOT EXISTS cro_fenced_test_effects (id TEXT PRIMARY KEY, value TEXT NOT NULL)")
        policy.assert_and_enforce_downstream_fence_atomic(
            "authorized-" + suffix, "authorized-worker-" + suffix, 1,
            lambda tx: tx.execute("INSERT INTO cro_fenced_test_effects(id,value) VALUES(?,?)", (suffix, "committed")),
        )
        authority.revoke_worker("authorized-worker-" + suffix, "integration append-only trigger check")

        receiver = IdempotentReceiver(DSN, key.public_key(), _epoch_provider)
        token = _token(authority, "receiver-" + suffix, "worker-" + suffix, 1)
        first = receiver.accept("idem-" + suffix, token, {"action": "test"})
        second = receiver.accept("idem-" + suffix, token, {"action": "test"})
        assert first == second and first["accepted"] is True

        high = _token(authority, "receiver-" + suffix, "worker-" + suffix, 2)
        receiver.accept("idem-high-" + suffix, high, {"action": "new-owner"})
        with pytest.raises(PermissionError, match="stale fencing epoch"):
            receiver.accept("idem-stale-" + suffix, token, {"action": "old-owner"})

        # A revoked authority epoch invalidates previously signed tokens.
        old_token = _token(authority, "revoked-" + suffix, "revoked-worker-" + suffix, 1)
        authority.revoke_worker("revoked-worker-" + suffix, "integration revocation")
        with pytest.raises(PermissionError, match="current authority epoch"):
            receiver.accept("idem-revoked-" + suffix, old_token, {"action": "must-not-run"})

        immutable_mutations = [
            ("UPDATE receiver_effects SET response_json=response_json WHERE idempotency_key=?", ("idem-" + suffix,)),
            ("DELETE FROM state_transition_log WHERE job_id=?", ("job-" + suffix,)),
            ("UPDATE reservation_history SET action=action WHERE candidate_id=?", ("authorized-" + suffix,)),
            ("DELETE FROM fenced_mutation_log WHERE candidate_id=?", ("authorized-" + suffix,)),
            ("UPDATE authority_audit SET detail=detail WHERE worker_id=?", ("authorized-worker-" + suffix,)),
            ("DELETE FROM revoked_workers WHERE worker_id=?", ("authorized-worker-" + suffix,)),
            ("UPDATE consumed_authority_tokens SET consumed_at=consumed_at WHERE nonce=?", (auth_token["claims"]["nonce"],)),
        ]
        for statement, params in immutable_mutations:
            with pytest.raises(Exception):
                db.execute(statement, params)
        protected_tables = [
            "reservation_history", "fenced_mutation_log", "authority_audit",
            "revoked_workers", "consumed_authority_tokens", "state_transition_log",
            "receiver_effects", "trusted_keys", "trusted_key_history", "verified_anchors",
        ]
        for table in protected_tables:
            for suffix_trigger in ("_no_update", "_no_delete"):
                trigger_name = table + suffix_trigger
                present = db.execute(
                    "SELECT EXISTS (SELECT 1 FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace WHERE t.tgname=? AND c.relname=? AND n.nspname=current_schema() AND NOT t.tgisinternal)",
                    (trigger_name, table),
                ).fetchone()[0]
                assert present, f"missing database append-only trigger {trigger_name}"
    finally:
        db.close()


def test_postgres_concurrent_lease_takeover_and_atomic_rollback_recovery():
    suffix = uuid.uuid4().hex
    candidate = "concurrent-" + suffix
    # Ensure core tables exist before racing independent connections.
    bootstrap = PostgresConnection(DSN)
    DurablePolicyManager(bootstrap, require_authority=False)
    bootstrap.execute("CREATE TABLE IF NOT EXISTS cro_test_mutations (id TEXT PRIMARY KEY, value TEXT NOT NULL)")
    bootstrap.close()

    barrier = threading.Barrier(2)
    outcomes = []
    errors = []
    lock = threading.Lock()

    def reserve(worker, epoch):
        conn = PostgresConnection(DSN)
        try:
            manager = DurablePolicyManager(conn, require_authority=False)
            barrier.wait(timeout=10)
            result = _retry_db_race(lambda: manager.atomic_reserve(candidate, worker, epoch))
            with lock: outcomes.append((worker, epoch, result))
        except BaseException as exc:
            with lock: errors.append(exc)
        finally:
            conn.close()

    threads = [
        threading.Thread(target=reserve, args=("worker-low-" + suffix, 1)),
        threading.Thread(target=reserve, args=("worker-high-" + suffix, 2)),
    ]
    for t in threads: t.start()
    for t in threads: t.join(timeout=20)
    assert all(not t.is_alive() for t in threads), "concurrent reservation deadlocked"
    assert not errors, repr(errors)

    check = PostgresConnection(DSN)
    try:
        row = check.execute("SELECT worker_id,epoch FROM reservations WHERE candidate_id=?", (candidate,)).fetchone()
        assert row == ("worker-high-" + suffix, 2)
        manager = DurablePolicyManager(check, require_authority=False)
        with pytest.raises(RuntimeError, match="transaction rolled back deliberately"):
            manager.assert_and_enforce_downstream_fence_atomic(
                candidate, "worker-high-" + suffix, 2,
                lambda tx: (tx.execute("INSERT INTO cro_test_mutations(id,value) VALUES(?,?)", (suffix, "uncommitted")),
                            (_ for _ in ()).throw(RuntimeError("transaction rolled back deliberately")))[1],
            )
        assert check.execute("SELECT 1 FROM cro_test_mutations WHERE id=?", (suffix,)).fetchone() is None
        assert check.execute("SELECT 1 FROM fenced_mutation_log WHERE candidate_id=? AND worker_id=? AND epoch=?", (candidate, "worker-high-" + suffix, 2)).fetchone() is None
        # New connection simulates process restart and confirms durable state survived rollback.
        recovered = PostgresConnection(DSN)
        try:
            assert DurablePolicyManager(recovered, require_authority=False).assert_lease_valid(candidate, "worker-high-" + suffix, 2)
        finally:
            recovered.close()
    finally:
        check.close()


def test_postgres_concurrent_duplicate_delivery_is_idempotent():
    suffix = uuid.uuid4().hex
    key = ed25519.Ed25519PrivateKey.generate()
    setup = PostgresConnection(DSN)
    try:
        authority = AuthorizationAuthority(setup, key)
        token = _token(authority, "dup-" + suffix, "worker-" + suffix, 1)
    finally:
        setup.close()
    receiver = IdempotentReceiver(DSN, key.public_key(), _epoch_provider)
    idem = "concurrent-idem-" + suffix
    payload = {"operation": "one-logical-effect", "value": 42}
    barrier = threading.Barrier(2)
    responses, errors = [], []
    lock = threading.Lock()

    def deliver():
        try:
            barrier.wait(timeout=10)
            result = _retry_db_race(lambda: receiver.accept(idem, token, payload))
            with lock: responses.append(result)
        except BaseException as exc:
            with lock: errors.append(exc)

    threads = [threading.Thread(target=deliver), threading.Thread(target=deliver)]
    for t in threads: t.start()
    for t in threads: t.join(timeout=20)
    assert all(not t.is_alive() for t in threads), "duplicate delivery deadlocked"
    assert not errors, repr(errors)
    assert len(responses) == 2 and responses[0] == responses[1]
    db = PostgresConnection(DSN)
    try:
        count = db.execute("SELECT count(*) FROM receiver_effects WHERE idempotency_key=?", (idem,)).fetchone()[0]
        assert count == 1
    finally:
        db.close()


def test_postgres_concurrent_signed_token_consumption_is_single_use():
    suffix = uuid.uuid4().hex
    key = ed25519.Ed25519PrivateKey.generate()
    authority_conn = PostgresConnection(DSN)
    try:
        authority = AuthorizationAuthority(authority_conn, key)
        signed = authority.issue_lease_token("single-use-" + suffix, "worker-" + suffix, 1, 30)
    finally:
        authority_conn.close()

    barrier = threading.Barrier(2)
    outcomes, errors = [], []
    lock = threading.Lock()

    def consume():
        conn = PostgresConnection(DSN)
        try:
            manager = DurablePolicyManager(conn, require_authority=True)
            barrier.wait(timeout=10)
            try:
                result = manager.atomic_reserve_authorized(signed, key.public_key())
                outcome = "accepted" if result else "not_reserved"
            except PermissionError:
                outcome = "rejected_replay"
            with lock: outcomes.append(outcome)
        except BaseException as exc:
            with lock: errors.append(exc)
        finally:
            conn.close()

    threads = [threading.Thread(target=consume), threading.Thread(target=consume)]
    for t in threads: t.start()
    for t in threads: t.join(timeout=20)
    assert all(not t.is_alive() for t in threads), "concurrent token consumption deadlocked"
    assert not errors, repr(errors)
    assert sorted(outcomes) == ["accepted", "rejected_replay"]


def test_postgres_trusted_key_history_and_checkpoint_anchor_round_trip():
    from cro.pilot import CheckpointMonitor
    from cro.trace_integrity import DurableKeyHistoryManager, canonical_serialize, sign_payload

    suffix = uuid.uuid4().hex
    root_key = ed25519.Ed25519PrivateKey.generate()
    new_key = ed25519.Ed25519PrivateKey.generate()
    db = PostgresConnection(DSN)
    try:
        keys = DurableKeyHistoryManager(db, "root-" + suffix, root_key.public_key())
        enrollment = {
            "admin_key_id": "root-" + suffix,
            "new_key_id": "worker-key-" + suffix,
            "new_pub_hex": new_key.public_key().public_bytes_raw().hex(),
        }
        signature = sign_payload(root_key, b"CRO_KEY_ENROLL_V1", enrollment)
        keys.add_trusted_key_authorized("root-" + suffix, signature, "worker-key-" + suffix, new_key.public_key())
        assert keys.get_public_key_bytes("worker-key-" + suffix) == new_key.public_key().public_bytes_raw()

        monitor = CheckpointMonitor(db, authority_public_key=root_key.public_key())
        anchor = {"anchor_hash": "anchor-" + suffix, "timestamp": time.time()}
        serialized = canonical_serialize(anchor)
        anchor_sig = root_key.sign(b"CRO_ANCHOR_VERIFY_V1" + len(serialized).to_bytes(8, "big") + serialized)
        monitor.record_cryptographically_verified_anchor(anchor, anchor_sig)
        assert monitor.get_latest_anchor_timestamp() == pytest.approx(anchor["timestamp"], abs=0.01)
        assert monitor.evaluate_checkpoint()["status"] == "PASS"

        with pytest.raises(Exception):
            db.execute("DELETE FROM trusted_keys WHERE key_id=?", ("root-" + suffix,))
        with pytest.raises(Exception):
            db.execute("UPDATE trusted_key_history SET action=action WHERE key_id=?", ("worker-key-" + suffix,))
        with pytest.raises(Exception):
            db.execute("UPDATE verified_anchors SET timestamp=timestamp WHERE anchor_hash=?", ("anchor-" + suffix,))
        with pytest.raises(Exception):
            db.execute("DELETE FROM verified_anchors WHERE anchor_hash=?", ("anchor-" + suffix,))
    finally:
        db.close()


def test_postgres_durable_store_backend_round_trip():
    from cro.durable_store import DurableStore

    suffix = uuid.uuid4().hex
    store = DurableStore(DSN, backend="postgresql")
    try:
        with store.atomic_transaction() as tx:
            tx.execute("INSERT INTO durable_outbox(id,payload,status) VALUES(?,?,?)", ("durable-" + suffix, "payload", "READY"))
        with store.atomic_transaction() as tx:
            row = tx.execute("SELECT payload,status FROM durable_outbox WHERE id=?", ("durable-" + suffix,)).fetchone()
            assert row == ("payload", "READY")
    finally:
        store.close()
