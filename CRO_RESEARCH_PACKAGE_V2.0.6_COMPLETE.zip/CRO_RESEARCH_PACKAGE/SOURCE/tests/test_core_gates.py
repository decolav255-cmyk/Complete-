import sqlite3
import time

import pytest
from cryptography.hazmat.primitives.asymmetric import ed25519

from cro.durable_store import DurableStore
from cro.engine import DurableEngine, EngineState
from cro.pilot import CheckpointMonitor
from cro.policy import AuthorizationAuthority, DurablePolicyManager
from cro.trace_integrity import (
    DOMAIN_EVENT, DOMAIN_DATASET, DOMAIN_PROTOCOL, DurableKeyHistoryManager,
    canonical_serialize, sign_payload, sign_release_manifest, verify_payload,
    verify_release_manifest,
)


def conn():
    return sqlite3.connect(":memory:", isolation_level=None)


def signed_message(domain, payload):
    raw = canonical_serialize(payload)
    return domain + len(raw).to_bytes(8, "big") + raw


# G1 — atomic lease reservation and strict fencing epochs

def test_g1_lease_renewal_and_epoch_takeover():
    db = conn()
    p = DurablePolicyManager(db, ttl_seconds=30, require_authority=False)
    assert p.atomic_reserve("candidate", "worker-A", 1)
    assert p.atomic_reserve("candidate", "worker-A", 1)  # same-worker renewal
    assert not p.atomic_reserve("candidate", "worker-B", 1)
    assert p.atomic_reserve("candidate", "worker-B", 2)
    assert not p.atomic_reserve("candidate", "worker-A", 1)
    assert p.assert_lease_valid("candidate", "worker-B", 2)


def test_g1_expired_lease_cannot_be_resurrected_at_same_epoch(monkeypatch):
    db = conn()
    p = DurablePolicyManager(db, ttl_seconds=1, require_authority=False)
    base = time.time()
    monkeypatch.setattr("cro.policy.time.time", lambda: base)
    assert p.atomic_reserve("c", "w", 7)
    monkeypatch.setattr("cro.policy.time.time", lambda: base + 2)
    assert not p.atomic_reserve("c", "w", 7)
    assert p.atomic_reserve("c", "w2", 8)


# G4 — fence check and protected database mutation share one transaction

def test_g4_mutation_is_atomic_with_fence_and_stale_worker_has_no_side_effect():
    db = conn()
    p = DurablePolicyManager(db, require_authority=False)
    db.execute("CREATE TABLE effects (value TEXT)")
    assert p.atomic_reserve("c", "worker-A", 1)
    p.assert_and_enforce_downstream_fence_atomic(
        "c", "worker-A", 1,
        lambda tx: tx.execute("INSERT INTO effects VALUES('authorized')"),
    )
    assert db.execute("SELECT value FROM effects").fetchall() == [("authorized",)]
    assert p.atomic_reserve("c", "worker-B", 2)
    with pytest.raises(RuntimeError, match="FENCE VIOLATION"):
        p.assert_and_enforce_downstream_fence_atomic(
            "c", "worker-A", 1,
            lambda tx: tx.execute("INSERT INTO effects VALUES('stale')"),
        )
    assert db.execute("SELECT value FROM effects").fetchall() == [("authorized",)]


def test_g4_mutation_exception_rolls_back_side_effect():
    db = conn()
    p = DurablePolicyManager(db, require_authority=False)
    db.execute("CREATE TABLE effects (value TEXT)")
    p.atomic_reserve("c", "w", 1)

    def fail(tx):
        tx.execute("INSERT INTO effects VALUES('partial')")
        raise ValueError("abort")

    with pytest.raises(ValueError, match="abort"):
        p.assert_and_enforce_downstream_fence_atomic("c", "w", 1, fail)
    assert db.execute("SELECT * FROM effects").fetchall() == []


# G2 — canonical encoding and durable, authorized key enrollment

def test_g2_canonical_serialization_is_deterministic_and_strict():
    assert canonical_serialize({"b": 2, "a": [1, True]}) == b'{"a":[1,true],"b":2}'
    with pytest.raises(TypeError, match="non-string"):
        canonical_serialize({1: "bad"})
    with pytest.raises(ValueError, match="non-finite"):
        canonical_serialize({"x": float("nan")})
    with pytest.raises(TypeError, match="unsupported"):
        canonical_serialize({"x": object()})


def test_g2_root_key_enrollment_signature_and_history_survive_restart():
    db = conn()
    root = ed25519.Ed25519PrivateKey.generate()
    child = ed25519.Ed25519PrivateKey.generate()
    manager = DurableKeyHistoryManager(db, "root", root.public_key())
    child_raw = child.public_key().public_bytes_raw()
    payload = {"admin_key_id": "root", "new_key_id": "child", "new_pub_hex": child_raw.hex()}
    sig = root.sign(signed_message(b"CRO_KEY_ENROLL_V1", payload))
    manager.add_trusted_key_authorized("root", sig, "child", child.public_key())
    event = {"event_id": "e-1", "value": 3}
    event_sig = child.sign(signed_message(DOMAIN_EVENT, event))
    assert manager.verify_signature("child", DOMAIN_EVENT, event, event_sig)
    assert not manager.verify_signature("child", DOMAIN_EVENT, {"event_id": "e-1", "value": 4}, event_sig)
    assert db.execute("SELECT COUNT(*) FROM trusted_key_history").fetchone()[0] == 2
    again = DurableKeyHistoryManager(db, "root", root.public_key())
    assert again.get_public_key_bytes("child") == child_raw


def test_g2_unauthorized_or_duplicate_key_enrollment_rejected():
    db = conn()
    root = ed25519.Ed25519PrivateKey.generate()
    other = ed25519.Ed25519PrivateKey.generate()
    manager = DurableKeyHistoryManager(db, "root", root.public_key())
    child = ed25519.Ed25519PrivateKey.generate()
    with pytest.raises(PermissionError):
        manager.add_trusted_key_authorized("unknown", b"bad", "child", child.public_key())
    with pytest.raises(PermissionError):
        manager.add_trusted_key_authorized("root", b"bad", "child", child.public_key())
    payload = {"admin_key_id": "root", "new_key_id": "child", "new_pub_hex": child.public_key().public_bytes_raw().hex()}
    sig = root.sign(signed_message(b"CRO_KEY_ENROLL_V1", payload))
    manager.add_trusted_key_authorized("root", sig, "child", child.public_key())
    with pytest.raises(ValueError, match="collision"):
        manager.add_trusted_key_authorized("root", sig, "child", other.public_key())


# G3 — durable, serialized lifecycle transitions

def test_g3_transitions_are_persisted_and_terminal_states_are_immutable():
    db = conn()
    engine = DurableEngine(db, "job-1")
    engine.transition(EngineState.PREPARING, "validated")
    engine.transition(EngineState.RUNNING, "started")
    engine.transition(EngineState.AUDIT_COMMITTED, "audit committed")
    engine.transition(EngineState.DECISION_RELEASED, "released")
    restarted = DurableEngine(db, "job-1")
    assert restarted.state is EngineState.DECISION_RELEASED
    assert db.execute("SELECT COUNT(*) FROM state_transition_log WHERE job_id='job-1'").fetchone()[0] == 4
    with pytest.raises(RuntimeError, match="invalid lifecycle"):
        restarted.transition(EngineState.RUNNING)


def test_g3_invalid_transition_does_not_write_log_or_state():
    db = conn()
    engine = DurableEngine(db, "job-2")
    with pytest.raises(RuntimeError):
        engine.transition(EngineState.COMPLETED)
    assert engine.state is EngineState.INIT
    assert db.execute("SELECT COUNT(*) FROM state_transition_log").fetchone()[0] == 0


# G5 — SQLite WAL transaction behavior and PostgreSQL backend selection

def test_g5_memory_store_persists_and_rolls_back():
    store = DurableStore(":memory:")
    with store.atomic_transaction() as tx:
        tx.execute("INSERT INTO durable_outbox VALUES('1','payload','READY')")
    assert store._conn.execute("SELECT payload FROM durable_outbox WHERE id='1'").fetchone() == ("payload",)
    with pytest.raises(ValueError):
        with store.atomic_transaction() as tx:
            tx.execute("INSERT INTO durable_outbox VALUES('2','bad','READY')")
            raise ValueError("rollback")
    assert store._conn.execute("SELECT COUNT(*) FROM durable_outbox").fetchone()[0] == 1
    store.close()


def test_g5_file_store_uses_wal_and_postgres_requires_a_real_dsn(tmp_path):
    store = DurableStore(str(tmp_path / "cro.db"))
    assert store._conn.execute("PRAGMA journal_mode").fetchone()[0].lower() == "wal"
    store.close()
    with pytest.raises(ValueError, match="requires a PostgreSQL DSN"):
        DurableStore(":memory:", backend="postgresql")


# G6 — signed anchors and persistent clock rollback watermark

def test_g6_valid_anchor_is_persisted_and_checkpoint_passes(monkeypatch):
    db = conn()
    private = ed25519.Ed25519PrivateKey.generate()
    now = time.time()
    monkeypatch.setattr("cro.pilot.time.time", lambda: now)
    monitor = CheckpointMonitor(db, private.public_key(), max_unanchored_seconds=300)
    payload = {"anchor_hash": "sha256:abc", "timestamp": now, "sequence": 1}
    sig = private.sign(signed_message(b"CRO_ANCHOR_VERIFY_V1", payload))
    monitor.record_cryptographically_verified_anchor(payload, sig)
    assert monitor.get_latest_anchor_timestamp() == now
    assert monitor.evaluate_checkpoint()["status"] == "PASS"


def test_g6_invalid_signature_and_conflicting_duplicate_are_rejected(monkeypatch):
    db = conn()
    private = ed25519.Ed25519PrivateKey.generate()
    now = time.time()
    monkeypatch.setattr("cro.pilot.time.time", lambda: now)
    monitor = CheckpointMonitor(db, private.public_key())
    payload = {"anchor_hash": "hash-1", "timestamp": now}
    with pytest.raises(ValueError, match="signature"):
        monitor.record_cryptographically_verified_anchor(payload, b"invalid")
    sig = private.sign(signed_message(b"CRO_ANCHOR_VERIFY_V1", payload))
    monitor.record_cryptographically_verified_anchor(payload, sig)
    conflicting = {"anchor_hash": "hash-1", "timestamp": now - 1}
    bad_sig = private.sign(signed_message(b"CRO_ANCHOR_VERIFY_V1", conflicting))
    with pytest.raises(ValueError, match="conflicting"):
        monitor.record_cryptographically_verified_anchor(conflicting, bad_sig)


def test_g6_clock_rollback_detected_after_restart(monkeypatch):
    db = conn()
    monkeypatch.setattr("cro.pilot.time.time", lambda: 10_000.0)
    CheckpointMonitor(db)
    monkeypatch.setattr("cro.pilot.time.time", lambda: 9_000.0)
    with pytest.raises(RuntimeError, match="clock rollback"):
        CheckpointMonitor(db)


def test_g1_concurrent_equal_epoch_claims_have_exactly_one_winner(tmp_path):
    import threading
    from concurrent.futures import ThreadPoolExecutor

    path = str(tmp_path / "leases.sqlite")
    DurablePolicyManager(sqlite3.connect(path, isolation_level=None), require_authority=False)
    barrier = threading.Barrier(2)

    def claim(worker):
        local = sqlite3.connect(path, timeout=10, isolation_level=None)
        manager = DurablePolicyManager(local, require_authority=False)
        barrier.wait()
        result = manager.atomic_reserve("shared", worker, 5)
        local.close()
        return result

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(claim, ["worker-1", "worker-2"]))
    assert sorted(results) == [False, True]


def test_g3_two_engine_instances_cannot_commit_the_same_stale_transition():
    db = conn()
    first = DurableEngine(db, "shared-job")
    second = DurableEngine(db, "shared-job")
    first.transition(EngineState.PREPARING)
    second.transition(EngineState.RUNNING)
    with pytest.raises(RuntimeError, match="invalid lifecycle"):
        first.transition(EngineState.RUNNING)
    assert DurableEngine(db, "shared-job").state is EngineState.RUNNING
    assert db.execute("SELECT COUNT(*) FROM state_transition_log").fetchone()[0] == 2


def test_g1_and_g4_successful_actions_are_recorded_in_append_only_audit_logs():
    db = conn()
    policy = DurablePolicyManager(db, require_authority=False)
    assert policy.atomic_reserve("audit-candidate", "worker", 4)
    db.execute("CREATE TABLE protected_rows (value TEXT)")
    policy.assert_and_enforce_downstream_fence_atomic(
        "audit-candidate", "worker", 4,
        lambda tx: tx.execute("INSERT INTO protected_rows VALUES('committed')"),
    )
    assert db.execute("SELECT action FROM reservation_history").fetchall() == [("RESERVED",)]
    assert db.execute("SELECT COUNT(*) FROM fenced_mutation_log").fetchone()[0] == 1
    with pytest.raises(sqlite3.IntegrityError, match="append-only"):
        db.execute("DELETE FROM reservation_history")
    with pytest.raises(sqlite3.IntegrityError, match="append-only"):
        db.execute("DELETE FROM fenced_mutation_log")


def test_g2_key_records_and_history_are_append_only():
    db = conn()
    root = ed25519.Ed25519PrivateKey.generate()
    manager = DurableKeyHistoryManager(db, "root", root.public_key())
    with pytest.raises(sqlite3.IntegrityError, match="immutable"):
        db.execute("DELETE FROM trusted_keys WHERE key_id='root'")
    with pytest.raises(sqlite3.IntegrityError, match="append-only"):
        db.execute("DELETE FROM trusted_key_history")


def test_g3_transition_log_is_append_only():
    db = conn()
    engine = DurableEngine(db, "append-job")
    engine.transition(EngineState.PREPARING)
    with pytest.raises(sqlite3.IntegrityError, match="append-only"):
        db.execute("DELETE FROM state_transition_log")


def test_g6_verified_anchor_history_is_append_only(monkeypatch):
    db = conn()
    private = ed25519.Ed25519PrivateKey.generate()
    now = time.time()
    monkeypatch.setattr("cro.pilot.time.time", lambda: now)
    monitor = CheckpointMonitor(db, private.public_key())
    payload = {"anchor_hash": "append-only-anchor", "timestamp": now}
    sig = private.sign(signed_message(b"CRO_ANCHOR_VERIFY_V1", payload))
    monitor.record_cryptographically_verified_anchor(payload, sig)
    with pytest.raises(sqlite3.IntegrityError, match="append-only"):
        db.execute("DELETE FROM verified_anchors")


def test_g1_authority_signed_single_use_lease_token_and_revocation():
    db = conn()
    policy = DurablePolicyManager(db)  # authority required by default
    signing_key = ed25519.Ed25519PrivateKey.generate()
    authority = AuthorizationAuthority(db, signing_key)
    with pytest.raises(PermissionError, match="authority-signed"):
        policy.atomic_reserve("c", "worker", 1)
    with pytest.raises(ValueError, match="60 seconds"):
        authority.issue_lease_token("c", "worker", 1, ttl_seconds=61)
    token = authority.issue_lease_token("c", "worker", 1, ttl_seconds=30)
    assert policy.atomic_reserve_authorized(token, signing_key.public_key())
    with pytest.raises(PermissionError, match="consumed"):
        policy.atomic_reserve_authorized(token, signing_key.public_key())
    authority.revoke_worker("worker", "operator revocation")
    with pytest.raises(RuntimeError, match="revoked"):
        policy.assert_and_enforce_downstream_fence_atomic(
            "c", "worker", 1, lambda tx: tx.execute("SELECT 1")
        )
    with pytest.raises(PermissionError, match="revoked"):
        authority.issue_lease_token("c", "worker", 2)


def test_g1_revocation_invalidates_previously_issued_authority_token():
    db = conn()
    policy = DurablePolicyManager(db)
    signing_key = ed25519.Ed25519PrivateKey.generate()
    authority = AuthorizationAuthority(db, signing_key)
    token = authority.issue_lease_token("c", "worker", 1)
    authority.revoke_worker("worker", "revoked before reservation")
    with pytest.raises(PermissionError, match="invalidated|revoked"):
        policy.atomic_reserve_authorized(token, signing_key.public_key())


def test_g2_domain_separation_and_signed_release_manifest_bind_actual_file_bytes():
    key = ed25519.Ed25519PrivateKey.generate()
    payload = {"dataset_sha256": "a" * 64, "protocol_sha256": "b" * 64}
    dataset_sig = sign_payload(key, DOMAIN_DATASET, payload)
    assert verify_payload(key.public_key(), DOMAIN_DATASET, payload, dataset_sig)
    assert not verify_payload(key.public_key(), DOMAIN_PROTOCOL, payload, dataset_sig)
    content = b"release artifact bytes"
    manifest = {"release": "test", "files": {"artifact.bin": __import__("hashlib").sha256(content).hexdigest()}}
    signed = sign_release_manifest(manifest, key)
    assert verify_release_manifest(signed, key.public_key(), {"artifact.bin": content})
    assert not verify_release_manifest(signed, key.public_key(), {"artifact.bin": b"tampered"})
    altered = {"manifest": {**manifest, "release": "tampered"}, "signature": signed["signature"]}
    assert not verify_release_manifest(altered, key.public_key())


def test_g3_state_and_transition_log_commit_or_rollback_together():
    db = conn()
    engine = DurableEngine(db, "atomic-job")
    db.execute("CREATE TRIGGER fail_transition_log BEFORE INSERT ON state_transition_log BEGIN SELECT RAISE(ABORT,'injected log failure'); END")
    with pytest.raises(sqlite3.IntegrityError, match="injected"):
        engine.transition(EngineState.PREPARING)
    assert engine.state is EngineState.INIT
    assert db.execute("SELECT COUNT(*) FROM engine_states").fetchone()[0] == 0
    assert db.execute("SELECT COUNT(*) FROM state_transition_log").fetchone()[0] == 0


def test_g1_authorized_lease_expiry_never_exceeds_signed_token_expiry(monkeypatch):
    db = conn()
    policy = DurablePolicyManager(db)
    signing_key = ed25519.Ed25519PrivateKey.generate()
    authority = AuthorizationAuthority(db, signing_key)
    base = time.time()
    monkeypatch.setattr("cro.policy.time.time", lambda: base)
    token = authority.issue_lease_token("c", "worker", 1, ttl_seconds=5)
    assert policy.atomic_reserve_authorized(token, signing_key.public_key())
    expiry = db.execute("SELECT expires_at FROM reservations WHERE candidate_id='c'").fetchone()[0]
    assert expiry <= token["claims"]["expires_at"]
    assert expiry <= base + 5


def test_g1_revocation_and_consumed_token_records_are_immutable():
    db = conn()
    policy = DurablePolicyManager(db)
    signing_key = ed25519.Ed25519PrivateKey.generate()
    authority = AuthorizationAuthority(db, signing_key)
    authority.revoke_worker("worker", "security event")
    with pytest.raises(sqlite3.IntegrityError, match="immutable"):
        db.execute("DELETE FROM revoked_workers WHERE worker_id='worker'")
    with pytest.raises(PermissionError, match="revoked"):
        authority.issue_lease_token("c", "worker", 1)


def test_g1_authorization_and_revocation_race_is_serialized(tmp_path):
    import threading
    from concurrent.futures import ThreadPoolExecutor

    path = str(tmp_path / "authority-race.sqlite")
    authority_db = sqlite3.connect(path, timeout=10, check_same_thread=False, isolation_level=None)
    policy_db = sqlite3.connect(path, timeout=10, check_same_thread=False, isolation_level=None)
    policy = DurablePolicyManager(policy_db)
    signing_key = ed25519.Ed25519PrivateKey.generate()
    authority = AuthorizationAuthority(authority_db, signing_key)
    token = authority.issue_lease_token("race-candidate", "race-worker", 1)
    barrier = threading.Barrier(2)

    def reserve():
        barrier.wait()
        try:
            return policy.atomic_reserve_authorized(token, signing_key.public_key())
        except PermissionError:
            return False

    def revoke():
        barrier.wait()
        authority.revoke_worker("race-worker", "concurrent revocation")
        return True

    with ThreadPoolExecutor(max_workers=2) as pool:
        reserve_future = pool.submit(reserve)
        revoke_future = pool.submit(revoke)
        reserve_future.result(timeout=10)
        revoke_future.result(timeout=10)
    assert policy_db.execute("SELECT 1 FROM revoked_workers WHERE worker_id='race-worker'").fetchone()
    with pytest.raises(RuntimeError, match="no reservation|revoked|expired"):
        policy.assert_and_enforce_downstream_fence_atomic(
            "race-candidate", "race-worker", 1, lambda tx: tx.execute("SELECT 1")
        )
    authority_db.close()
    policy_db.close()


def test_g4_fenced_mutation_and_epoch_takeover_serialize(tmp_path):
    import threading
    from concurrent.futures import ThreadPoolExecutor

    path = str(tmp_path / "fence-race.sqlite")
    db1 = sqlite3.connect(path, timeout=10, check_same_thread=False, isolation_level=None)
    db2 = sqlite3.connect(path, timeout=10, check_same_thread=False, isolation_level=None)
    p1 = DurablePolicyManager(db1, require_authority=False)
    p2 = DurablePolicyManager(db2, require_authority=False)
    db1.execute("CREATE TABLE IF NOT EXISTS effects (value TEXT)")
    assert p1.atomic_reserve("c", "worker-A", 1)
    mutation_started = threading.Event()
    allow_commit = threading.Event()
    takeover_started = threading.Event()

    def old_worker_write():
        def mutation(tx):
            tx.execute("INSERT INTO effects VALUES('before-takeover')")
            mutation_started.set()
            assert allow_commit.wait(5)
            return "committed"
        return p1.assert_and_enforce_downstream_fence_atomic("c", "worker-A", 1, mutation)

    def new_worker_takeover():
        assert mutation_started.wait(5)
        takeover_started.set()
        return p2.atomic_reserve("c", "worker-B", 2)

    with ThreadPoolExecutor(max_workers=2) as pool:
        old_future = pool.submit(old_worker_write)
        assert mutation_started.wait(5)
        new_future = pool.submit(new_worker_takeover)
        assert takeover_started.wait(5)
        time.sleep(0.05)  # allow the new writer to block on the open transaction
        allow_commit.set()
        assert old_future.result(timeout=10) == "committed"
        assert new_future.result(timeout=10) is True

    with pytest.raises(RuntimeError, match="stale holder"):
        p1.assert_and_enforce_downstream_fence_atomic(
            "c", "worker-A", 1,
            lambda tx: tx.execute("INSERT INTO effects VALUES('after-takeover')"),
        )
    assert db1.execute("SELECT value FROM effects").fetchall() == [("before-takeover",)]
    db1.close()
    db2.close()


def test_g3_state_machine_survives_database_close_and_reopen(tmp_path):
    path = str(tmp_path / "engine-restart.sqlite")
    first_db = sqlite3.connect(path, isolation_level=None)
    first = DurableEngine(first_db, "durable-job")
    first.transition(EngineState.PREPARING)
    first.transition(EngineState.RUNNING)
    first_db.close()
    second_db = sqlite3.connect(path, isolation_level=None)
    restarted = DurableEngine(second_db, "durable-job")
    assert restarted.state is EngineState.RUNNING
    restarted.transition(EngineState.RECOVERY_PENDING, "restart recovery path")
    assert DurableEngine(second_db, "durable-job").state is EngineState.RECOVERY_PENDING
    second_db.close()


def test_g6_clock_watermark_survives_database_close_and_reopen(tmp_path, monkeypatch):
    path = str(tmp_path / "anchor-clock.sqlite")
    first_db = sqlite3.connect(path, isolation_level=None)
    monkeypatch.setattr("cro.pilot.time.time", lambda: 50_000.0)
    CheckpointMonitor(first_db)
    first_db.close()
    second_db = sqlite3.connect(path, isolation_level=None)
    monkeypatch.setattr("cro.pilot.time.time", lambda: 49_000.0)
    with pytest.raises(RuntimeError, match="clock rollback"):
        CheckpointMonitor(second_db)
    second_db.close()


def test_g1_lease_and_fencing_state_survive_database_restart(tmp_path):
    path = str(tmp_path / "lease-restart.sqlite")
    first_db = sqlite3.connect(path, isolation_level=None)
    first = DurablePolicyManager(first_db, require_authority=False)
    assert first.atomic_reserve("persistent-candidate", "worker", 9)
    first_db.close()
    second_db = sqlite3.connect(path, isolation_level=None)
    second = DurablePolicyManager(second_db, require_authority=False)
    assert second.assert_lease_valid("persistent-candidate", "worker", 9)
    assert second.atomic_reserve("persistent-candidate", "new-worker", 10)
    with pytest.raises(RuntimeError, match="stale"):
        second.assert_and_enforce_downstream_fence_atomic(
            "persistent-candidate", "worker", 9, lambda tx: tx.execute("SELECT 1")
        )
    second_db.close()


def test_g2_trusted_key_history_survives_database_restart(tmp_path):
    path = str(tmp_path / "key-history.sqlite")
    root = ed25519.Ed25519PrivateKey.generate()
    child = ed25519.Ed25519PrivateKey.generate()
    first_db = sqlite3.connect(path, isolation_level=None)
    manager = DurableKeyHistoryManager(first_db, "root", root.public_key())
    raw = child.public_key().public_bytes_raw()
    payload = {"admin_key_id": "root", "new_key_id": "child", "new_pub_hex": raw.hex()}
    manager.add_trusted_key_authorized("root", root.sign(signed_message(b"CRO_KEY_ENROLL_V1", payload)), "child", child.public_key())
    first_db.close()
    second_db = sqlite3.connect(path, isolation_level=None)
    restarted = DurableKeyHistoryManager(second_db, "root", root.public_key())
    assert restarted.get_public_key_bytes("child") == raw
    assert second_db.execute("SELECT COUNT(*) FROM trusted_key_history").fetchone()[0] == 2
    second_db.close()


def test_g5_file_outbox_rows_survive_store_close_and_reopen(tmp_path):
    path = str(tmp_path / "durable-outbox.sqlite")
    first = DurableStore(path)
    with first.atomic_transaction() as tx:
        tx.execute("INSERT INTO durable_outbox VALUES('event-1','payload','PENDING')")
    first.close()
    second = DurableStore(path)
    assert second._conn.execute("SELECT payload,status FROM durable_outbox WHERE id='event-1'").fetchone() == ("payload", "PENDING")
    second.close()


def test_g6_verified_anchor_history_survives_database_restart(tmp_path, monkeypatch):
    path = str(tmp_path / "verified-anchor-restart.sqlite")
    private = ed25519.Ed25519PrivateKey.generate()
    now = time.time()
    monkeypatch.setattr("cro.pilot.time.time", lambda: now)
    first_db = sqlite3.connect(path, isolation_level=None)
    first = CheckpointMonitor(first_db, private.public_key(), max_unanchored_seconds=300)
    payload = {"anchor_hash": "persisted-anchor", "timestamp": now}
    first.record_cryptographically_verified_anchor(payload, private.sign(signed_message(b"CRO_ANCHOR_VERIFY_V1", payload)))
    first_db.close()
    second_db = sqlite3.connect(path, isolation_level=None)
    second = CheckpointMonitor(second_db, private.public_key(), max_unanchored_seconds=300)
    assert second.get_latest_anchor_timestamp() == now
    assert second.evaluate_checkpoint()["status"] == "PASS"
    second_db.close()
