"""Driver-independent tests for PostgreSQL transaction/retry contract."""
import sys
import types
import pytest


class FakePgError(Exception):
    def __init__(self, sqlstate):
        super().__init__(sqlstate); self.sqlstate = sqlstate

class FakeCursor:
    def __init__(self): self.statements = []
    def __enter__(self): return self
    def __exit__(self, *args): return False
    def execute(self, sql, params=()): self.statements.append((sql, params))
    def fetchone(self): return None
    def fetchall(self): return []

class FakeTransaction:
    def __init__(self, conn): self.conn = conn
    def __enter__(self): self.conn.tx_count += 1; return self
    def __exit__(self, typ, value, tb):
        if typ: self.conn.rollbacks += 1
        else: self.conn.commits += 1
        return False

class FakeConnection:
    def __init__(self):
        self.autocommit = False; self.tx_count = 0; self.commits = 0; self.rollbacks = 0
        self.cursors = []; self.closed = False
    def cursor(self):
        c = FakeCursor(); self.cursors.append(c); return c
    def transaction(self): return FakeTransaction(self)
    def close(self): self.closed = True

@pytest.fixture
def fake_pg(monkeypatch):
    state = {"conn": FakeConnection(), "connect_args": None}
    def connect(*args, **kwargs): state["connect_args"] = (args, kwargs); return state["conn"]
    mod = types.SimpleNamespace(connect=connect, Error=FakePgError)
    monkeypatch.setitem(sys.modules, "psycopg", mod)
    return state

def test_store_initializes_schema_and_serializable_transaction(fake_pg):
    from cro.postgres_store import PostgresDurableStore
    store = PostgresDurableStore("postgresql://test")
    assert fake_pg["connect_args"][1]["autocommit"] is True
    with store.atomic_transaction() as tx:
        tx.execute("INSERT INTO durable_outbox(id,payload,status) VALUES(?,?,?)", ("a", "b", "READY"))
    statements = [s for c in fake_pg["conn"].cursors for s, _ in c.statements]
    assert any("SERIALIZABLE" in s for s in statements)
    assert fake_pg["conn"].commits == 1

def test_run_serializable_retries_only_retryable_sqlstates(fake_pg, monkeypatch):
    from cro.postgres_store import PostgresDurableStore
    monkeypatch.setattr("cro.postgres_store.time.sleep", lambda _: None)
    store = PostgresDurableStore("postgresql://test")
    calls = {"n": 0}
    def op(tx):
        calls["n"] += 1
        if calls["n"] < 3: raise FakePgError("40001")
        return "committed"
    assert store.run_serializable(op) == "committed"
    assert calls["n"] == 3
    assert fake_pg["conn"].rollbacks == 2
    assert fake_pg["conn"].commits == 1

def test_run_serializable_does_not_retry_non_retryable_errors(fake_pg):
    from cro.postgres_store import PostgresDurableStore
    store = PostgresDurableStore("postgresql://test")
    calls = {"n": 0}
    def op(tx):
        calls["n"] += 1
        raise FakePgError("23505")
    with pytest.raises(FakePgError):
        store.run_serializable(op)
    assert calls["n"] == 1
    assert fake_pg["conn"].rollbacks == 1

@pytest.mark.integration
def test_live_postgresql_serializable_round_trip():
    """Opt-in live test: set CRO_TEST_POSTGRES_DSN to a disposable database."""
    import os
    dsn = os.environ.get("CRO_TEST_POSTGRES_DSN")
    if not dsn:
        pytest.skip("CRO_TEST_POSTGRES_DSN not configured")
    pytest.importorskip("psycopg")
    from cro.postgres_store import PostgresDurableStore
    store = PostgresDurableStore(dsn)
    try:
        key = "integration-test-" + __import__("uuid").uuid4().hex
        store.run_serializable(lambda tx: tx.execute(
            "INSERT INTO durable_outbox(id,payload,status) VALUES(?,?,?)",
            (key, "integration-payload", "TEST")
        ))
        with store.atomic_transaction() as tx:
            row = tx.execute("SELECT payload,status FROM durable_outbox WHERE id=?", (key,)).fetchone()
            assert row == ("integration-payload", "TEST")
            tx.execute("DELETE FROM durable_outbox WHERE id=?", (key,))
    finally:
        store.close()
