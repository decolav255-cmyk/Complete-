"""Revision 22 regression suite reconstructed from the user's supplied bundle.
The test purposes and independent checks are retained; see R23_STATUS.md."""
import copy, math, unittest
from fractions import Fraction
from itertools import combinations
from unittest.mock import patch
import numpy as np
from cro.pooled_screen import RobustPooledScreenEngine

MECH = {'mechanism': 'complete_cluster_randomization_within_strata'}

def sample(nc=6, per=2, seed=42):
    rng=np.random.default_rng(seed); c=np.repeat(np.arange(nc),per); n=len(c)
    ct=np.array(([0,1]*((nc+1)//2))[:nc],float); t=ct[c]
    m=rng.normal(size=n); y=.5*t+.7*m+.3*t*m+rng.normal(0,.2,n)
    return y,t,m,c

class TestR22(unittest.TestCase):
    def test_1_family_state_preservation_and_delimiters(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=3); e.construct_family(['a'],['m'],['r'])
        with self.assertRaises(ValueError): e.construct_family(['x','x'],['m'],['r'])
        self.assertEqual(len(e.family_hypotheses_),1)
        e.construct_family(['a__1'],['m::2'],['r--3'])
        self.assertEqual(e.family_hypotheses_[0]['tuple_id'],('a__1','m::2','r--3'))
    def test_2_single_cluster_rejection_and_state_clear(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=1); rng=np.random.default_rng(1)
        y=rng.normal(size=10); t=np.ones(10); m=rng.normal(size=10); c=np.zeros(10)
        with self.assertRaises(ValueError): e.compute_cluster_robust_stat(y,t,m,c)
        *_,abst,reason=e.cluster_permutation_test(y,t,m,c,assignment_config=MECH)
        self.assertTrue(abst); self.assertIn('G=1 is insufficient',reason)
        self.assertEqual(e.last_observed_cr1_model_fit_,{})
    def test_3_observation_and_cluster_strata_equivalence(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=2); y,t,m,c=sample(3,2)
        so=np.array(['a','a','b','b','b','b']); sg=np.array(['a','b','b'])
        r1=e.cluster_permutation_test(y,t,m,c,assignment_config={**MECH,'strata':so})
        r2=e.cluster_permutation_test(y,t,m,c,assignment_config={**MECH,'strata':sg})
        self.assertFalse(r1[2],r1[3]); self.assertFalse(r2[2],r2[3])
        self.assertAlmostEqual(r1[0],r2[0],places=10); self.assertAlmostEqual(r1[1],r2[1],places=10)
    def test_4_exact_enumeration_diagnostics(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=2,exact_enumeration_threshold=50)
        y,t,m,c=sample(4,2); t=np.array([0,0,1,1,0,0,1,1.]); cfg={**MECH,'strata':[1,1,2,2]}
        r=e.cluster_permutation_test(y,t,m,c,assignment_config=cfg); self.assertFalse(r[2],r[3])
        d=e.last_permutation_diagnostics_; self.assertEqual(d['evaluation_mode'],'exact_enumeration')
        self.assertEqual(d['theoretical_allocation_space_size'],4); self.assertEqual(d['total_evaluations'],4)
        self.assertFalse(d['plus_one_correction_applied'])
    def test_5_large_space_lazy_mc_and_stratum_counts(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=5,exact_enumeration_threshold=50,n_permutations=40,random_state=42)
        y,t,m,c=sample(12,3); sc=np.repeat([0,1,2],4); cfg={**MECH,'strata':sc}
        cap=[]; real=e.compute_cluster_robust_stat
        def spy(y0,t0,m0,c0): cap.append(np.array(t0).copy()); return real(y0,t0,m0,c0)
        with patch.object(e,'compute_cluster_robust_stat',side_effect=spy): r=e.cluster_permutation_test(y,t,m,c,assignment_config=cfg)
        self.assertFalse(r[2],r[3]); d=e.last_permutation_diagnostics_
        self.assertEqual(d['evaluation_mode'],'monte_carlo'); self.assertEqual(d['total_evaluations'],40)
        self.assertEqual(len(cap),41); np.testing.assert_array_equal(cap[0],t)
        for v in cap[1:]:
            for cl in np.unique(c): self.assertEqual(len(np.unique(v[c==cl])),1)
            for s in range(3): self.assertEqual(sum(v[c==cl][0] for cl in np.unique(c)[sc==s]),d['expected_stratum_treated_counts'][s])
    def test_6_cluster_identifier_type_validation(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=2); y,t,m,c=sample(4,2)
        bad=[10,10,'10','10',1,1,'01','01']; r=e.cluster_permutation_test(y,t,m,bad,assignment_config=MECH)
        self.assertTrue(r[2]); self.assertIn('Mixed cluster identifier types',r[3])
        good=['c10','c10','c2','c2','c1','c1','c3','c3']; r=e.cluster_permutation_test(y,t,m,good,assignment_config=MECH)
        self.assertFalse(r[2],r[3])
    def test_7_caller_config_deep_immutability(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=2,n_permutations=10); y,t,m,c=sample(4,2)
        cfg={**MECH,'strata':np.ones(len(c)),'nested':{'note':['a','b']}}; old=copy.deepcopy(cfg)
        e.cluster_permutation_test(y,t,m,c,assignment_config=cfg)
        self.assertEqual(cfg['nested'],old['nested']); np.testing.assert_array_equal(cfg['strata'],old['strata'])
    def test_8_independent_full_cr1_covariance(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=2); y,t,m,c=sample(5,6)
        X=np.column_stack([np.ones(len(t)),t,m,t*m]); k=X.shape[1]; inv=np.linalg.inv(X.T@X)
        b=inv@X.T@y; r=y-X@b; meat=np.zeros((k,k))
        for cl in np.unique(c):
            ix=c==cl; s=X[ix].T@r[ix]; meat+=np.outer(s,s)
        adj=(len(np.unique(c))/(len(np.unique(c))-1))*((len(y)-1)/(len(y)-k)); V=adj*inv@meat@inv
        got=e.compute_cluster_robust_stat(y,t,m,c); fit=e.last_cr1_model_fit_
        np.testing.assert_allclose(fit['beta'],b,atol=1e-12); np.testing.assert_allclose(fit['vcov'],V,atol=1e-12)
        self.assertAlmostEqual(got[0],b[3]/np.sqrt(V[3,3]),places=12)
    def test_8b_invalid_variance_controlled_failure(self):
        e=RobustPooledScreenEngine(); b=np.ones(4); V=np.eye(4); V[0,0]=-1
        with self.assertRaises(ValueError): e._validate_cr1_outputs(b,V)
    def test_8c_noninteraction_invalid_covariance_rejected(self):
        e=RobustPooledScreenEngine(); b=np.ones(4); V=np.eye(4); V[0,1]=np.nan; V[1,0]=np.nan
        with self.assertRaises(ValueError): e._validate_cr1_outputs(b,V)
        V=np.eye(4); V[0,1]=.1
        with self.assertRaises(ValueError): e._validate_cr1_outputs(b,V)
        self.assertTrue(np.isfinite(e._validate_cr1_outputs(b,np.eye(4))[0]).all())
    def test_8d_failed_cr1_clears_prior_fit(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=2, test_mode=True); y,t,m,c=sample(5,6)
        e.compute_cluster_robust_stat(y,t,m,c); self.assertTrue(e.last_cr1_model_fit_)
        bad=e.last_cr1_model_fit_['vcov'].copy(); bad[0,0]=-1; e._test_vcov_override=bad
        try:
            with self.assertRaises(ValueError): e.compute_cluster_robust_stat(y,t,m,c)
            self.assertEqual(e.last_cr1_model_fit_,{})
        finally: e._test_vcov_override=None
    def test_9_plus_one_known_statistics(self):
        p,b,M=RobustPooledScreenEngine.monte_carlo_plus_one_pvalue(2,[3,1,-2.5])
        self.assertEqual((b,M),(2,3)); self.assertAlmostEqual(p,.75)
        self.assertEqual(RobustPooledScreenEngine.monte_carlo_plus_one_pvalue(1,[5,5,5,5])[0],1)
        self.assertEqual(RobustPooledScreenEngine.monte_carlo_plus_one_pvalue(2,[.1,-.1,0])[0],.25)
    def test_9b_mc_path_controlled_stats_and_call_count(self):
        M=4; known=np.array([3,.5,-2.5,1.5]); e=RobustPooledScreenEngine(min_clusters_threshold=4,exact_enumeration_threshold=5,n_permutations=M,test_mode=True)
        y,t,m,c=sample(6,2); e._test_mc_perm_stats=known; real=e.compute_cluster_robust_stat; count={'n':0}
        def fake(y0,t0,m0,c0):
            count['n']+=1
            if count['n']==1:
                try: real(y0,t0,m0,c0)
                except Exception: e.last_cr1_model_fit_={'beta':np.ones(4),'vcov':np.eye(4),'se':np.ones(4),'t_stat':np.ones(4),'df_adj':1.,'G':6,'n':len(y0),'k':4}
                return 2.,0.,1.
            return 0.,0.,1.
        try:
            with patch.object(e,'compute_cluster_robust_stat',side_effect=fake): r=e.cluster_permutation_test(y,t,m,c,assignment_config=MECH)
            self.assertFalse(r[2],r[3]); self.assertAlmostEqual(r[1],.6); self.assertEqual(count['n'],M+1)
        finally: e._test_mc_perm_stats=None
    def test_9c_end_to_end_mc_p_from_captured_statistics(self):
        M=30; e=RobustPooledScreenEngine(min_clusters_threshold=5,exact_enumeration_threshold=50,n_permutations=M,random_state=7)
        y,t,m,c=sample(12,2,7); captured=[]; real=e.compute_cluster_robust_stat
        def spy(*args):
            z=real(*args); captured.append(z[0]); return z
        with patch.object(e,'compute_cluster_robust_stat',side_effect=spy): r=e.cluster_permutation_test(y,t,m,c,assignment_config=MECH)
        self.assertFalse(r[2],r[3]); self.assertEqual(len(captured),M+1)
        p=(sum(abs(x)>=abs(captured[0]) for x in captured[1:])+1)/(M+1); self.assertAlmostEqual(r[1],p)
    def test_10_exact_allocations_match_independent_set(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=2,exact_enumeration_threshold=1000); y,t,m,c=sample(6,2,1)
        t=np.array([1,1,0,0,0,0,0,0,1,1,0,0.]); strata=np.array([0,0,0,1,1,1]); cfg={**MECH,'strata':strata}
        r=e.cluster_permutation_test(y,t,m,c,assignment_config=cfg); self.assertFalse(r[2],r[3])
        got=set(e.last_permutation_diagnostics_['evaluated_treated_sets']); expected=set()
        for a in combinations([0,1,2],1):
            for b in combinations([3,4,5],1): expected.add(frozenset(a+b))
        self.assertEqual(got,expected)
    def test_11_observed_cr1_fit_preserved_after_permutation(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=2); y,t,m,c=sample(4,2,2)
        z=e.compute_cluster_robust_stat(y,t,m,c); fit={k:v.copy() if hasattr(v,'copy') else v for k,v in e.last_cr1_model_fit_.items()}
        r=e.cluster_permutation_test(y,t,m,c,assignment_config=MECH); self.assertFalse(r[2],r[3])
        np.testing.assert_allclose(e.last_cr1_model_fit_['beta'],fit['beta']); np.testing.assert_allclose(e.last_cr1_model_fit_['vcov'],fit['vcov'])
        self.assertAlmostEqual(r[0],z[0])
    def test_12_failed_call_clears_all_inference_state(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=2,n_permutations=5); y,t,m,c=sample(4,2,3)
        self.assertFalse(e.cluster_permutation_test(y,t,m,c,assignment_config=MECH)[2]); self.assertTrue(e.last_observed_cr1_model_fit_)
        r=e.cluster_permutation_test(y,t,m,c,assignment_config={}); self.assertTrue(r[2])
        self.assertEqual(e.last_permutation_diagnostics_,{}); self.assertEqual(e.last_cr1_model_fit_,{}); self.assertEqual(e.last_observed_cr1_model_fit_,{})

if __name__=='__main__': unittest.main()

class TestR23Additions(unittest.TestCase):
    def test_structured_sharp_null_result(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=2)
        rng=np.random.default_rng(91); c=np.repeat(np.arange(4),2); n=len(c)
        seed=314; assign=np.random.Generator(np.random.PCG64(seed)); treated=set(assign.choice(4,2,replace=False).tolist())
        tc=np.array([1.0 if j in treated else 0.0 for j in range(4)]); t=tc[c]
        m=rng.normal(size=n); y=.5*m+rng.normal(size=n)
        cfg={**MECH,'strata':[0,0,0,0], 'randomization_record':{'algorithm':'numpy.PCG64_uniform_without_replacement_v1','seed':seed,'treated_counts':[{'stratum':0,'n_treated':2,'n_clusters':4}]}}
        out=e.sharp_null_test(y,t,m,c,assignment_config=cfg)
        self.assertIsInstance(out.__class__.__name__, str)
        self.assertFalse(out.abstained, out.reason)
        self.assertEqual(out.null_hypothesis, 'sharp_global_zero_effect')
        self.assertEqual(out.diagnostics['backend'], 'python_fractions_exact_rational_algebra')
        self.assertGreaterEqual(out.p_value, 0); self.assertLessEqual(out.p_value, 1)

    def test_exact_rational_constant_effect_inversion_matches_independent_tau_zero_test(self):
        G=6; per=3; c=np.repeat(np.arange(G),per); n=len(c)
        rng=np.random.default_rng(44); m=rng.normal(size=n); base=.5*m+rng.normal(size=n)
        seed=123; chosen=set(np.random.Generator(np.random.PCG64(seed)).choice(G,3,replace=False).tolist())
        t=np.array([float(j in chosen) for j in range(G)])[c]; y=base+.7*t
        rec={'algorithm':'numpy.PCG64_uniform_without_replacement_v1','seed':seed,
             'treated_counts':[{'stratum':0,'n_treated':3,'n_clusters':G}]}
        cfg={**MECH,'strata':[0]*G,'randomization_record':rec}
        exact=RobustPooledScreenEngine(min_clusters_threshold=4,exact_enumeration_threshold=1000)
        out=exact.constant_effect_inversion(y,t,m,c,tau_bounds=(-10,10),assignment_config=cfg,tau_reference=.7)
        self.assertFalse(out.abstained,out.reason)
        self.assertEqual(out.method,'exact_rational_design_based_inversion')
        direct=RobustPooledScreenEngine(min_clusters_threshold=4,exact_enumeration_threshold=1000)
        stat,p,abst,reason=direct.cluster_permutation_test(y-.7*t,t,m,c,assignment_config={**MECH,'strata':[0]*G})
        self.assertFalse(abst,reason)
        self.assertAlmostEqual(float(Fraction(out.diagnostics['p_value_at_tau_reference'])),p,places=12)
        self.assertEqual(out.diagnostics['valid_allocation_count'],20)
        self.assertIn('confidence_set_outer_enclosure',out.diagnostics)
        comps=[(Fraction(a),Fraction(b)) for a,b in out.diagnostics['confidence_set_outer_enclosure']]
        self.assertTrue(any(a<=Fraction(7,10)<=b for a,b in comps))
        self.assertLessEqual(Fraction.from_float(out.ci_lower),min(a for a,b in comps))
        self.assertGreaterEqual(Fraction.from_float(out.ci_upper),max(b for a,b in comps))

    def test_exact_inversion_abstains_if_exact_enumeration_too_large(self):
        G=6; c=np.repeat(np.arange(G),3); n=len(c); rng=np.random.default_rng(8)
        m=rng.normal(size=n); y=rng.normal(size=n); seed=5
        chosen=set(np.random.Generator(np.random.PCG64(seed)).choice(G,3,replace=False).tolist())
        t=np.array([float(j in chosen) for j in range(G)])[c]
        cfg={**MECH,'strata':[0]*G,'randomization_record':{'algorithm':'numpy.PCG64_uniform_without_replacement_v1','seed':seed,'treated_counts':[{'stratum':0,'n_treated':3,'n_clusters':G}]}}
        e=RobustPooledScreenEngine(min_clusters_threshold=4,exact_enumeration_threshold=5)
        out=e.constant_effect_inversion(y,t,m,c,tau_bounds=(-1,1),assignment_config=cfg)
        self.assertTrue(out.abstained)
        self.assertIn('requires full enumeration',out.reason)

    def test_constant_effect_wald_is_labeled_asymptotic(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=2)
        y,t,m,c=sample(8,5)
        out=e.constant_effect_wald(y,t,m,c)
        self.assertFalse(out.abstained, out.reason)
        self.assertEqual(out.validity_classification, 'asymptotic_in_G_not_finite_sample_exact')
        self.assertEqual(out.diagnostics['degrees_of_freedom'], 4)

    def test_test_hooks_disabled_in_production(self):
        e=RobustPooledScreenEngine()
        e._test_vcov_override=np.eye(4)
        y,t,m,c=sample(12,6)
        with self.assertRaises(RuntimeError): e.compute_cluster_robust_stat(y,t,m,c)

    def test_holm_structured_result_surfaces_untestable(self):
        e=RobustPooledScreenEngine(alpha=.05)
        e.construct_family(['a','b'],['m'],['r']); e.mark_untestable(1)
        out=e.holm_result([.01,1.0])
        self.assertEqual(out.untestable_indices,(1,))
        self.assertEqual(len(out.adjusted_p_values),2)

    def test_exact_binary_rational_rank_and_unresolved_conditioning(self):
        X=np.array([[1.,0.],[0.,1.],[1.,1.]])
        out=RobustPooledScreenEngine.exact_binary_rational_rank(X)
        self.assertEqual(out['algebraic_rank'],2)
        self.assertTrue(out['algebraically_full_column_rank'])
        self.assertEqual(out['numerical_condition_classification'],'numerically_unresolved')
        bad=RobustPooledScreenEngine.exact_binary_rational_rank(np.array([[1.,2.],[2.,4.]]))
        self.assertEqual(bad['algebraic_rank'],1)

    def test_r23_randomization_record_mismatch_abstains(self):
        e=RobustPooledScreenEngine(min_clusters_threshold=2)
        y,t,m,c=sample(4,2)
        cfg={**MECH,'strata':[0,0,0,0], 'randomization_record':{
            'algorithm':'numpy.PCG64_uniform_without_replacement_v1','seed':123,
            'treated_counts':[{'stratum':0,'n_treated':2,'n_clusters':4}]}}
        out=e.sharp_null_test(y,t,m,c,assignment_config=cfg)
        self.assertTrue(out.abstained)
        self.assertIn('does not reproduce',out.reason)
