import base64, json, sqlite3
import pytest
from cryptography.hazmat.primitives.asymmetric import ed25519
from cro.remote_authority import AuthorityApplication
from cro.idempotent_receiver import IdempotentReceiver
from cro.postgres_store import _CursorAdapter, PostgresDurableStore


def _write_authority_key(path):
    from cryptography.hazmat.primitives import serialization
    key = ed25519.Ed25519PrivateKey.generate()
    path.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    path.chmod(0o600)
    return key


def test_remote_authority_issues_verifiable_token_and_revoke_invalidates(tmp_path):
    key_path = tmp_path/'authority.pem'
    _write_authority_key(key_path)
    app = AuthorityApplication(str(tmp_path/'authority.db'), str(key_path), 'a'*40)
    assert key_path.stat().st_mode & 0o777 == 0o600
    token = app.issue({'candidate_id':'c1','worker_id':'w1','epoch':1,'ttl_seconds':20})
    from cryptography.hazmat.primitives import serialization
    pub = app.key.public_key()
    sig = base64.b64decode(token['signature_b64'])
    from cro.trace_integrity import canonical_serialize
    raw = canonical_serialize(token['claims'])
    pub.verify(sig, b'CRO_LEASE_AUTH_V1'+len(raw).to_bytes(8,'big')+raw)
    assert app.current_epoch() == 0
    app.revoke({'worker_id':'w1','reason':'test revocation'})
    assert app.current_epoch() == 1
    receiver = IdempotentReceiver(str(tmp_path/'receiver.db'), pub, app.current_epoch, require_shared_postgres=False)
    with pytest.raises(PermissionError, match='authority epoch'):
        receiver.accept('id-1', token, {'action':'write'})


def test_idempotent_receiver_accepts_once_replays_same_result_and_rejects_conflict(tmp_path):
    key_path = tmp_path/'authority.pem'
    _write_authority_key(key_path)
    app = AuthorityApplication(str(tmp_path/'authority.db'), str(key_path), 'b'*40)
    token = app.issue({'candidate_id':'c1','worker_id':'w1','epoch':3,'ttl_seconds':20})
    receiver = IdempotentReceiver(str(tmp_path/'receiver.db'), app.key.public_key(), app.current_epoch, require_shared_postgres=False)
    first = receiver.accept('same-key', token, {'action':'commit','value':1})
    second = receiver.accept('same-key', token, {'action':'commit','value':1})
    assert first == second and first['accepted'] is True
    with pytest.raises(ValueError, match='reused'):
        receiver.accept('same-key', token, {'action':'commit','value':2})
    stale = app.issue({'candidate_id':'c1','worker_id':'w2','epoch':2,'ttl_seconds':20})
    with pytest.raises(PermissionError, match='stale fencing'):
        receiver.accept('new-key', stale, {'action':'stale'})


def test_postgres_store_fails_clearly_when_optional_driver_missing():
    with pytest.raises(RuntimeError, match='psycopg'):
        PostgresDurableStore('postgresql://unused')


class DummyCursor:
    def __init__(self): self.sql=None; self.params=None
    def execute(self, sql, params): self.sql, self.params = sql, params
    def fetchone(self): return ('ok',)
    def fetchall(self): return []


def test_postgres_adapter_translates_qmarks_without_touching_quoted_literals():
    c=DummyCursor(); a=_CursorAdapter(c)
    a.execute("INSERT INTO t(a,b,c) VALUES(?, '?', ?)", (1,2))
    assert c.sql == "INSERT INTO t(a,b,c) VALUES(%s, '?', %s)"
    assert c.params == (1,2)

def test_detached_manifest_signature_round_trip_and_tamper_detection():
    from cro.trace_integrity import sign_release_manifest, verify_release_manifest
    key=ed25519.Ed25519PrivateKey.generate()
    payload=b'approved release payload'
    import hashlib
    manifest={'release':'test','files':{'payload.bin':hashlib.sha256(payload).hexdigest()}}
    signed=sign_release_manifest(manifest,key)
    assert verify_release_manifest(signed,key.public_key(),{'payload.bin':payload})
    assert not verify_release_manifest(signed,key.public_key(),{'payload.bin':b'tampered'})


def test_authority_service_refuses_missing_or_overexposed_signing_key(tmp_path):
    missing = tmp_path / "missing.pem"
    with pytest.raises(FileNotFoundError, match="must be provisioned"):
        AuthorityApplication(str(tmp_path / "authority.db"), str(missing), "c" * 40)
    loose = tmp_path / "loose.pem"
    _write_authority_key(loose)
    loose.chmod(0o644)
    with pytest.raises(PermissionError, match="owner-readable"):
        AuthorityApplication(str(tmp_path / "authority.db"), str(loose), "d" * 40)
