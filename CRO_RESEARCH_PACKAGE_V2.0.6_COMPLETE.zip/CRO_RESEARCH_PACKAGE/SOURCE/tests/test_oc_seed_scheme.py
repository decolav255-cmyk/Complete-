from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "OC"))
from seed_scheme import SEED_SCHEME_VERSION, child_rng, seed_word  # noqa: E402


def test_oc_seed_words_are_stable_sha256_derivations():
    assert SEED_SCHEME_VERSION == "sha256_label_words_v1"
    assert seed_word("scenario", "sharp_null") == 1693773858
    assert seed_word("cell_id", "G12_n5_icc0.20_beta0.35") == 2796761187
    assert seed_word("role", "outcomes") == 671970481


def test_oc_child_rng_is_repeatable_and_role_separated():
    a = child_rng("sharp_null", "G12_n5_icc0.20_beta0.00", 7, "outcomes")
    b = child_rng("sharp_null", "G12_n5_icc0.20_beta0.00", 7, "outcomes")
    c = child_rng("sharp_null", "G12_n5_icc0.20_beta0.00", 7, "assignment")
    np.testing.assert_array_equal(a.integers(0, 2**32, size=16), b.integers(0, 2**32, size=16))
    assert not np.array_equal(
        child_rng("sharp_null", "G12_n5_icc0.20_beta0.00", 7, "outcomes").integers(0, 2**32, size=16),
        c.integers(0, 2**32, size=16),
    )


def test_oc_seed_scheme_rejects_invalid_labels_and_replicates():
    import pytest
    with pytest.raises(ValueError):
        seed_word("", "label")
    with pytest.raises(ValueError):
        child_rng("scenario", "cell", -1, "role")
