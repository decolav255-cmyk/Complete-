from cro.postgres_compat import PostgresConnection


def test_postgres_sql_adapter_rewrites_sqlite_dialect():
    sql = PostgresConnection._sql("CREATE TABLE IF NOT EXISTS x (id INTEGER PRIMARY KEY AUTOINCREMENT, n REAL NOT NULL, payload BLOB NOT NULL)")
    assert "BIGSERIAL PRIMARY KEY" in sql
    assert "BYTEA NOT NULL" in sql
    assert "AUTOINCREMENT" not in sql
    assert PostgresConnection._sql("INSERT OR IGNORE INTO authority_state(id,authority_epoch) VALUES(1,0)") == "INSERT INTO authority_state(id,authority_epoch) VALUES(1,0) ON CONFLICT DO NOTHING"
    assert "GREATEST(epoch, excluded.epoch)" in PostgresConnection._sql("UPDATE t SET epoch=MAX(epoch,excluded.epoch) WHERE id=?")
    assert "%s" in PostgresConnection._sql("SELECT * FROM t WHERE id=?")
    assert "SERIALIZABLE" in PostgresConnection._sql("BEGIN IMMEDIATE")


def test_postgres_append_only_trigger_ddl_is_not_silently_discarded():
    sql = PostgresConnection._sql("CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit BEGIN SELECT RAISE(ABORT,'immutable'); END")
    assert "CREATE TRIGGER IF NOT EXISTS audit_no_delete" in sql


def test_postgres_migration_trigger_names_match_runtime_schema_checks():
    from pathlib import Path
    root = Path(__file__).resolve().parents[2]
    migration = (root / "DEPLOYMENT/postgresql/002_cro_core.sql").read_text()
    policy = (root / "SOURCE/cro/policy.py").read_text()
    engine = (root / "SOURCE/cro/engine.py").read_text()
    integrity = (root / "SOURCE/cro/trace_integrity.py").read_text()
    pilot = (root / "SOURCE/cro/pilot.py").read_text()
    tables = {
        "reservation_history", "fenced_mutation_log", "authority_audit",
        "revoked_workers", "consumed_authority_tokens", "state_transition_log",
        "receiver_effects", "trusted_keys", "trusted_key_history", "verified_anchors",
    }
    for table in tables:
        assert f"'{table}'" in migration, f"migration does not protect {table}"
    assert "t || '_no_update'" in migration and "t || '_no_delete'" in migration
    assert "CREATE TRIGGER %I BEFORE UPDATE" in migration
    assert "CREATE TRIGGER %I BEFORE DELETE" in migration
    expected = {
        "reservation_history_no_update", "reservation_history_no_delete",
        "fenced_mutation_log_no_update", "fenced_mutation_log_no_delete",
        "authority_audit_no_update", "authority_audit_no_delete",
        "revoked_workers_no_update", "revoked_workers_no_delete",
        "consumed_authority_tokens_no_update", "consumed_authority_tokens_no_delete",
        "state_transition_log_no_update", "state_transition_log_no_delete",
        "trusted_keys_no_update", "trusted_keys_no_delete",
        "trusted_key_history_no_update", "trusted_key_history_no_delete",
        "verified_anchors_no_update", "verified_anchors_no_delete",
    }
    for trigger in expected:
        assert trigger in policy + engine + integrity + pilot, f"runtime schema check missing {trigger}"


def test_postgres_retry_decorator_replays_only_retryable_database_aborts():
    from cro.postgres_compat import retry_postgres_serialization

    class DbError(Exception):
        def __init__(self, sqlstate):
            self.sqlstate = sqlstate

    class Service:
        db_path = "postgresql://example.invalid/cro"
        def __init__(self): self.calls = 0

        @retry_postgres_serialization(dsn_attr="db_path", max_attempts=3)
        def operation(self):
            self.calls += 1
            if self.calls == 1:
                raise DbError("40001")
            return "committed"

    service = Service()
    assert service.operation() == "committed"
    assert service.calls == 2

    class Broken(Service):
        @retry_postgres_serialization(dsn_attr="db_path", max_attempts=3)
        def operation(self):
            self.calls += 1
            raise DbError("23505")

    broken = Broken()
    try:
        broken.operation()
    except DbError:
        pass
    else:
        raise AssertionError("non-retryable SQLSTATE was swallowed")
    assert broken.calls == 1


def test_postgres_commit_failure_rolls_back_connection_before_retry():
    class BrokenCommitConnection:
        def __init__(self): self.rollbacks = 0
        def commit(self): raise RuntimeError("commit failed")
        def rollback(self): self.rollbacks += 1
        def close(self): pass

    adapter = object.__new__(PostgresConnection)
    adapter._conn = BrokenCommitConnection()
    adapter._active = True
    adapter._depth = 0
    try:
        adapter.commit()
    except RuntimeError as exc:
        assert str(exc) == "commit failed"
    else:
        raise AssertionError("commit failure was swallowed")
    assert adapter._conn.rollbacks == 1
    assert adapter.in_transaction is False
