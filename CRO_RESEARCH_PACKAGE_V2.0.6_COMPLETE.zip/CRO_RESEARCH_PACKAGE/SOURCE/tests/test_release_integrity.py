import hashlib
from pathlib import Path

import numpy as np

from cro.pooled_screen import RobustPooledScreenEngine

APPROVED_R23_SHA256 = "92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6"


def test_g7_r23_source_matches_frozen_pin():
    source = Path(__file__).resolve().parents[1] / "cro" / "pooled_screen.py"
    assert hashlib.sha256(source.read_bytes()).hexdigest() == APPROVED_R23_SHA256


def test_g7_direct_invocation_of_pinned_r23_sharp_null_test():
    clusters = np.repeat(np.arange(4), 2)
    seed = 17
    chosen = set(np.random.Generator(np.random.PCG64(seed)).choice(4, 2, replace=False).tolist())
    cluster_t = np.array([float(i in chosen) for i in range(4)])
    treatment = cluster_t[clusters]
    moderator = np.linspace(-1.0, 1.0, len(clusters))
    outcome = 0.3 * treatment + 0.2 * moderator + np.random.default_rng(5).normal(0, 0.1, len(clusters))
    config = {
        "mechanism": "complete_cluster_randomization_within_strata",
        "strata": [0, 0, 0, 0],
        "randomization_record": {
            "algorithm": "numpy.PCG64_uniform_without_replacement_v1",
            "seed": seed,
            "treated_counts": [{"stratum": 0, "n_treated": 2, "n_clusters": 4}],
        },
    }
    engine = RobustPooledScreenEngine(min_clusters_threshold=2, exact_enumeration_threshold=100)
    result = engine.sharp_null_test(
        outcome, treatment, moderator, clusters,
        assignment_design="cluster", assignment_config=config,
    )
    assert result.abstained is False, result.reason
    assert result.method == "cluster_randomization_test"
    assert result.p_value is not None
