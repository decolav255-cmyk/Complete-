# CRO Demonstration Specification v2.0.2

**Version:** 2.0.2  
**Date:** 2026-11-06  
**Status:** DRAFT FOR INSPECTION — not formally frozen  
**Amends:** v2.0.1 (three specification corrections only)  
**Non-changes:** No new simulations; historical numerical results unchanged; V3 failure retained; commercial D1 interpretation unchanged  

**R23 source pin (verified on this package):**  
`SOURCE/cro/pooled_screen.py`  
SHA-256: `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`  
(Verified by direct hash of the file in this package.)

---

# Part A — Scope

Single demonstration-track specification. Demo ≠ OC Protocol v1.1 completion.  
Not partner/production validation. Not formal freeze until explicitly approved.

---

# Part B — D1 procedure

## B1. Eligibility (record / design)

Design-eligible only if all hold:

- Mechanism `complete_cluster_randomization_within_strata`
- Treatment constant within cluster  
- Cluster-level strata aligned to first-appearance cluster order  
- `randomization_record` present with algorithm `numpy.PCG64_uniform_without_replacement_v1`, nonnegative integer seed, and treated_counts  
- Observed assignment **reproduces** from that record under the pinned verifier  

Otherwise primary state = **NOT_ELIGIBLE** (test not run as CRT). Do not fabricate a record.

## B2. Mutually exclusive primary states

| State | When |
|-------|------|
| **NOT_ELIGIBLE** | Missing, invalid, or unreproducible assignment record / non-CRT design (includes S1) |
| **ABSTAIN** | Record validates, but numerical or computational engine failure (rank/variance/threshold/other engine exception) |
| **DO_NOT_AUTHORIZE** | Eligible test executed successfully; \(p \ge 0.05\) |
| **AUTHORIZE** | Eligible test executed successfully; \(p < 0.05\) → label `AUTHORIZE_DESIGN_BASED_REJECTION_OF_SHARP_NULL` |

Always record `reason` separately.  
**NOT_ELIGIBLE** is not ABSTAIN.  
Forbidden primary reason: `confounding_flag_demo`.

Historical S1 rows that set both `D1_do_not_authorize` and `D1_abstain` with reason `missing_randomization_record` are interpreted as **NOT_ELIGIBLE**. Rates unchanged.

## B3. Null and statistic

**Null:** sharp global null \(Y_i(1)=Y_i(0)\) for all units under the declared randomization.

**Entry point:** `sharp_null_test` → `constant_effect_inversion(..., tau_reference=0.0, fixed_tau_only=True)` in the pinned source.

**Statistic:** absolute CR1 **interaction** \(t\) for the \(T\times M\) coefficient in the working model with columns \((1,T,M,T\times M)\), at fixed \(\tau=0\). Diagnostics name: `absolute_t_statistic`.

**Binding limitations**

- Rejection of the sharp null ≠ establishment of moderation.  
- Non-rejection ≠ proof that a uniform main effect is absent.  
- Statistic is primarily sensitive to interaction-aligned alternatives.

## B4. Allocation universe and estimability rule (formal)

### B4.1 Full design allocation universe

Given strata and fixed within-stratum treated counts from the observed design margins, the **design universe** \(\mathcal{A}\) is the set of all cluster treatment assignments obtainable by choosing treated-cluster subsets of the required size within each stratum (product of combinations). Enumeration uses first-appearance cluster order as in the pinned code.

### B4.2 Deterministic estimability predicate (design + pretreatment only)

Moderator \(M\) is treated as **pretreatment** (fixed under the sharp-null randomization of \(T\)).

For candidate assignment \(T^{(A)}\) (cluster-level expanded to individuals), form the individual-level design matrix with rows

\[
X_i^{(A)} = \big(1,\ T^{(A)}_i,\ M_i,\ T^{(A)}_i M_i\big).
\]

Let \(H^{(A)} = (X^{(A)})^\top X^{(A)}\) (exact rational Gram matrix as in the pinned `exact_rank_and_fit` / `inv_matrix` path).

**Primary estimability rule \(E(A)\):**

1. \(H^{(A)}\) is full rank (invertible under exact rational Gaussian elimination as implemented).  
2. Cluster count and sample size meet engine minima (\(G>1\), \(n>k\) with \(k=4\)).  
3. The CR1 variance structure for the interaction contrast is not identically degenerate as a polynomial in the pure design sense required by the implementation’s “variance polynomial identically zero” guard when that guard is implied by design-only conditions.

**Outcome independence requirement (normative):**  
The **retained set** for an exact conditional randomization test must be

\[
\mathcal{A}_{\mathrm{ret}} = \{A\in\mathcal{A}: E(A)=\mathrm{true}\},
\]

where \(E(A)\) is a function only of **(assignment \(A\), pretreatment design information including \(M\), strata, cluster sizes)** — **not** of observed outcomes \(Y\).

**Observed allocation requirement:**  
\(A_{\mathrm{obs}}\in\mathcal{A}_{\mathrm{ret}}\). If the observed assignment is not estimable under \(E\), primary state = **ABSTAIN** (eligible design record, but test not executed).

### B4.3 Why conditioning preserves a randomization test

If \(E(A)\) depends only on assignment and pretreatment design information, then under the sharp null ( \(Y\) fixed; \(T\) randomized), the event \(\{A\in\mathcal{A}_{\mathrm{ret}}\}\) is determined before looking at the outcome-driven extremeness ordering. The randomization distribution **conditional on** \(A_{\mathrm{obs}}\in\mathcal{A}_{\mathrm{ret}}\) and on the realized pretreatment design is the uniform distribution over \(\mathcal{A}_{\mathrm{ret}}\) (under complete randomization within strata with fixed margins). The p-value

\[
p = \frac{\#\{A\in\mathcal{A}_{\mathrm{ret}}:\ A\text{ is at least as extreme as }A_{\mathrm{obs}}\}}{|\mathcal{A}_{\mathrm{ret}}|}
\]

is then an **exact conditional** randomization p-value under that uniform law.

### B4.4 Implementation honesty note (pinned R23)

In the pinned source, exclusion is implemented by trying `exact_rank_and_fit` per allocation and catching failures. Rank non-invertibility of \(H^{(A)}\) is design/pretreatment-based. Some failure messages can involve variance polynomials constructed using outcome residuals in the code path.

**Normative rule for claims under this specification:**  
Exactness is claimed for the **conditional test given \(\mathcal{A}_{\mathrm{ret}}\) defined by design-and-pretreatment estimability**. If a particular replicate’s exclusion set were to differ solely because of \(Y\)-dependent guards, that replicate must be treated as **ABSTAIN** or flagged, not as a standard exact p-value. Historical confirmatory aggregates remain as recorded by the engine at run time; this section constrains **interpretation and future runs**.

### B4.5 p-value

As implemented in fixed-τ path: Fraction of retained allocations at least as extreme as observed under the R23 comparison polynomial ranking at \(\tau=0\); \(\alpha=0.05\).

---

# Part C — Historical results (unchanged figures)

Master seed `20261108`. n=500.

**S1:** OLS unclustered sig pos 0.982; AUTHORIZE 0; NOT_ELIGIBLE (missing_randomization_record) 1.0; primary success **0.982** (0.966, 0.991).

**S2:** AUTHORIZE **0.046** (0.031, 0.068); ABSTAIN 0; OLS unclustered sig pos 0.312 (0.273, 0.354) — not CRT-valid; **V3 FAILED** (\(\hat p\ge 0.20\) only).

**S3:** AUTHORIZE **0.046** (0.031, 0.068); ABSTAIN 0.

**V3 sole pass rule:** \(\hat p_{\mathrm{AUTHORIZE}}\ge 0.20\). CI does not create an alternate pass.

---

# Part D — Comparators and commercial limits

- **C1_OLS_unclustered:** pooled OLS IID SE; not CRT-valid.  
- **C1m_cluster:** predeclared §F; unevaluated.  
- **C2:** naive CR1-normal interaction only.  

Forbidden: D1 ⇒ moderation/benefit; 31.2% ⇒ CRT main-effect detection; demo ⇒ OC complete.

---

# Part E — Optional S2i

Separate future arm (\(\beta=0.35\)). Does not validate V3 on main-effect S2.

---

# Part F — C1m_cluster (predeclared, unevaluated)

Estimand \(\tau=\mathbb{E}[Y_{ic}(1)-Y_{ic}(0)]\). Equal cluster sizes in first evaluation design so individual- and cluster-weighted ATE coincide; unequal sizes need amendment.  
Model \(Y\sim 1+T+\) stratum FE. Statistic \(t_\tau=\hat\tau/\mathrm{SE}_{\mathrm{CR1}}\); \(p=2\Phi(-|t_\tau|)\); \(\alpha=0.05\). Wald 95% CI. Complete cases or abstain.  
First evaluation design if later approved: S2-like G=12, \(n_c=5\), ICC 0.20, \(\tau_0=0.35\), \(\beta=0\), 500 reps. No performance claim until then. CR1 normal p is candidate, not validated OC at G=12.

---

# Part G — Reproducibility (complete)

## G1. Seeds

```text
u32(label) = unsigned big-endian uint32 from SHA-256(UTF-8 bytes of label)[0:4]
SeedSequence([20261108, u32(scenario), int(replicate_id), u32(role)]) → numpy.random.PCG64 → Generator
```

- `replicate_id` starts at **0**.  
- Scenario strings: `S1`, `S2`, `S3`.  
- Role strings: `C`, `M`, `Y`, `assignment` exactly.  
- Python `hash()` forbidden.

## G2. Within-stratum treated sampling (S2/S3)

```text
rec_seed = int(Generator(child_rng(scenario, rep, "assignment")).integers(0, 2**31 - 1))
gen = Generator(PCG64(rec_seed))   # single generator, strata in order 0,1
for each stratum st in {0,1}:
    members = cluster indices with strata_c == st  # contiguous blocks: [0..G/2-1], [G/2..G-1]
    nt = len(members) // 2
    selected = set(gen.choice(len(members), size=nt, replace=False).tolist())
    # gen.choice uses NumPy Generator API; without-replacement index draw
    cluster_t[c] = 1 if local index in selected else 0
```

Record stores `seed=rec_seed`, algorithm string above, and treated_counts.

## G3. Moderator

```text
rng_M = child_rng(scenario, rep, "M")
M_c = rng_M.normal(0.0, 1.0, size=G)
M_c = (M_c - M_c.mean()) / M_c.std(ddof=0)   # population std (ddof=0)
```

## G4. Outcome generation (`simulate_Y`) — exact draw order

```text
rng_Y = child_rng(scenario, rep, "Y")
sigma_u2 = ICC
sigma_e2 = 1.0 - ICC
u = rng_Y.normal(0.0, sqrt(sigma_u2), size=G)             # cluster intercepts, length G
eps = rng_Y.normal(0.0, sqrt(sigma_e2), size=n_individuals)  # individual noise, length G * n_per
gamma = -0.15 on stratum 0 clusters, +0.15 on stratum 1
# S1 only: C_c = child_rng("S1", rep, "C").normal(0,1,size=G); delta=0.6
# S2/S3: C_c = 0; delta=0
Y = gamma[cluster] + u[cluster] + eps + T_cluster*(tau0 + beta*M_c[cluster]) + delta*C_c[cluster]
```

Individual order: `clusters = np.repeat(np.arange(G), n_per)` (cluster 0’s individuals contiguous, etc.).

## G5. Historical vs future

Part C aggregates are historical. New runs need not match old row-level draws bit-for-bit after seed-policy hardening.

---

# Part H — OC v1.1

Separate; partial; not replaced by this demo.

---

# Part I — External narrative

Without a verifiable randomization record, unclustered OLS was often significant (98.2%) while CRO never AUTHORIZE (NOT_ELIGIBLE / missing record); primary success 98.2% (96.6–99.1%).  
With a CRT record, D1 AUTHORIZE is sharp-null rejection via an interaction functional (S2: 4.6%; V3 power floor failed). Unclustered OLS 31.2% is not CRT-valid main-effect inference.  
One sentence: design-gated brake and sharp-null randomization test — not automatic ROI/moderation detection.

---

# Part J — Approval

v2.0.2 only tightens estimability, state partition, and reproducibility detail.

Formal freeze phrase (only when intended):

`Approve CRO Demonstration Specification v2.0.2 as written.`

Until then: inspection draft. No new runs unless separately requested.
