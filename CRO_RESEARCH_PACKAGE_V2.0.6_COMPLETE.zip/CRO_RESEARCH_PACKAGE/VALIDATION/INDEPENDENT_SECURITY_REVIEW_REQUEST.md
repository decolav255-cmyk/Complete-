# Independent CRO security review request

**Reviewer requirement:** This review must be performed by a qualified reviewer who did not implement this candidate and who is independent of the implementation author. An AI-assisted review may identify issues, but does not by itself constitute an independent professional security assessment.

## Exact review target

Review the exact SHA-256 identified in the release receipt for the candidate ZIP, including all source, migrations, Docker configuration, runbooks and verification logs. Do not silently substitute a later working tree.

## Required scope

1. **Authorization and cryptography:** Ed25519 key loading/custody, signature domain separation, claim validation, expiry, replay prevention, authority epoch changes, revocation, nonce uniqueness and key rotation.
2. **Concurrency and fencing:** SERIALIZABLE isolation, retry safety, deadlock handling, single-use token consumption, epoch takeover, stale-holder rejection and duplicate delivery.
3. **Persistence integrity:** append-only triggers, database roles/ownership, migration idempotence, transaction rollback, restart, backup/restore and audit completeness.
4. **Service security:** HTTP authentication, request size limits, error handling, denial-of-service exposure, binding/ingress, TLS termination, headers, logs and health endpoints.
5. **Container security:** non-root execution, read-only filesystem, capabilities, secret mounts, image dependencies, patching, exposed ports and Compose defaults.
6. **Operational controls:** secret rotation, key compromise, revocation, incident response, monitoring, backup protection and recovery runbooks.
7. **Data protection:** customer data minimization, retention/deletion, access boundaries, encryption and jurisdiction-specific obligations.

## Required deliverables

- Findings classified Critical / High / Medium / Low / Informational.
- Evidence and affected file/line references for every finding.
- Exploitability and impact analysis; no generic checklist-only report.
- Required remediation and retest evidence for each Critical/High finding.
- Explicit residual-risk statement and a signed verdict: PASS, CONDITIONAL PASS, or FAIL.
- Reviewer identity, qualifications, independence statement, date and exact candidate SHA-256.

## Independence and limitations

The reviewer must disclose any conflicts and must not rely solely on the implementation author's test summary. They should inspect the source, run the PostgreSQL 16 verification procedure, and independently validate critical controls. The review must not certify customer-specific legal or regulatory compliance without the appropriate specialist scope.
