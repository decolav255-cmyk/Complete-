# Owner-controlled release signing handoff

The project owner must generate and retain the release private key. The implementation environment must never receive or generate the owner's production signing private key.

## Generate offline

On an owner-controlled offline machine:

```bash
python scripts/generate_release_key.py \
  --private /secure/offline/cro-release-private.pem \
  --public DEPLOYMENT/cro-release-public.pem
```

Keep the private key offline or in an owner-controlled KMS/HSM. Back it up securely. Do not upload it to ChatGPT, commit it, place it in the Docker image, or copy it into the deployment host.

## Sign the finalized candidate

After the live PostgreSQL 16 gate, independent review, remediation and final manifest are complete, extract the exact final package and run:

```bash
cd CRO_RESEARCH_PACKAGE
PYTHONPATH=SOURCE python scripts/sign_release.py \
  --private-key /secure/offline/cro-release-private.pem
PYTHONPATH=SOURCE python scripts/verify_release.py \
  --public-key DEPLOYMENT/cro-release-public.pem
```

The detached signature file is `CRO_RELEASE_MANIFEST.sig.json`. Verify it against the public key and exact package files. Record the final ZIP SHA-256 and the signature file SHA-256 in the release receipt.

## Owner approval

The owner should confirm the candidate ZIP hash, review verdict, validation log, public-key fingerprint and deployment target before authorizing release. Any post-signing file change invalidates the signed manifest and requires a new review of the delta and a new owner signature.
