# PostgreSQL application migration — phase 2 audit

**Date:** 2026-11-09  
**Disposition:** Expanded PostgreSQL implementation candidate; not production-ready.

## Changes implemented

- Added `SOURCE/cro/postgres_compat.py`, a psycopg-backed connection adapter for the existing CRO DB-API/qmark persistence interfaces. It maps `BEGIN IMMEDIATE` to SERIALIZABLE transactions, converts selected SQLite SQL idioms, and leaves append-only enforcement to PostgreSQL migrations.
- Enabled `DurableStore(backend="postgresql", db_path=DSN)` rather than the previous explicit `NotImplementedError` path.
- Adapted `DurablePolicyManager` and `AuthorizationAuthority` to accept the PostgreSQL connection interface without changing their business logic or the SQLite test path.
- Adapted `DurableEngine` to use the PostgreSQL-compatible connection interface.
- Added PostgreSQL DSN support to the remote authority and idempotent receiver.
- Added `DEPLOYMENT/postgresql/002_cro_core.sql` for policy reservations, authority state/audit, token consumption, engine state/transition history, receiver epochs and idempotency records. Append-only triggers protect audit/history, consumed tokens, revocations, and accepted receiver effects.
- Updated Compose to mount both migrations on first PostgreSQL volume initialization and configure the remote authority to use its PostgreSQL DSN.
- Added an opt-in full-stack PostgreSQL integration test covering policy reservation, engine transitions, authority token issuance, and receiver deduplication.
- Updated deployment documentation and explicit production stop conditions.

## Verification actually performed

- Python test suite: **74 passed, 2 skipped**.
- Both skipped tests require `CRO_TEST_POSTGRES_DSN`; neither ran against a live database.
- Python compilation passed (`python -m compileall -q cro tests`).
- Approved R23 source pin remains unchanged: `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`.

## Not verified / release blockers

- `psycopg` is not installed in this environment; no PostgreSQL server/client or Docker executable is available.
- Migration SQL has not been executed by PostgreSQL. SQL dialect compatibility, trigger installation, schema privileges, and actual transaction semantics remain unverified.
- No concurrent lease races, serialization/deadlock retries for core policy workflows, crash/restart, backup/restore, migration-upgrade, or connection-loss tests were run.
- No Docker build, Compose launch, authority health check against PostgreSQL, downstream customer receiver integration, or remote deployment was run.
- No independent security review, customer-specific data protection review, owner-controlled signing key, or detached owner signature is included.

## Verdict

The code and schema migration now cover the PostgreSQL paths for the policy manager, execution engine, remote authority, receiver, and durable store at implementation level. The package is materially more complete than phase 1, but **a full PostgreSQL integration pass has not been established**. Do not represent this as production-ready or a final release until the live PostgreSQL and operational blockers above are closed.

The approved v2.0.5 scientific specification, R23 source, and historical scientific results were not intentionally modified.
