# Security Remediation Record — v2.0.6 Complete Distribution

**Baseline archive:** CRO_RESEARCH_PACKAGE_V2.0.5_POSTGRES_PHASE3_CANDIDATE.zip  
**Baseline SHA-256:** 1d210a9db2f2708d16f0f31070d03b1e30830464119de475fb7ac3fcb4e96b24  
**Status:** Complete distribution assembled from verified v2.0.5 scientific baseline + v2.0.6 security-remediation changes. Unit tests re-executed and passed.  
**Not claimed:** Penetration test, live PostgreSQL 16 privilege validation, TLS termination validation, production readiness, or full outbox lifecycle (renewal / dead-letter / consumer deduplication beyond receiver idempotency).

## Implemented controls

### C1 — Shared PostgreSQL invariant
- `IdempotentReceiver` defaults to `require_shared_postgres=True`.
- Non-Postgres DSNs are rejected under the pilot path.
- `authority_state` is read inside the receiver SERIALIZABLE transaction when the invariant is enabled.
- Laboratory escape hatch (`require_shared_postgres=False`) still requires a callable epoch provider and is explicitly non-atomic.

### H1 — Cleartext HTTP boundary
- Non-loopback binds refused unless `CRO_AUTHORITY_ALLOW_CLEARTEXT=1`.
- Explicit statement that TLS is not implemented inside the stdlib HTTP server; reverse-proxy / mTLS required for non-lab use.

### H2 — Rate limiting and body limits
- Separate unauthenticated and authenticated token buckets.
- Content-Length checked before body read; default max 16 KiB.
- In-process only; proxy-level limits remain required.

### H3 — Administrator token rotation
- Primary + optional previous token with constant-time comparison (`hmac.compare_digest`).
- Previous must be ≥32 characters and distinct.
- Removing previous invalidates it after restart.

### H4 — Trusted-key revocation
- Append-only `revoked_keys` table + history `REVOKED` action.
- Administrator authorization verified before idempotent success on already-revoked keys.
- Root admin key cannot be revoked via the ordinary path.
- `get_public_key_bytes` / `verify_signature` consult revocation state.
- PostgreSQL migration 002 updated; runtime role grants SELECT/INSERT only on `revoked_keys`.

### H5 — Database least privilege
- Runtime role script revokes prior broad grants, removes schema CREATE for `cro_app`, restricts UPDATE to mutable tables, and grants SELECT/INSERT only on append-only evidence tables.
- Default privileges no longer auto-grant UPDATE to `cro_app`.

### Outbox scope (narrowed)
- Durable outbox table exists (`durable_outbox`) with status column.
- Writes occur inside SERIALIZABLE transactions via `DurableStore` / `PostgresStore`.
- Serialization failure retries are bounded and limited to SQLSTATE 40001/40P01.
- **Not implemented / not claimed:** outbox-level fencing tokens, lease renewal on outbox rows, explicit acknowledgement protocol, dead-letter queue, or consumer-side deduplication beyond the receiver’s own `receiver_effects` idempotency table.
- Callers remain responsible for higher-level exactly-once semantics where required.

## Tests executed (assembly environment)

```
PYTHONPATH=SOURCE pytest SOURCE/tests/ -v
```

**Result:** 94 passed, 7 skipped (live PostgreSQL / optional driver tests — environment has no PostgreSQL server or Docker).

Live PostgreSQL role enforcement, Docker/Compose gates, backup/restore, and TLS termination validation were not executed. They remain required before staging acceptance.

## Frozen scientific baseline

v2.0.5 specification (`CRO_DEMONSTRATION_SPEC_v2.0.5.md`), approval record (`DEMO/APPROVAL_v2.0.5.txt`), historical S1–S3 rates, V3 failure, Option A artifacts, and pinned R23 hash are retained unchanged from the approved baseline.
