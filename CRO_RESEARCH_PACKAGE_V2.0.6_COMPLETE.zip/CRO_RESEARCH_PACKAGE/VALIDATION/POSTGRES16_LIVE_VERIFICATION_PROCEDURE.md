# CRO PostgreSQL 16 live verification procedure

**Purpose:** Execute the remaining environment-dependent verification after PostgreSQL 16 and Docker are available. This procedure does not authorize production traffic.

## 1. Prerequisites

- Docker Engine and Docker Compose v2.
- Python 3.11+ on the host.
- PostgreSQL 16 image access.
- An isolated test host; do not use customer data.
- A generated authority Ed25519 keypair and two distinct strong database passwords.

## 2. Provision local secrets

From the package root:

```bash
cp DEPLOYMENT/.env.example DEPLOYMENT/.env
mkdir -p DEPLOYMENT/secrets
python scripts/generate_authority_key.py \
  --private DEPLOYMENT/secrets/authority-ed25519.pem \
  --public DEPLOYMENT/authority-public.pem
sudo chown 10001:10001 DEPLOYMENT/secrets/authority-ed25519.pem
sudo chmod 0400 DEPLOYMENT/secrets/authority-ed25519.pem
```

The authority container runs as UID 10001. The key loader fails closed unless the pre-provisioned Ed25519 key is owner-readable and inaccessible to group/other users; it does not generate a new identity at service startup. Adapt ownership to the container UID mapping on rootless/user-namespaced Docker hosts.

Generate three distinct 32-byte hexadecimal secrets (for example, run `openssl rand -hex 32` three times) and edit `DEPLOYMENT/.env`. Hexadecimal values avoid shell/DSN quoting ambiguities. Set:

- `CRO_POSTGRES_BOOTSTRAP_PASSWORD` — bootstrap superuser only.
- `CRO_POSTGRES_PASSWORD` — non-superuser runtime role `cro_app`.
- `CRO_AUTHORITY_ADMIN_TOKEN` — at least 32 random characters.
- `CRO_AUTHORITY_DSN` — service-network DSN using `cro_app` and the URL-encoded runtime password.
- `CRO_TEST_POSTGRES_DSN` — host DSN using `127.0.0.1:55432` and the same runtime credentials.

Do not commit `.env`, the private key, or any secret. The public key may be distributed to receivers.

## 3. Run the complete automated live gate

```bash
bash scripts/run_postgres16_gate.sh
```

The script validates Compose configuration, builds the authority image, launches PostgreSQL, confirms server major version 16, verifies the non-superuser runtime role and migration objects, runs live integration tests, starts the authority service, checks its health endpoint, and reruns the complete test suite with the live DSN enabled. It writes a timestamped log under `VALIDATION/`.

Expected test coverage:

1. Policy reservation, authority token issue/consume/revoke, engine transitions, receiver acceptance and duplicate replay.
2. Concurrent single-use signed-token consumption: exactly one acceptance, one replay rejection.
3. Concurrent lease takeover: epoch 2 wins; epoch 1 cannot overwrite it.
4. Concurrent duplicate delivery: exactly one durable receiver effect and identical responses.
5. Trusted-key enrollment/history and signed checkpoint-anchor/clock-watermark round-trip.
6. Transaction rollback: mutation and audit record both absent after deliberate failure.
7. Recovery: a new connection/process reads the committed lease and engine state.
8. Fencing, revocation epoch, and presence/enforcement of all append-only triggers.
9. PostgreSQL `DurableStore` and durable-outbox transaction round-trips, including the restricted outbox cleanup privilege.

All live tests retry only SQLSTATE `40001` and `40P01`; other errors fail the gate.

## 4. Manual operational checks

After the script passes:

- Restart `cro-authority` and verify the same public key fingerprint and authority epoch remain stable.
- Restart PostgreSQL and repeat the full integration suite.
- Take a database backup, restore it into a separate empty PostgreSQL 16 instance, and rerun integrity plus integration tests.
- Test a controlled PostgreSQL connection interruption during a transaction; verify no partial receiver effect or audit mutation survives.
- Verify logs do not expose DSNs, passwords, private key material, bearer tokens, or request bodies.
- Confirm external ingress is TLS-protected and the authority admin endpoint is not publicly exposed.
- Verify database backups are encrypted, access-controlled, retained and restorable.

Record commands, versions, timestamps, exit codes, logs and backup/restore identifiers in a signed validation report. Do not claim a check passed based only on service health.

## 5. Stop conditions

Any failed integration, serialization retry exhaustion, unexpected duplicate effect, stale-fence acceptance, missing trigger, migration drift, authority restart key change, restore failure, or secret exposure is a release blocker. Disable authorization traffic and preserve logs for investigation.

## 6. Production promotion still requires

- Independent security review of the exact source and deployment candidate.
- Customer-specific privacy, data retention/deletion, access-control and incident-response approval.
- Owner-controlled release-signing key custody and detached signature verification.
- Owner approval of the exact tested artifact and deployment environment.

A passing local PostgreSQL 16 gate is necessary but not sufficient for production certification.
