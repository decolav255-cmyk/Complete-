# CRO v2.0.5 deployment-hardening candidate — local audit record

**Execution date:** 2026-11-09  
**Disposition:** Deployment-hardening candidate; not production-deployed, not owner-signed, and not independently security-audited.

## Preserved baseline

- Approved scientific specification: `CRO_DEMONSTRATION_SPEC_v2.0.5.md` and `DEMO/APPROVAL_v2.0.5.txt` unchanged.
- R23 source pin: `SOURCE/cro/pooled_screen.py` SHA-256 `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`.
- Historical S1–S3, Option A, and partial OC artifacts retained. No confirmatory reruns or historical result overwrites performed in this hardening pass.

## New implementation

1. `SOURCE/cro/remote_authority.py`: separately deployable Ed25519 lease authority service with independent SQLite state, short-lived signed lease tokens, revocation epochs, protected administrative endpoints, bounded request size, health/epoch endpoints, and restrictive private-key creation permissions.
2. `SOURCE/cro/idempotent_receiver.py`: verifies authority signatures and live authority epoch; rejects expired/future tokens and stale fencing epochs; durably stores accepted logical effects; replays identical idempotency keys without duplicating acceptance; rejects reuse with different payloads.
3. `SOURCE/cro/postgres_store.py`: optional PostgreSQL SERIALIZABLE transaction wrapper for durable outbox. It is explicitly **not** full application-wide PostgreSQL support; existing SQLite-specific policy/authority/engine paths still require migration and integration work.
4. `DEPLOYMENT/`: Docker reference deployment, environment template, security/data-control baseline, optional PostgreSQL dependency, and deployment/rollback runbook.
5. `scripts/`: owner-controlled Ed25519 release key generation, detached manifest signing, and signature verification. Private release keys are not included in the package.

## Tests

- Combined package test suite: **68 passed**.
- New deployment-hardening tests: **5 passed**.
- Python compilation: **passed** (`python -m compileall -q SOURCE OC scripts`).
- R23 pinned source hash: exact match.
- Original CRO v0.6.16 baseline suite: **207 passed**.
- PostgreSQL live integration: **not run** (no PostgreSQL server/driver available in the execution environment).
- Docker image build / remote deployment: **not run** (requires owner-controlled infrastructure and credentials).

## Remaining release gates

- Deploy authority service in an owner-controlled isolated environment; configure TLS ingress, secret custody, monitoring, encrypted backups, and restore.
- Integrate receiver with each real downstream side-effect system and prove its idempotency/transaction semantics.
- Complete full PostgreSQL schema migration and application integration tests if PostgreSQL is the chosen backend; the current optional module covers only the durable-outbox transaction primitive.
- Owner-controlled detached release signing using a project-owned private key, with key custody recorded.
- Independent technical/security review of this exact candidate.
- Customer-specific data controls, contracts, retention/deletion, access controls, incident response, hosting approval, and pilot acceptance.

## Scientific and commercial boundary

The v2.0.5 scientific evidence and claims boundary are unchanged. The candidate is suitable for continued deployment preparation and controlled engineering evaluation. It is not an authorization to ingest customer data or represent CRO as production-certified. Paid pilot execution remains gated by the owner and customer-specific approvals above.
