# PostgreSQL deployment preparation — phase 1 audit

**Date:** 2026-11-09  
**Disposition:** PostgreSQL-target preparation candidate; not production-ready.

## Implemented in this phase

- Selected PostgreSQL 16 as the production database target; SQLite remains available for local development and existing validated paths.
- Added a PostgreSQL 16 service to the reference Docker Compose deployment.
- Added an explicit durable-outbox SQL migration.
- Hardened `PostgresDurableStore` to establish SERIALIZABLE isolation on each transaction.
- Added bounded retries for PostgreSQL serialization failures (`40001`) and deadlocks (`40P01`); other database errors are not retried.
- Added driver-independent tests for transaction setup, commit/rollback, retry behavior, and qmark conversion.
- Added an opt-in live PostgreSQL round-trip test gated by `CRO_TEST_POSTGRES_DSN`.
- Updated deployment runbook, environment example, manifest, and checksums.

## Verification

- Package test suite: **72 passed, 1 skipped**.
- The skipped test is the live PostgreSQL integration test; no PostgreSQL server/DSN was available in this environment.
- Release manifest entries: **143**, all hashes verified.
- Current package checksum list: all entries verified.
- Approved R23 source hash: exact match to `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`.

## Explicitly not completed

This is **not full PostgreSQL application support**. The policy manager, execution engine, remote authorization authority, and idempotent receiver still use SQLite-specific persistence and require PostgreSQL schema/transaction migrations. No production authorization workload should be routed to PostgreSQL until those migrations and live integration/concurrency tests pass.

No Docker build, database service launch, live PostgreSQL test, remote deployment, owner-controlled detached signature, or independent security review was performed in this phase.

## Next engineering gates

1. Port the policy manager's reservations, authority epochs, token consumption, and append-only audit tables to PostgreSQL-native DDL and serializable transactions.
2. Port engine lifecycle state and immutable transition history.
3. Port authority state and receiver idempotency/fencing records; test atomicity against a real downstream adapter.
4. Run migration, restart, backup/restore, concurrency, serialization-failure and fail-closed tests against PostgreSQL 16.
5. Build and deploy into owner-controlled infrastructure; complete key custody, detached signing and independent review separately.
