# Independent AI-assisted CRO code review prompt

You are acting as an adversarial second reviewer. You did not implement this candidate. Review the exact `CRO_RESEARCH_PACKAGE_V2.0.5_POSTGRES_PHASE3_CANDIDATE.zip` artifact and do not modify its files.

## First verify the artifact

- Compute the ZIP SHA-256 and compare it with the external release receipt supplied with the archive.
- Verify `CRO_RELEASE_MANIFEST.json` and `CRO_SHA256SUMS.txt` against every package file.
- Verify `SOURCE/cro/pooled_screen.py` against the approved R23 SHA-256 `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`.
- Confirm the approved scientific specification and historical evidence are not modified.

## Review scope

1. PostgreSQL SQL adapter correctness: qmark parsing, SQLite-to-PostgreSQL translation, transaction state tracking, cursor/connection lifecycle, SERIALIZABLE behavior and commit/rollback failure handling.
2. Retry correctness: only SQLSTATE `40001` and `40P01`, full transaction replay, idempotency, callback side-effect boundaries, and ambiguous commit behavior.
3. Authorization correctness: Ed25519 claim validation, nonce replay prevention, authority epoch/revocation races, expiry/future timestamps, fencing epochs and concurrent takeover.
4. Receiver correctness: idempotency-key collisions, duplicate delivery races, authority epoch checked atomically with effect acceptance, stale fencing, payload hash binding and behavior after token expiry.
5. All persistent components: policy manager, authority, execution engine, durable outbox, trusted-key history and checkpoint/clock monitor. Check every SQL statement against PostgreSQL 16 syntax and migration schema.
6. Migration correctness: idempotence, transactional application, trigger names and targets, immutable table coverage, runtime role privileges, sequence permissions and existing-volume upgrade behavior.
7. Deployment security: non-root container, read-only filesystem, private-key ownership/mode, secret exposure, database bootstrap/runtime role separation, ports, TLS ingress assumptions, health checks and logs.
8. Recovery: rollback, restart, backup/restore, migration failure recovery, connection loss and authority key continuity.
9. Scientific and commercial claims: confirm deployment hardening does not expand CRO's approved v2.0.5 scientific claims or misrepresent historical evidence.

## Required output

- Findings first, sorted Critical / High / Medium / Low / Informational.
- For each finding: exact file and line(s), preconditions, concrete failure/exploit scenario, impact, reproducibility, and recommended remediation.
- Separate confirmed defects from hypotheses and environment-dependent concerns.
- Identify any missing PostgreSQL 16 or Docker tests. Never describe skipped tests as passed.
- End with a concise verdict: PASS, CONDITIONAL PASS, or FAIL, and list release blockers.

Do not produce a generic checklist. Do not change code. An AI review is a useful adversarial second opinion, not a substitute for a qualified independent security assessment or actual live PostgreSQL 16 execution.
