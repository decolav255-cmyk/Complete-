# PostgreSQL application hardening — phase 3 audit

**Date:** 2026-11-09  
**Disposition:** Implementation and verification-procedure candidate; not production-certified.

## Implemented in this phase

- Added bounded whole-operation retries for PostgreSQL serialization failures (`40001`) and deadlocks (`40P01`) to policy reservation/authorization/fenced mutation, authority token issuance/revocation, engine state transitions, and idempotent receiver acceptance. Only these retryable SQLSTATEs are retried; other failures propagate. Retryable callbacks are database-only.
- Moved PostgreSQL receiver authority-epoch validation into the same SERIALIZABLE transaction as the accepted effect, preventing the reference shared-database deployment from relying on a preflight-only revocation check.
- Aligned engine and consumed-token append-only trigger checks with migration 002's trigger names; added a regression contract test.
- Explicitly close PostgreSQL connections created by authority bootstrap and receiver operations.
- Made authority startup fail closed when the signing key is absent or group/world-readable; service startup no longer silently generates a new authority identity.
- Extended the PostgreSQL schema and runtime adapter to trusted-key history and checkpoint anchor/clock persistence, including BYTEA conversion, append-only triggers, and bounded transaction retries.
- Added a live round-trip test for the `DurableStore(backend="postgresql")` path; limited runtime DELETE permission to the operational `durable_outbox` table, while immutable evidence tables remain non-deletable by `cro_app`.
- Separated the PostgreSQL bootstrap role from the non-superuser `cro_app` runtime role. Added an init script to create/grant the runtime role, loopback-only host port mapping, and separate bootstrap/runtime secrets.
- Expanded opt-in PostgreSQL 16 integration coverage to include full-stack round-trip, single-use signed-token race, concurrent lease takeover/fencing, concurrent duplicate delivery, deliberate transaction rollback, recovery from a fresh connection, revocation, and append-only enforcement.
- Added a repeatable live-gate script, live verification procedure, independent security-review request, and owner-controlled signing handoff.

## Verification actually performed in this environment

- `PYTHONPATH=. pytest -q`: **78 passed, 7 skipped**.
- The seven skipped tests require a live PostgreSQL DSN. They were not executed.
- Python compilation: passed.
- Bash syntax validation for the PostgreSQL gate and runtime-role init scripts: passed.
- ZIP integrity: `unzip -t` passed; all manifest payload hashes and current checksum entries verified.
- R23 pinned source SHA-256 remains `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`.

## Not verified

- No PostgreSQL 16 server was available; neither migration was executed by PostgreSQL.
- No Docker executable/daemon was available; image build and Compose launch were not performed.
- No live race, serialization retry, rollback/restart, backup/restore, or connection-loss scenario was executed.
- The runtime role bootstrap shell script was syntax-checked but not run against PostgreSQL.
- No independent security review, customer-specific privacy/legal review, production TLS/secret-manager deployment, or owner-controlled release signature exists yet.

## Required next gates

1. Run `bash scripts/run_postgres16_gate.sh` on a host with Docker and PostgreSQL 16 image access.
2. Complete manual restart, backup/restore and connection-loss checks in `VALIDATION/POSTGRES16_LIVE_VERIFICATION_PROCEDURE.md`.
3. Obtain independent review and remediate all Critical/High findings.
4. Have the owner sign the exact final manifest using an offline/owner-controlled key and verify the detached signature.

**Release verdict:** `CANDIDATE_PENDING_LIVE_POSTGRES16_AND_EXTERNAL_GATES`. Do not represent this candidate as production-ready or enable production authorization traffic.

The approved scientific specification v2.0.5, its approval record, historical results, and pinned R23 source were not intentionally changed.
