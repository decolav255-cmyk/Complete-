# Remaining Gates — CRO v2.0.6 Complete Assembly

**Date:** 2026-11-09  
**Environment used for this assembly:** Linux container without PostgreSQL server, without Docker, without psycopg driver.

## Gates that passed in this environment

- Full scientific baseline (v2.0.5 specification, approval record, historical DEMO evidence) retained.
- Security-remediation source changes overlaid and verified by unit tests.
- `.pytest_cache` and temporary build artefacts removed.
- Outbox claims narrowed to implemented functionality only.
- Internal component SHA-256 manifest (`CHECKSUMS.sha256`) generated.
- Automated test suite: **94 passed, 7 skipped**.
- No production-readiness, penetration-test, or independent-certification claims made.

## Outstanding gates (not executed)

1. **Live PostgreSQL 16 privilege / role enforcement**  
   - Script `DEPLOYMENT/postgresql/003_create_runtime_role.sh` exists but has never been applied against a real PostgreSQL 16 instance in this audit.  
   - Required: create role, apply grants, attempt forbidden UPDATE/DELETE on append-only tables, confirm rejection.

2. **Full Postgres-16 live verification procedure**  
   - `VALIDATION/POSTGRES16_LIVE_VERIFICATION_PROCEDURE.md` remains the authoritative checklist.  
   - Items still open: concurrent lease takeover, restart recovery, connection-loss, backup/restore round-trip, signed validation report.

3. **Docker Compose / deployment gate**  
   - `scripts/run_postgres16_gate.sh` and `DEPLOYMENT/docker-compose.yml` not exercised.

4. **TLS termination / reverse-proxy validation**  
   - Code correctly refuses non-loopback cleartext without the laboratory override. Actual TLS termination at a proxy was not tested.

5. **Backup / WAL / point-in-time recovery**  
   - Documented as deployment-environment responsibilities; no restore evidence produced in this run.

6. **Penetration testing / independent security certification**  
   - Explicitly not claimed and not performed.

## Verdict on readiness

- Suitable for further technical review and design-gate preparation **once** the live PostgreSQL privilege and deployment gates are closed by an environment that possesses PostgreSQL 16 + Docker.
- **Not** ready for commercial pilot-authorization outreach or final release.
- This assembly does **not** constitute a full PASS.

## How to close the remaining gates

1. Provision PostgreSQL 16 and Docker.
2. Apply migrations and the runtime-role script.
3. Execute every step in `POSTGRES16_LIVE_VERIFICATION_PROCEDURE.md`.
4. Attach signed logs, exit codes, and restore identifiers.
5. Update this remaining-gates document and the change manifest.
6. Re-compute the final ZIP SHA-256 and publish a new detached checksum.
