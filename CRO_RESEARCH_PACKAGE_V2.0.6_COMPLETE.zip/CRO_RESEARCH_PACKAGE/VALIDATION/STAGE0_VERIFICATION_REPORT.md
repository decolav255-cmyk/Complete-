# Stage 0 — baseline integrity report

**Execution date:** 2026-11-08  
**Result:** Archive integrity checks passed; original internal manifest contained one documented mismatch; mismatch is corrected in this derivative candidate only. This is not an independent third-party audit.

## Protected baseline

- File: `CRO_RESEARCH_PACKAGE(4).zip`
- Size: 1,258,660 bytes
- SHA-256: `611e7f0fe808e50d8cb29ffc5ae4dccc5428c847d70e9a33437badb308d633bd`
- Expected pinned SHA-256: `611e7f0fe808e50d8cb29ffc5ae4dccc5428c847d70e9a33437badb308d633bd`
- Match: **YES**
- ZIP entries: 91
- ZIP CRC test: **PASS**

## Original internal checksum manifest

- Entries checked: 22
- Matching entries: 21
- Mismatching entries: 1
- Missing entries: 0

The sole mismatch was `PHASE1_STATUS.md`:

- Manifest expected: `99ae9febff072cca8959cb764f2ef8dc6205b8463cae873f2f4f8fe898cc2a4d`
- Actual bytes: `187142836572e9060e10c16d1e2d64363d93934a642f221efa1d781d4cc2d503`
- Disposition: preserved the original file content, appended a dated package-state addendum in this derivative, and refreshed the manifest to the resulting exact file hash. The historical source of the old expected digest is unknown. This is a manifest-consistency repair, not proof of provenance.

## Nested archives

| Artifact | SHA-256 | Result |
|---|---|---|
| `ORIGINALS/CRO_R23_EXACT_RATIONAL_PHASE1.zip` | `ee848fa5a55aa1620fb5148356bb7f79e5cb82c4a4e2b65edc3b8ae57e95095b` | Matches recorded project pin |
| `ORIGINALS/CRO_v0.6.16_DEV_VALIDATED.zip` | `3860e079e6b29ef86844b74b99ca9326b7997a298dbd883ff2342160ec88beef` | Matches recorded project pin |

Both nested archives passed ZIP CRC testing.

## Frozen artifacts preserved

| Artifact | SHA-256 |
|---|---|
| `CRO_DEMONSTRATION_SPEC_v2.0.5.md` | `4eb854e7fabc5872568cd5c7c5b66a03b524ef805f604d2162118c88badcbec7` |
| `DEMO/APPROVAL_v2.0.5.txt` | `b6aba20a9391ee53fdbf6f7d4122e32853467ec3c9bf23182ff4629c645e2e8e` |
| `SOURCE/cro/pooled_screen.py` | `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6` |

These hashes match the original internal manifest. No bytes in these artifacts were changed in this candidate.

## Test execution

- Command: `PYTHONPATH=SOURCE python -m pytest -q SOURCE/tests/test_pooled_screen.py`
- Result: **25 passed**
- Note: invoking pytest without `PYTHONPATH=SOURCE` fails collection because the package import root is not configured; the corrected command passes.

## Scope and exclusions

This report does not establish source-code correctness beyond the executed test suite, security, concurrency safety, cryptographic correctness, production readiness, independent audit, customer validation, or commercial release approval. It does not implement RC2.5.0.
