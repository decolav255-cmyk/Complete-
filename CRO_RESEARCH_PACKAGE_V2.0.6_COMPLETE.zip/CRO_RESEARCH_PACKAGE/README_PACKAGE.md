# CRO Research Package v2.0.5 — Repaired Release Candidate

**Status:** Repaired local verification candidate; not production-certified and not independently security-audited.

## Start here

1. `COMMERCIAL/OUTREACH_READINESS.md` — current permitted outreach and paid-pilot boundaries.
2. `COMMERCIAL/EXECUTIVE_ONE_PAGER.md` — claims-safe scientific summary.
3. `COMMERCIAL/COVER_EMAIL.md` — exploratory outreach draft.
4. `COMMERCIAL/OFFER_AND_PRICING.md` — indicative packages, pricing, and prerequisites.
5. `COMMERCIAL/PILOT_PROTOCOL.md` — mandatory pilot eligibility, scope, execution gates, and deliverables.
6. `SOURCE/README.md` — source map, test command, and technical limitations.
7. `VALIDATION/RELEASE_CANDIDATE_AUDIT_2026-11-09.md` — reproducible local audit record.
8. `GOVERNANCE/RC2.5.0_STATUS.md` — implementation status and unresolved requirements.
9. `VALIDATION/POSTGRES16_LIVE_VERIFICATION_PROCEDURE.md` — reproducible live PostgreSQL 16/Docker gate.
10. `VALIDATION/INDEPENDENT_AI_REVIEW_PROMPT.md` — adversarial second-review brief (not a formal security audit).

## Frozen scientific baseline

`CRO_DEMONSTRATION_SPEC_v2.0.5.md` and `DEMO/APPROVAL_v2.0.5.txt` are preserved unchanged. Historical S1–S3 results, Option A artifacts, the R23 source pin, and partial OC v1.1 materials are retained. No new confirmatory runs or historical result changes are represented.

## What is included

- Full research, demonstration, evidence, protocol, commercial, and governance material.
- Original nested R23 and CRO v0.6.16 baseline archives.
- Deterministic SHA-256-based seed derivation for future OC runs; historical partial OC outputs are preserved unchanged.
- Pinned R23 source and its original tests.
- Local hardened core modules and reproducible tests for authorization, signatures, lifecycle, fencing, SQLite durability, and checkpoint anchoring.
- PostgreSQL 16 persistence paths, migrations, append-only triggers, non-superuser runtime role, live-gate runner, and owner/security-review handoff documents.

## Release boundary

Exploratory discovery outreach is permitted within the stated claim boundaries. A paid operational pilot remains conditional on owner approval of this exact candidate, independent technical/security review, customer-data controls, operational runbook and rollback, and signed contractual terms. Annual software licensing and production deployment are not offerable.

## Integrity files

- `CRO_RELEASE_MANIFEST.json` contains file hashes for package payload files.
- `CRO_SHA256SUMS.txt` contains the current package file checksums, including the release manifest.
- The inherited `CHECKSUMS.sha256` is retained as a historical baseline artifact; it is not the current checksum list for this repaired derivative.
- The ZIP's own SHA-256 is provided in the external release receipt beside the ZIP. It is intentionally not embedded in the ZIP manifest because embedding the archive's own final hash creates a self-referential checksum problem.

## PostgreSQL deployment candidate status (2026-11-09)

The package includes PostgreSQL-compatible persistence paths for the policy manager, execution engine, remote authorization authority, idempotent receiver, durable outbox, trusted-key history, and checkpoint/clock persistence; bounded retries for serialization/deadlock aborts; database-enforced append-only triggers; a pre-provisioned owner-only authority signing key; and a separate non-superuser runtime database role. Run `bash scripts/run_postgres16_gate.sh` to execute the live PostgreSQL 16, Docker and service-health gates. In the implementation environment, **78 local tests passed and 7 live PostgreSQL tests were skipped** because PostgreSQL/Docker were unavailable. No live database or container launch is claimed. See `VALIDATION/POSTGRES16_LIVE_VERIFICATION_PROCEDURE.md` and `VALIDATION/POSTGRES_PHASE3_AUDIT.md`.
