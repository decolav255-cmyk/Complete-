# CRO Demonstration Specification v2.0.1

**Version:** 2.0.1  
**Date:** 2026-11-06  
**Status:** DRAFT FOR INSPECTION — not formally frozen  
**Amends:** v2.0 (specification precision only)  
**Non-changes:** No new simulations; no changes to historical numerical results; no retuning; V3 failure retained  

**R23 implementation pin (D1):**  
`SOURCE/cro/pooled_screen.py` SHA-256 `92157a54cd04d3e06c27691f23eb0106485c0ea07bef5659d96e621c7ba709d6`

---

# Part A — Scope and posture

## A1. Purpose

Single consolidated specification for the independent demonstration track: historical results, claim boundaries, decision states, D1 statistic definition, predeclared unevaluated procedures, and reproducibility details.

## A2. Non-claims

Not partner/production validation; not ROI; not OC Protocol v1.1 completion; not formal freeze until explicitly approved.

## A3. Two tracks

| Track | State |
|-------|--------|
| Demonstration (this document) | S1–S3 confirmatory history complete; narrative corrected |
| OC Protocol v1.1 | Separate; **partial**; not replaced by demo (n=500 ≠ 5,000/2,000) |

---

# Part B — System under test

## B1. D1 — Design-gated sharp-null procedure (fully specified)

### B1.1 Eligibility

Design-eligible only if **all** hold:

- `mechanism = complete_cluster_randomization_within_strata`
- Treatment constant within each cluster  
- Strata vector aligned to first-appearance cluster order  
- Verified `randomization_record`: algorithm `numpy.PCG64_uniform_without_replacement_v1`, nonnegative integer seed, treated_counts per stratum  
- Observed assignment reproduces from that record  

Otherwise the scenario is **NOT_ELIGIBLE** (see B2). Do not fabricate a record.

### B1.2 Implementation entry point

- Call: R23 `RobustPooledScreenEngine.sharp_null_test(...)`  
- Which invokes: `constant_effect_inversion(..., tau_reference=0.0, fixed_tau_only=True)`  
- Source pin: SHA-256 above  

### B1.3 Null hypothesis

Sharp global null under the declared randomization:

\[
H_0:\ Y_i(1)=Y_i(0)\ \text{for all units }i.
\]

### B1.4 Test statistic

For each complete-cluster allocation \(A\) in the **design-only estimable allocation set**:

1. Form the cluster-level / individual-level design used by R23 for the **treatment × moderator interaction** coefficient in the working model with intercept, \(T\), \(M\), and \(T\times M\) (CR1 cluster-robust machinery as implemented in `pooled_screen.py`).  
2. At fixed \(\tau=0\) (no outcome adjustment by a constant treatment effect parameter), compute the CR1 **interaction** \(t\)-statistic for allocation \(A\), denoted \(t_{\mathrm{int}}(A)\).  
3. **Observed statistic:** \(T_{\mathrm{obs}} = |t_{\mathrm{int}}(A_{\mathrm{obs}})|\), exported in diagnostics as `absolute_t_statistic` when available.

**Sensitivity note (binding):**  
This statistic is an **interaction functional**. It can reject the sharp global null when data are extreme under that null, and it is **primarily sensitive to patterns aligned with treatment–moderator interaction**, not to a pure constant main effect. Therefore:

- Rejection of the sharp null **≠** establishment of moderation as a separate causal claim.  
- **Failure to reject does not establish** that a uniform main effect is absent.

### B1.5 Reference distribution and p-value (fixed-τ exact path)

1. Enumerate the allocation space implied by complete cluster randomization within strata with fixed within-stratum treated counts (or the design-only **estimable** subset if rank/variance rules exclude some allocations).  
2. For each estimable allocation \(A\), form the exact-rational comparison that ranks allocations by the interaction statistic at \(\tau=0\) (R23: polynomial comparison \(B/V\) form; count allocations at least as extreme as observed).  
3. **Exact randomization p-value:**

\[
p = \frac{\#\{A:\ A\text{ is at least as extreme as }A_{\mathrm{obs}}\}}{\#\{\text{estimable allocations}\}}
\]

as implemented by `p_at(tau_ref)` in the fixed-τ path (Fraction arithmetic; observed allocation included).  

4. Primary decision threshold: \(\alpha = 0.05\) (two-sided extremeness in the sense of the implemented ranking).  

5. If enumeration exceeds the engine threshold or the observed allocation is not estimable, the engine **ABSTAINS** (no p-value).

### B1.6 What fixed-τ D1 does *not* test

- It does not authorize “beneficial improvement.”  
- It does not, by itself, identify a main-effect estimand \(\tau\).  
- It does not establish moderation as a distinct hypothesis test of \(\beta\neq 0\) without further assumptions.

---

## B2. Outcome states (mutually exclusive authorization layer)

Use **one** primary state per replicate:

| State | Meaning |
|-------|---------|
| **AUTHORIZE** | Design-eligible; test executed; \(p < 0.05\) → `AUTHORIZE_DESIGN_BASED_REJECTION_OF_SHARP_NULL` |
| **DO_NOT_AUTHORIZE** | Design-eligible; test executed; \(p \ge 0.05\) |
| **NOT_ELIGIBLE** | No authentic eligible design/record (e.g., S1); test **not** run as CRT |
| **ABSTAIN** | Design claimed eligible but engine abstained (rank, variance, threshold, verification failure after attempt, etc.) |

**Rules**

- **NOT_ELIGIBLE** and **ABSTAIN** both imply **no authorization**, but they are **not** the same state.  
- Record machine-readable `reason` separately in all cases.  
- S1 historical reporting: primary state **NOT_ELIGIBLE** (reason `missing_randomization_record`), not “eligible test failed to reject.”  
- Forbidden primary success reason: `confounding_flag_demo`.

**Legacy mapping (historical JSON fields)**  
Older rows may store `D1_do_not_authorize=True` and `D1_abstain=True` for S1. Under v2.0.1 taxonomy that is interpreted as **NOT_ELIGIBLE** when reason is `missing_randomization_record` / `observational_assignment` and no p-value was produced. Numerical rates unchanged.

---

## B3. Comparator taxonomy

| ID | Method | CRT-valid? | Use |
|----|--------|------------|-----|
| **C1_OLS_unclustered** | Pooled OLS \(Y\sim 1+T\), IID SE, normal \(p\) | **No** | Foil only |
| **C1m_cluster** | §F cluster-robust main-effect | Only after evaluation | Predeclared; unevaluated |
| **C2** | CR1 interaction, naive normal \(p\) | No | Stress comparator |
| **C3** | Ignore clustering | No | Optional stress |

Historical S2 rate 31.2% = **C1_OLS_unclustered only**.

---

## B4. Commercial constraints

**Allowed:** record-gated non-authorization; sharp-null rejection rates under verified CRT; explicit limitations.  

**Forbidden:** D1 ⇒ moderation or proven benefit; 31.2% ⇒ CRT-valid main-effect detection; “conventional methods generally fail”; universal 5% calibration; low power ⇒ no effects exist; demo ⇒ OC complete.

---

# Part C — Historical confirmatory results (unchanged figures)

Demo master seed: `20261108`. Engine: R23 pin above. n=500 per scenario.

## C1. S1 — Confounded, no record

| Metric | Rate | Wilson 95% |
|--------|------|------------|
| C1_OLS_unclustered sig pos | 0.982 | — |
| AUTHORIZE | 0.000 | — |
| NOT_ELIGIBLE (reason missing_randomization_record) | 1.000 | — |
| Primary success (OLS sig pos ∧ not AUTHORIZE ∧ allowed reason) | **0.982** | **(0.966, 0.991)** |

## C2. S2 — CRT record, pure main effect \(\tau_0=0.35\), \(\beta=0\)

| Metric | Rate | Wilson 95% |
|--------|------|------------|
| AUTHORIZE (D1) | **0.046** | **(0.031, 0.068)** |
| DO_NOT_AUTHORIZE (eligible, \(p\ge 0.05\)) | 0.954 | — |
| ABSTAIN | 0.000 | — |
| C1_OLS_unclustered sig pos | 0.312 | (0.273, 0.354) |
| V3 power floor | **FAILED** | see C4 |

Reading: interaction-functional D1 vs main-effect truth explains low AUTHORIZE rate; does not prove main effect absent; OLS 31.2% is not CRT-valid inference.

## C3. S3 — CRT record, sharp null

| Metric | Rate | Wilson 95% |
|--------|------|------------|
| AUTHORIZE (Type I snapshot) | **0.046** | **(0.031, 0.068)** |
| ABSTAIN | 0.000 | — |
| C1_OLS_unclustered sig pos | 0.072 | (0.052, 0.098) |

## C4. Value test V3 (clarified)

**Intent:** demo **power floor** for D1 AUTHORIZE rate under S2’s predeclared alternative.

**v2.0.1 success criterion (sole):**

\[
\text{V3 passes only if }\hat p_{\mathrm{AUTHORIZE}} \ge 0.20.
\]

Wilson confidence intervals are **always reported** for transparency but **do not** constitute an alternate pass rule (a rate of 0.08 whose CI excludes 0.05 does **not** pass V3).

**Historical outcome:** \(\hat p=0.046 < 0.20\) → **V3 FAILED** (retained).

V1 supported; V2 descriptive only (S3 Type I snapshot).

---

# Part D — Dual readout (Path C)

On CRT-eligible scenarios: report D1 states and C1_OLS_unclustered side by side; agreement not required; C1m_cluster only after §F evaluation.

---

# Part E — Optional S2i

Future separate arm: \(\tau_0=0\), \(\beta=0.35\), same CRT shell.  
Passing any power floor on S2i **does not** validate V3 on pure main-effect S2.

---

# Part F — C1m_cluster (predeclared, unevaluated)

### F1. Estimand

Individual-level average treatment effect \(\tau=\mathbb{E}[Y_{ic}(1)-Y_{ic}(0)]\) under the declared CRT.

**Weighting:** Primary evaluation design uses **equal cluster sizes** (\(n_c=5\) for all clusters). The working model is fit at the individual level with equal weight per individual; with equal \(n_c\), individual-weighted and cluster-weighted average treatment effects coincide. If a future design uses unequal cluster sizes, an amendment must declare whether \(\tau\) is individual-weighted or cluster-weighted before evaluation.

### F2–F8. (Unchanged substance from v2.0)

- Null \(\tau=0\); \(\alpha=0.05\)  
- Model: \(Y\sim 1+T+\) stratum FE only  
- Statistic: \(t_\tau=\hat\tau/\mathrm{SE}_{\mathrm{CR1}}(\hat\tau)\); primary \(p=2\Phi(-|t_\tau|)\)  
- CI: Wald 95% with CR1 SE  
- Missing: complete finite \((Y,T)\) or abstain; no imputation  
- First evaluation design if later approved: S2-like G=12, n=5, ICC=0.20, \(\tau_0=0.35\), \(\beta=0\), 500 reps  
- CR1 normal-reference is a **predeclared candidate**, not validated operating-characteristic proof at G=12 until evaluated  
- No performance claim until approved evaluation exists  

---

# Part G — Reproducibility (complete)

## G1. Child seed derivation

```text
u32(label) = unsigned big-endian uint32 from SHA-256(utf-8(label))[0:4]
SeedSequence([20261108, u32(scenario), int(replicate_id), u32(role)]) → numpy.random.PCG64
```

- Byte order: **unsigned big-endian** for the four bytes.  
- `replicate_id` begins at **0**.  
- Python `hash()` forbidden.

## G2. Exact scenario strings

| Scenario | `scenario` string |
|----------|-------------------|
| S1 | `S1` |
| S2 | `S2` |
| S3 | `S3` |

## G3. Exact role strings

| Role | String | Used for |
|------|--------|----------|
| Confounder draws (S1) | `C` | `C_c` |
| Moderator draws | `M` | cluster-level \(M\), then standardized |
| Outcome noise / DGP | `Y` | \(u_c\), \(\varepsilon_{ic}\) streams as implemented |
| Assignment seed material (S2/S3) | `assignment` | draws `rec_seed` for PCG64 record |

## G4. Assignment generation (S2/S3)

1. `rec_seed = int(rng_assignment.integers(0, 2**31 - 1))` with `rng_assignment = child_rng(scenario, rep, "assignment")`.  
2. Strata: first \(G/2\) clusters stratum 0; remaining stratum 1.  
3. Within each stratum: `Generator(PCG64(rec_seed))` — **single** generator consumed in stratum order 0 then 1; each stratum draws `nt = n_stratum/2` treated indices without replacement.  
4. Build `randomization_record` with that seed and treated_counts; individual \(T\) = cluster \(T\) expanded by cluster size.

## G5. Historical vs future runs

Aggregate rates in Part C are **historical**. New runs under this seed specification are not required to match old row-level draws bit-for-bit.

---

# Part H — OC Protocol v1.1

Separate track; partial; P1 = exact randomization under stated design (not universal 5% calibration); P2 = naive CR1-normal interaction only; low power at small \(G\) is a limitation.

---

# Part I — External narrative

**Problem.** Significant OLS is often read as “the intervention worked” without a verifiable assignment record.

**S1.** Unclustered OLS significant in 98.2% of replicates; CRO never AUTHORIZE; state NOT_ELIGIBLE with missing randomization record; primary success 98.2% (96.6–99.1%).

**S2.** Under verified CRT, D1 AUTHORIZE (sharp-null rejection via interaction functional) 4.6% (3.1–6.8%); V3 power floor failed. Unclustered OLS significant in 31.2% — not CRT-valid main-effect inference. Cluster-robust main-effect procedure predeclared, unevaluated.

**S3.** Type I snapshot AUTHORIZE 4.6% (3.1–6.8%), zero ABSTAIN.

**One sentence.** CRO is a design-gated evidence brake and sharp-null randomization test under a declared CRT—not an automatic ROI or moderation detector, and not validated by unclustered OLS p-values.

---

# Part J — Approval

Architecture of v2.0 retained; v2.0.1 tightens specification only.

Formal freeze phrase (only when intended):

`Approve CRO Demonstration Specification v2.0.1 as written.`

Until then: inspection draft. New runs (C1m_cluster, S2i, OC cells) require a separate explicit request after freeze.
